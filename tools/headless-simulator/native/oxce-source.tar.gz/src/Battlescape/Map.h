#pragma once
/*
 * Copyright 2010-2016 OpenXcom Developers.
 *
 * This file is part of OpenXcom.
 *
 * OpenXcom is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * OpenXcom is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with OpenXcom.  If not, see <http://www.gnu.org/licenses/>.
 */
#include "../Engine/InteractiveSurface.h"
#include "../Engine/Options.h"
#include "../Engine/Collections.h"
#include "../Mod/MapData.h"
#include "Position.h"
#include "Particle.h"
#include <vector>
#include <map>
#include <tuple>
#include <string>

namespace OpenXcom
{

class SavedBattleGame;
class Surface;
class SurfaceSet;
class BattleUnit;
struct BattleAction;
class Projectile;
class Explosion;
class BattlescapeMessage;
class Camera;
class Timer;
class Text;
class Tile;
class UnitSprite;

enum CursorType { CT_NONE, CT_NORMAL, CT_AIM, CT_PSI, CT_WAYPOINT, CT_THROW };
enum TilePart : int;

/**
 * Helper class that returns all important data about the unit movement
 */
struct UnitWalkingOffset
{
	Position ScreenOffset;
	int NormalizedMovePhase;
	int TerrainLevelOffset;
};

/**
 * Interactive map of the battlescape.
 */
class Map : public InteractiveSurface
{
private:
	static const int SCROLL_INTERVAL = 15;
	static const int FADE_INTERVAL = 23;
	static const int NIGHT_VISION_SHADE = 4;
	static const int NIGHT_VISION_MAX_SHADE = 8;
	static const int BULLET_SPRITES = 35;
	Timer *_scrollMouseTimer, *_scrollKeyTimer, *_obstacleTimer;
	Timer *_fadeTimer;
	int _fadeShade;
	bool _nightVisionOn;
	int _debugVisionMode;
	int _nvColor;
	Game *_game;
	SavedBattleGame *_save;
	bool _isTFTD;
	// R41: camera projection quadrant; reset for each battle.
	int _r41Rotation = 0;
	// SDL 1.2 can omit key-up callbacks for focused overlays; gate key
	// down events by time instead of locking a held-state forever.
	Uint32 _r41LastRotationAt = 0;
	bool _r41PivotValid = false;
	Position _r41PivotWorld;
	Position _r41PivotOffset;
	// R41 wall art: cache horizontal mirrors of immutable source sprites.
	// Sprite sheets remain owned by the Mod; cache is local to this Map.
	std::map<std::tuple<const Uint8*, int, int, int>, std::vector<Uint8>> _r41WallFlipCache;
	// RC7: isometric 90-degree tread rotation, computed once per source frame.
	std::map<std::tuple<const Uint8*, int, int, int, int, int>, std::vector<Uint8>> _r42RampRotateCache;
	// Compatibility no-op for old opaque HUD panel annotations.
	void r40RememberHudRect(int x, int y, int w, int h);
	Surface *_arrow;
	Surface *_stunIndicator, *_woundIndicator, *_burnIndicator, *_shockIndicator;
	bool _anyIndicator, _isAltPressed, _isCtrlPressed;
	int _spriteWidth, _spriteHeight;
	int _selectorX, _selectorY;
	int _mouseX, _mouseY;
	CursorType _cursorType;
	int _cursorSize;
	int _cacheActiveWeaponUfopediaArticleUnlocked; // -1 = unknown, 0 = locked, 1 = unlocked
	bool _cacheIsCtrlPressed;
	Position _cacheCursorPosition;
	int _cacheHasLOS; // -1 = unknown, 0 = no LOS, 1 = has LOS
	int _animFrame;
	Projectile *_projectile;
	bool _followProjectile;
	bool _projectileInFOV;
	std::list<Explosion *> _explosions;
	std::vector<std::vector<Particle>> _vaporParticlesInit;
	std::vector<std::vector<Particle>> _vaporParticles;
	bool _explosionInFOV, _launch;
	BattlescapeMessage *_message;
	Camera *_camera;
	int _visibleMapHeight;
	std::vector<Position> _waypoints;
	bool _unitDying, _smoothCamera, _smoothingEngaged, _flashScreen;
	int _bgColor;
	bool _previewSettingArrows, _previewSettingTu, _previewSettingEnergy;
	Text *_txtAccuracy;
	SurfaceSet *_projectileSet;

	void drawUnit(UnitSprite &unitSprite, Tile *unitTile, Tile *currTile, Position tileScreenPosition, bool topLayer, BattleUnit* movingUnit = nullptr);
	void drawTerrain(Surface *surface);
	void r41BlitWall(Surface *surface, Tile *owner, TilePart part,
		int x, int y, bool half, bool mirror);

    // LOSLOF_R22_RECON_PREVIEW: map-local, default OFF, not persisted.
    bool _r22On = false;
    // R30.2: compact resistance info; Shift+F8 retains the full reference.
    bool _r30FullResists = false;
    // R32: independent Shift+F8 hostile roster with no fog filtering.
    bool _r32EnemyCounts = false;
    void r32DrawEnemyCounts();
    // R37: F8-controlled known-threat risk, reaction-score threshold and
    // action TU / reaction-score deltas. Cache probes for 450ms.
    std::vector<int> _r37ReactionRisks;
    std::vector<int> _r37ReactionTUCosts;
    double _r37VisibleEnemyThreshold = -1.0;
    Uint32 _r37ReactionCheckedAt = 0;
    BattleUnit *_r37ReactionActor = nullptr;
    int _r37ReactionActorTU = -1;
    const void *_r37ReactionSelectedWeapon = nullptr;
    // R38: first-click preview only, cached independently of the stable
    // current-tile HUD. MAX is the highest risk of any one path step.
    unsigned long long _r38PathSignature = 0;
    int _r38PathStepCount = 0;
    int _r38PathFirstTU = -1;
    int _r38PathFirstRisk = -1;
    int _r38PathTotalTU = -1;
    int _r38PathMaxRisk = -1;
    int _r38PathMaxStep = 0;
    int _r38PathMode = 0;
    // R39: fixed-target, first-click shot preview including a conditional
    // hit/survive branch (native wasHitBy bypasses the view-sector gate).
    // R41: progressive Monte Carlo using a private RNG and native Projectile.
    // No saves, unit stats, ammo, TU, or obstacle flags are mutated.
    struct R41LandingCell {
        Position tile = Position(0,0,0);
        unsigned count = 0;
        unsigned early = 0;
        unsigned friendlyRadius = 0;
    };
    std::map<int, R41LandingCell> _r41LandingCells;
    unsigned long long _r41ThrowSignature = 0;
    Uint32 _r41ThrowChangedAt = 0;
    Uint32 _r41ThrowBatchAt = 0;
    unsigned _r41ThrowSamples = 0;
    unsigned _r41Target = 0, _r41Scatter = 0, _r41Early = 0;
    unsigned _r41FriendlyRadius = 0, _r41Unknown = 0, _r41Failed = 0;
    std::string r41DrawThrowHeatmap(BattleAction action, const Position &target,
        const Position &from, const Position &muzzle, bool virtualKneeled);
    unsigned long long _r39TargetSignature = 0;
    int _r39ShotTU = -1;
    int _r39ShotRiskNow = -1;
    int _r39ShotRiskIfHit = -1;
    void r37DrawReactionHud();
    Position r32VirtualStandPosition(const Position &hover, const BattleUnit *actor) const;
    // LOSLOF_R22_NATIVE_INPUT_FIX: native aiming has no click lock.
    BattleUnit *_r22StanceActor = nullptr;
    bool _r22StanceOverride = false;
    Uint32 _r22LastUiRefresh = 0; // at most one incremental redraw per 90ms
    void r22DrawContrastHud(const char *stance, bool simulated,
                            const std::string &tail);
    bool _r22Kneel = false;
    void r22DrawOverlay();
    // Virtual source has the native XY offset and the actual raised voxel
    // foot plane; only previews bypass the native lower-storey clamp.
    Position r32VirtualMuzzle(BattleAction &action, Tile *sourceTile,
        int stanceDelta, bool hypothetical) const;

    // R29: non-invasive target-locked candidate firing-position B heatmap.
    struct R29BlockCell
    {
        Position source = Position(0, 0, 0);
        unsigned trials = 0;
        unsigned blocked = 0;
        unsigned hits = 0;
    };
    std::vector<R29BlockCell> _r29BlockCells;
    unsigned long long _r29BlockKey = 0;
    Uint32 _r29BlockStamp = 0;
    Uint32 _r29BlockBatchStamp = 0;
    size_t _r29BlockNext = 0;
    unsigned _r29BlockPass = 3; // 3 = idle or complete
    void r29ClearBlockGrid();
    void r29DrawTargetBlockGrid(BattleUnit *shooter, BattleAction *current,
                                const Position &target);

    // LOSLOF_R22_STATISTICS_EXPERIMENTAL

    // LOSLOF_R22_RECOVERY_BETA_20261012: drawing-only fields.
    Position r22PlannedPosition(const BattleUnit *unit) const;
    void r22DrawVisibilityHull(const Position &source, const Position &eye, int level);
    void r22DrawRemoteTargetHud(const Position &target, const Position &aim);

    // LOSLOF_R22_THROW_PREVIEW_RECOVERY - strictly map-local state.
    void r22DrawThrowPreview(const Position& from, const Position& destination,
        const Tile* originTile, const Tile* targetTile);
    unsigned long long _r22ThrowCacheKey = 0;
    Uint32 _r22ThrowCacheTime = 0;
    std::vector<Position> _r22ThrowTrajectory;
    bool _r22ThrowValid = false;

    std::vector<unsigned char> _r22VisibleHull;
    unsigned long long _r22HullHash = 0;
    Uint32 _r22HullCheckedAt = 0;
    size_t _r22HullNextIndex = 0; // progressive scan: at most 64 candidate rays/frame
    bool _r22HullWorkPending = false; // ticker, not render, requests next incremental frame
    Uint32 _r22HullLastBatchTick = 0; // throttle ray work on animation redraws

    void r22DrawStats(const Position& origin, const Position& target,
        const Position& aim, const Position& muzzle);
    // Cache expensive native voxel scan for the same aim/weapon/stance.
    unsigned long long _r22NativeAimKey = 0;
    Uint32 _r22NativeAimCheckedAt = 0;
    Position _r22NativeAimGoal = Position(0,0,0);
    bool _r22NativeAimFound = false;
    int _r22NativeAimSide = 0;
    unsigned long long _r22StatsKey = 0;
    unsigned long _r22StatsUpdated = 0;
    Uint32 _r22StatsBatchTick = 0; // minimum 95ms between progressive batches
    std::string _r22StatsText;
    std::map<int, unsigned> _r22TileRisks;
    unsigned _r22SampleCount = 0;
    // Separate 1,024-trial H/B/M counters and 384-trial risk cache.
    unsigned _r22HitSamples = 0;
    unsigned _r22BlockedSamples = 0;
    unsigned _r22MissSamples = 0;
    unsigned _r22RiskSamples = 0;


	int getTerrainLevel(const Position& pos, int size) const;
	int getWallShade(TilePart part, Tile* tileFrot);
	int _iconHeight, _iconWidth, _messageColor;
	int _hostileBarColor, _neutralBarColor, _borderBarColor;
	const std::vector<Uint8> *_transparencies;
	bool _showObstacles;
	bool _showInfoOnCursor;
public:
	/// Creates a new map at the specified position and size.
	Map(Game* game, int width, int height, int x, int y, int visibleMapHeight);
	/// Cleans up the map.
	~Map();
	/// Initializes the map.
	void init();
	/// Handles timers.
	void think() override;
	/// Draws the surface.
	void draw() override;
	void refreshAIProgress(int progress);
	/// Sets the palette.
	void setPalette(const SDL_Color *colors, int firstcolor = 0, int ncolors = 256) override;
	void refreshHiddenMovementBackground();
	/// Special handling for mouse press.
	void mousePress(Action *action, State *state) override;
	/// Special handling for mouse release.
	void mouseRelease(Action *action, State *state) override;
	/// Special handling for mouse over
	void mouseOver(Action *action, State *state) override;
	/// Special handling for key presses.
	void keyboardPress(Action *action, State *state) override;
	/// Special handling for key releases.
	void keyboardRelease(Action *action, State *state) override;
	/// Rotates the tile frames 0-7
	void animate(bool redraw);
	/// Sets the battlescape selector position relative to mouse position.
	void setSelectorPosition(int mx, int my);
	/// Gets the currently selected position.
	void getSelectorPosition(Position *pos) const;

    /// Consume map click only when the preview is active. Never fires a weapon.

	/// Calculates the offset of a soldier, when it is walking in the middle of 2 tiles.
	UnitWalkingOffset calculateWalkingOffset(const BattleUnit *unit) const;
	/// Sets the 3D cursor type.
	void setCursorType(CursorType type, int size = 1);
	/// Gets the 3D cursor type.
	CursorType getCursorType() const;

	/// Sets projectile.
	void setProjectile(Projectile *projectile);
	/// Gets projectile.
	Projectile *getProjectile() const;
	/// Sets follow projectile flag.
	void setFollowProjectile(bool followProjectile) { _followProjectile = followProjectile; }
	/// Gets follow projectile flag.
	bool getFollowProjectile() const { return _followProjectile; }
	/// Gets alt pressed flag.
	bool isAltPressed() const { return _isAltPressed; }
	/// Gets ctrl pressed flag.
	bool isCtrlPressed() const { return _isCtrlPressed; }
	/// Add new vapor particle.
	void addVaporParticle(Position pos, Particle particle);
	/// Get all vapor for tile.
	Collections::Range<const Particle*> getVaporParticle(const Tile* tile, int topLayer) const;
	/// Gets explosion set.
	std::list<Explosion*> *getExplosions();

	/// Gets the pointer to the camera.
	Camera *getCamera();
	/// R40: mirrored visual camera; native world/tile coordinates never change.
	int getR41Rotation() const { return _r41Rotation; }
	/// Mouse-scrolls the camera.
	void scrollMouse();
	/// Keyboard-scrolls the camera.
	void scrollKey();
	/// fades in/out
	void fadeShade();
	/// Get waypoints vector.
	std::vector<Position> *getWaypoints();
	/// Set mouse-buttons' pressed state.
	void setButtonsPressed(Uint8 button, bool pressed);
	/// Sets the unitDying flag.
	void setUnitDying(bool flag);
	/// Refreshes the battlescape selector after scrolling.
	void refreshSelectorPosition();
	/// Special handling for updating map height.
	void setHeight(int height) override;
	/// Special handling for updating map width.
	void setWidth(int width) override;
	/// Get the vertical position of the hidden movement screen.
	int getMessageY() const;
	/// Get the icon height.
	int getIconHeight() const;
	/// Get the icon width.
	int getIconWidth() const;
	/// Convert a map position to a sound angle.
	int getSoundAngle(const Position& pos) const;
	/// Reset the camera smoothing bool.
	void resetCameraSmoothing();
	/// Set whether the screen should "flash" or not.
	void setBlastFlash(bool flash);
	/// Check if the screen is flashing this.
	bool getBlastFlash() const;
	/// Modify shade for fading
	int reShade(Tile *tile) const;
	int reShadeMinimap(int maxShade) const;
	/// toggle the night-vision mode
	void enableNightVision();
	void toggleNightVision();
	void toggleDebugVisionMode();
	void persistToggles();
	/// Resets obstacle markers.
	void resetObstacles();
	/// Enables obstacle markers.
	void enableObstacles();
	/// Disables obstacle markers.
	void disableObstacles();
};

}
