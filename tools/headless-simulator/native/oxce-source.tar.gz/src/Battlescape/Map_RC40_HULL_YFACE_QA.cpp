/*
 * Copyright 2010-2016 OpenXcom Developers.
 *
 * This file is part of OpenXcom.
 *
 * OpenXcom is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * OpenXcom is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with OpenXcom.  If not, see <http://www.gnu.org/licenses/>.
 */
#include "Map.h"
#include "../Engine/RNG.h"
#include <map>
#include <cmath>
#include <sstream>
#include <iomanip>
#include <stdint.h>
#include <set>
#include "Camera.h"
#include "UnitSprite.h"
#include "ItemSprite.h"
#include "Pathfinding.h"
#include "TileEngine.h"
#include "Projectile.h"
#include "ProjectileFlyBState.h"
#include "Explosion.h"
#include "BattlescapeState.h"
#include "Particle.h"
#include "../Mod/Mod.h"
#include "../Engine/Action.h"
#include "../Engine/SurfaceSet.h"
#include "../Engine/Timer.h"
#include "../Engine/Language.h"
#include "../Engine/Palette.h"
#include "../Engine/Game.h"
#include "../Engine/Screen.h"
#include "../Engine/Logger.h"
#include "../Engine/ShaderDraw.h"
#include "../Engine/ShaderMove.h"
#include "../Savegame/SavedBattleGame.h"
#include "../Savegame/Tile.h"
#include "../Savegame/BattleUnit.h"
#include "../Savegame/BattleItem.h"
#include "../Ufopaedia/Ufopaedia.h"
#include "../Mod/RuleItem.h"
#include "../Mod/RuleInterface.h"
#include "../Mod/MapDataSet.h"
#include "../Mod/MapData.h"
#include "../Mod/Armor.h"
#include "../Mod/RuleEnviroEffects.h"
#include "BattlescapeMessage.h"
#include "../Savegame/SavedGame.h"
#include "../Interface/NumberText.h"
#include "../Interface/Text.h"
#include "../fmath.h"


/*
  1) Map origin is top corner.
  2) X axis goes downright. (width of the map)
  3) Y axis goes downleft. (length of the map
  4) Z axis goes up (height of the map)

           0,0
            /\
           /  \
        y+ \  / x+
            \/

  Compass directions

         W  /\  N
           /  \
           \  /
         S  \/  E

  Unit directions

         6  /\  0
           /  \
           \  /
         4  \/  2

  Big units parts

            /\
           /0 \
          /\  /\
         /2 \/1 \
         \  /\  /
          \/3 \/
           \  /
            \/
 */

namespace OpenXcom
{
// Visual-only smoke clarity switch; never changes tile smoke or combat rules.
bool gHighVisibilitySmoke = false;
// R43_QA_ONLY: file-local pin, so the QA build does not rebuild other headers.
static bool r43QaPin=false;
static Position r43QaCenter;

/**
 * Sets up a map with the specified size and position.
 * @param game Pointer to the core game.
 * @param width Width in pixels.
 * @param height Height in pixels.
 * @param x X position in pixels.
 * @param y Y position in pixels.
 * @param visibleMapHeight Current visible map height.
 */
Map::Map(Game *game, int width, int height, int x, int y, int visibleMapHeight) : InteractiveSurface(width, height, x, y),
	_game(game), _isTFTD(false), _arrow(0), _anyIndicator(false), _isAltPressed(false), _isCtrlPressed(false),
	_selectorX(0), _selectorY(0), _mouseX(0), _mouseY(0), _cursorType(CT_NORMAL), _cursorSize(1), _animFrame(0),
	_projectile(0), _followProjectile(true), _projectileInFOV(false), _explosionInFOV(false), _launch(false), _visibleMapHeight(visibleMapHeight),
	_unitDying(false), _smoothingEngaged(false), _flashScreen(false), _bgColor(15), _projectileSet(0), _showObstacles(false), _showInfoOnCursor(false)
{
	// TODO: extract to a better place later
	for (const auto& pair : Options::mods)
	{
		if (pair.second)
		{
			if (pair.first == "xcom2")
			{
				_isTFTD = true;
				break;
			}
		}
	}

	_iconHeight = _game->getMod()->getInterface("battlescape")->getElement("icons")->h;
	_iconWidth = _game->getMod()->getInterface("battlescape")->getElement("icons")->w;
	_messageColor = _game->getMod()->getInterface("battlescape")->getElement("messageWindows")->color;

	auto* itf = _game->getMod()->getInterface("battlescape")->getElement("thinkingProgressBar");
	_hostileBarColor = itf->color;
	_neutralBarColor = itf->color2;
	_borderBarColor = itf->border;

	PathPreview previewSetting = Options::battleNewPreviewPath;
	_smoothCamera = Options::battleSmoothCamera;
	if (Options::traceAI)
	{
		// turn everything on because we want to see the markers.
		previewSetting = PATH_ARROW_TU;
	}
	_previewSettingArrows = previewSetting & PATH_ARROWS;
	_previewSettingTu     = previewSetting & PATH_TU_COST;
	_previewSettingEnergy = previewSetting & PATH_ENERGY_COST;

	_save = _game->getSavedGame()->getSavedBattle();
	if ((int)(_game->getMod()->getLUTs()->size()) > _save->getDepth())
	{
		_transparencies = &_game->getMod()->getLUTs()->at(_save->getDepth());
	}
	else
	{
		const static std::vector<Uint8> dummy;
		_transparencies = &dummy;
	}

	_spriteWidth = _game->getMod()->getSurfaceSet("BLANKS.PCK")->getFrame(0)->getWidth();
	_spriteHeight = _game->getMod()->getSurfaceSet("BLANKS.PCK")->getFrame(0)->getHeight();
	_message = new BattlescapeMessage(320, (visibleMapHeight < 200)? visibleMapHeight : 200, 0, 0);
	_message->setX(_game->getScreen()->getDX());
	_message->setY((visibleMapHeight - _message->getHeight()) / 2);
	_message->setTextColor(_messageColor);
	_camera = new Camera(_spriteWidth, _spriteHeight, _save->getMapSizeX(), _save->getMapSizeY(), _save->getMapSizeZ(), this, visibleMapHeight);
	_scrollMouseTimer = new Timer(SCROLL_INTERVAL);
	_scrollMouseTimer->onTimer((SurfaceHandler)&Map::scrollMouse);
	_scrollKeyTimer = new Timer(SCROLL_INTERVAL);
	_scrollKeyTimer->onTimer((SurfaceHandler)&Map::scrollKey);
	_camera->setScrollTimer(_scrollMouseTimer, _scrollKeyTimer);
	_obstacleTimer = new Timer(2500);
	_obstacleTimer->stop();
	_obstacleTimer->onTimer((SurfaceHandler)&Map::disableObstacles);

	_showInfoOnCursor = (Options::oxceShowAccuracyOnCrosshair == 1 && Options::battleUFOExtenderAccuracy) || Options::oxceShowAccuracyOnCrosshair == 2;
	_txtAccuracy = new Text(44, 18, 0, 0);
	_txtAccuracy->setSmall();
	_txtAccuracy->setPalette(_game->getScreen()->getPalette());
	_txtAccuracy->setHighContrast(true);
	_txtAccuracy->initText(_game->getMod()->getFont("FONT_BIG"), _game->getMod()->getFont("FONT_SMALL"), _game->getLanguage());
	_cacheActiveWeaponUfopediaArticleUnlocked = -1;
	_cacheIsCtrlPressed = false;
	_cacheCursorPosition = TileEngine::invalid;
	_cacheHasLOS = -1;

	_nightVisionOn = false;
	if (Options::oxceToggleNightVisionType == 2)
	{
		// persisted per campaign
		_nightVisionOn = _game->getSavedGame()->getToggleNightVision();
	}
	else if (Options::oxceToggleNightVisionType == 1)
	{
		// persisted per battle
		_nightVisionOn = _save->getToggleNightVision();
	}

	_debugVisionMode = 0;
	if (Options::oxceToggleBrightnessType == 2)
	{
		// persisted per campaign
		_debugVisionMode = _game->getSavedGame()->getToggleBrightness();
	}
	else if (Options::oxceToggleBrightnessType == 1)
	{
		// persisted per battle
		_debugVisionMode = _save->getToggleBrightness();
	}

	_save->setToggleNightVisionTemp(false);
	_save->setToggleNightVisionColorTemp(0);
	_save->setToggleBrightnessTemp(_debugVisionMode);

	_fadeShade = 16;
	_nvColor = 0;
	_fadeTimer = new Timer(FADE_INTERVAL);
	_fadeTimer->onTimer((SurfaceHandler)&Map::fadeShade);
	_fadeTimer->start();

	auto* enviro = _save->getEnviroEffects();
	if (enviro)
	{
		_bgColor = enviro->getMapBackgroundColor();
	}

	_stunIndicator = _game->getMod()->getSurface("FloorStunIndicator", false);
	_woundIndicator = _game->getMod()->getSurface("FloorWoundIndicator", false);
	_burnIndicator = _game->getMod()->getSurface("FloorBurnIndicator", false);
	_shockIndicator = _game->getMod()->getSurface("FloorShockIndicator", false);
	_anyIndicator = _stunIndicator || _woundIndicator || _burnIndicator || _shockIndicator;

	if (enviro)
	{
		if (!enviro->getMapShockIndicator().empty())
		{
			_shockIndicator = _game->getMod()->getSurface(enviro->getMapShockIndicator(), false);
		}
	}

	_vaporParticlesInit.resize(_camera->getMapSizeY() * _camera->getMapSizeX());
	_vaporParticles.resize(_camera->getMapSizeY() * _camera->getMapSizeX());
}

/**
 * Deletes the map.
 */
Map::~Map()
{
	delete _scrollMouseTimer;
	delete _scrollKeyTimer;
	delete _fadeTimer;
	delete _obstacleTimer;
	delete _arrow;
	delete _message;
	delete _camera;
	delete _txtAccuracy;
}

/**
 * Initializes the map.
 */
void Map::init()
{
	// load the tiny arrow into a surface
	int f = Palette::blockOffset(1); // yellow
	int b = 15; // black
	int pixels[81] = { 0, 0, b, b, b, b, b, 0, 0,
					   0, 0, b, f, f, f, b, 0, 0,
					   0, 0, b, f, f, f, b, 0, 0,
					   b, b, b, f, f, f, b, b, b,
					   b, f, f, f, f, f, f, f, b,
					   0, b, f, f, f, f, f, b, 0,
					   0, 0, b, f, f, f, b, 0, 0,
					   0, 0, 0, b, f, b, 0, 0, 0,
					   0, 0, 0, 0, b, 0, 0, 0, 0 };

	_arrow = new Surface(9, 9);
	_arrow->setPalette(this->getPalette());
	_arrow->lock();
	for (int y = 0; y < 9;++y)
		for (int x = 0; x < 9; ++x)
			_arrow->setPixel(x, y, pixels[x+(y*9)]);
	_arrow->unlock();

	_projectile = 0;
	if (_save->getDepth() == 0)
	{
		_projectileSet = _game->getMod()->getSurfaceSet("Projectiles");
	}
	else
	{
		_projectileSet = _game->getMod()->getSurfaceSet("UnderwaterProjectiles");
	}
}

/**
 * Keeps the animation timers running.
 */
void Map::think()
{
	_scrollMouseTimer->think(0, this);
	_scrollKeyTimer->think(0, this);
	_fadeTimer->think(0, this);
	_obstacleTimer->think(0, this);
    // R37 reaction-risk refresh belongs to the same F8-controlled overlay.
    if (_r22On && _save && _save->getSide() == FACTION_PLAYER &&
        _save->getSelectedUnit() &&
        SDL_GetTicks() - _r37ReactionCheckedAt >= 450U)
        _redraw = true;
    if (_r22On && _save && _save->getSide() == FACTION_PLAYER &&
        _cursorType != CT_NONE &&
        ((_r22StatsKey != 0 && _r22SampleCount < 1024U) ||
         (_r41ThrowSignature && _r41ThrowSamples < 256U) ||
         _r22HullWorkPending ||
         (_r29BlockPass < 3 && !_r29BlockCells.empty())))
    {
        const Uint32 tick = SDL_GetTicks();
        if (tick - _r22LastUiRefresh >= 90U)
        {
            _r22LastUiRefresh = tick;
            _redraw = true;
        }
    }
}

/**
 * Draws the whole map, part by part.
 */
void Map::draw()
{
	if (!_redraw)
	{
		return;
	}

	// normally we'd call for a Surface::draw();
	// but we don't want to clear the background with colour 0, which is transparent (aka black)
	// we use colour 15 because that actually corresponds to the colour we DO want in all variations of the xcom and tftd palettes.
	// Note: un-hardcoded the color from 15 to ruleset value, default 15
	_redraw = false;
	ShaderDrawFunc(
		[](Uint8& dest, Uint8 color)
		{
			dest = color;
		},
		ShaderSurface(this),
		ShaderScalar<Uint8>(Palette::blockOffset(0) + _bgColor)
	);

	Tile *t;

	_projectileInFOV = _save->getDebugMode();
	if (_projectile)
	{
		t = _save->getTile(_projectile->getPosition(0).toTile());
		if (_save->getSide() == FACTION_PLAYER || (t && t->getVisible()))
		{
			_projectileInFOV = true;
		}
	}
	_explosionInFOV = _save->getDebugMode();
	if (!_explosions.empty())
	{
		for (auto* explosion : _explosions)
		{
			if (explosion->isBig())
			{
				_explosionInFOV = true;
				break;
			}
			t = _save->getTile(explosion->getPosition().toTile());
			if (t && t->getVisible())
			{
				_explosionInFOV = true;
				break;
			}
		}
	}

	if ((_save->getSelectedUnit() && _save->getSelectedUnit()->getVisible()) || _unitDying || _save->getSide() == FACTION_PLAYER || _save->getDebugMode() || _projectileInFOV || _explosionInFOV)
	{
		drawTerrain(this);
	}
	else
	{
		_message->blit(this->getSurface());
	}


    // R41: world coordinates are projected by Camera; HUD text stays readable.
    // No framebuffer mirror, pixel copy, temporary image or per-frame allocation.
    if (_r22On && _save && _camera && _save->getSide() == FACTION_PLAYER && _save->getSelectedUnit())
        r22DrawOverlay();
    // R32/R37 render in screen coordinates and are never rotated.
    if (_r32EnemyCounts && _save && _save->getSide() == FACTION_PLAYER)
        r32DrawEnemyCounts();
    if (_r22On)
        r37DrawReactionHud();
    // A small fixed-position orientation label; no HUD row shifting.
    const char *r41ViewLabels[] = {"VIEW 0", "VIEW 90", "VIEW 180", "VIEW 270"};
    const int labelX = std::max(0, getWidth() - 82);
    drawRect(labelX,0,82,12,0);
    drawString(labelX+4,2,r41ViewLabels[_r41Rotation],160);
}

void Map::r40RememberHudRect(int, int, int, int) { }


// R37: tactical readout controlled by F8 together with R22/R29.
// When enabled, show movement, attacks, kneel/stand. Landing has no
// separate TU charge: it is a follow-up check to a fall, not a player action.
// Known enemy threshold is visibility-gated; hidden enemies remain unknown.
void Map::r37DrawReactionHud()
{
    if (!_r22On || !_save || _save->getSide() != FACTION_PLAYER ||
        !_save->getTileEngine() || getWidth() < 180 ||
        std::min(getHeight(), _visibleMapHeight) < 56)
        return;
    BattleUnit *actor = _save->getSelectedUnit();
    if (!actor || actor->getFaction() != FACTION_PLAYER ||
        actor->isOut() || !actor->getTile())
        return;

    BattleAction *native = _save->getBattleGame()
        ? _save->getBattleGame()->getCurrentAction() : nullptr;
    BattleItem *active = native && native->actor == actor ? native->weapon : nullptr;
    Pathfinding *preview = _save->getPathfinding();
    const bool pathPending = preview && preview->isPathPreviewed() &&
        !preview->getPath().empty();
    const BattleActionMove pathMove = pathPending && native && native->actor == actor
        ? native->getMoveType() : BAM_NORMAL;
    // The first click in Confirm Fire Mode stores a TARGET waypoint, but
    // native->target still refers to the previous action until the second
    // click. Use that pinned waypoint, never cursor hover, for shot risks.
    const bool awaitingShotConfirmation = !pathPending &&
        Options::battleConfirmFireMode && _cursorType != CT_NONE &&
        native && native->actor == actor && native->targeting &&
        !native->sprayTargeting && !native->waypoints.empty() &&
        native->weapon && (native->type == BA_SNAPSHOT ||
        native->type == BA_AIMEDSHOT || native->type == BA_AUTOSHOT);
    const Position pendingShotTarget = awaitingShotConfirmation ?
        native->waypoints.front() : Position(-1, -1, -1);
    Tile *pendingShotTile = awaitingShotConfirmation ?
        _save->getTile(pendingShotTarget) : nullptr;
    BattleUnit *knownShotTarget = pendingShotTile ? pendingShotTile->getUnit() : nullptr;
    if (knownShotTarget && (!knownShotTarget->getVisible() ||
        knownShotTarget->getFaction() == FACTION_PLAYER ||
        knownShotTarget->isOut() || knownShotTarget->isOutThresholdExceed()))
        knownShotTarget = nullptr;
    unsigned long long shotSignature = 0;
    if (awaitingShotConfirmation)
    {
        shotSignature = 1469598103934665603ULL;
        auto add = [&](int x) {
            shotSignature ^= static_cast<unsigned>(x);
            shotSignature *= 1099511628211ULL;
        };
        add(pendingShotTarget.x);
        add(pendingShotTarget.y);
        add(pendingShotTarget.z);
        add(static_cast<int>(native->type));
        add(knownShotTarget ? knownShotTarget->getId() : -1);
    }
    // A newly clicked or changed path must refresh immediately, not wait
    // for the 450ms background refresh timer. The base HUD stays unchanged.
    unsigned long long pathSignature = 0;
    if (pathPending)
    {
        pathSignature = 1469598103934665603ULL;
        auto add = [&](int x) {
            pathSignature ^= static_cast<unsigned>(x);
            pathSignature *= 1099511628211ULL;
        };
        add(actor->getPosition().x);
        add(actor->getPosition().y);
        add(actor->getPosition().z);
        add(static_cast<int>(pathMove));
        add(static_cast<int>(preview->getPath().size()));
        for (int dir : preview->getPath()) add(dir);
    }
    const Uint32 now = SDL_GetTicks();
    if (_r37ReactionRisks.size() != 10 ||
        _r38PathSignature != pathSignature ||
        _r39TargetSignature != shotSignature ||
        _r37ReactionActor != actor ||
        _r37ReactionActorTU != actor->getTimeUnits() ||
        _r37ReactionSelectedWeapon != active ||
        now - _r37ReactionCheckedAt >= 450U)
    {
        _r37ReactionActor = actor;
        _r37ReactionActorTU = actor->getTimeUnits();
        _r37ReactionSelectedWeapon = active;
        _r37ReactionCheckedAt = now;
        _r38PathSignature = pathSignature;
        _r38PathStepCount = 0;
        _r38PathFirstTU = -1;
        _r38PathFirstRisk = -1;
        _r38PathTotalTU = -1;
        _r38PathMaxRisk = -1;
        _r38PathMaxStep = 0;
        _r38PathMode = static_cast<int>(pathMove);
        _r39TargetSignature = shotSignature;
        _r39ShotTU = -1;
        _r39ShotRiskNow = -1;
        _r39ShotRiskIfHit = -1;

        const BattleActionType types[10] = {
            BA_WALK, BA_WALK, BA_WALK, BA_SNAPSHOT, BA_AIMEDSHOT,
            BA_AUTOSHOT, BA_THROW, BA_HIT, BA_LAUNCH, BA_KNEEL
        };
        std::vector<BattleAction> actions(10);
        std::vector<double> postScores(10, -1.0);
        _r37ReactionTUCosts.assign(10, -1);

        // Baseline rows always describe the actor's current facing direction.
        // A first-click path preview has a separate readout below and must
        // never silently change WLK/RUN/SNK costs or risk in this panel.
        Pathfinding *path = _save->getPathfinding();
        const int stepDir = actor->getDirection();

        Position target(-1, -1, -1);
        if (awaitingShotConfirmation && pendingShotTile)
            target = pendingShotTarget;
        else if (native && native->actor == actor && native->targeting &&
            _save->getTile(native->target))
            target = native->target;
        else if (_cursorType != CT_NONE)
        {
            Position hover;
            getSelectorPosition(&hover);
            Tile *hoverTile = _save->getTile(hover);
            if (hoverTile && hoverTile->isDiscovered(O_FLOOR))
                target = hover;
        }

        auto usable = [&](BattleItem *weapon, BattleActionType mode) {
            if (!weapon || !weapon->getRules() ||
                !_save->canUseWeapon(weapon, actor, false, mode))
                return false;
            if (mode == BA_THROW)
            {
                const RuleItem *rule = weapon->getRules();
                if (rule->isFixed() || rule->getCostThrow().Time <= 0)
                    return false;
            }
            else if (!weapon->getActionConf(mode) ||
                     !weapon->getAmmoForAction(mode))
                return false;
            BattleActionCost cost(mode, actor, weapon);
            return cost.Time > 0 && cost.haveTU();
        };

        auto findWeapon = [&](BattleActionType mode) -> BattleItem* {
            // Do not treat the contents of a backpack as ready-to-fire:
            // select an actual held/active weapon or built-in melee weapon.
            BattleItem *candidates[] = {
                active,
                mode == BA_HIT ? actor->getUtilityWeapon(BT_MELEE) : nullptr,
                actor->getMainHandWeapon(false),
                actor->getRightHandWeapon(),
                actor->getLeftHandWeapon(),
                mode == BA_HIT ? actor->getSpecialWeapon(BT_MELEE) : nullptr
            };
            for (BattleItem *weapon : candidates)
                if (usable(weapon, mode)) return weapon;
            return nullptr;
        };

        const int maxTU = actor->getBaseStats()->tu;
        const int currentTU = actor->getTimeUnits();
        for (int i = 0; i < 10; ++i)
        {
            BattleAction &a = actions[i];
            a.type = types[i];
            a.actor = actor;
            a.target = target;
            a.run = (i == 1);
            a.sneak = (i == 2);
            if (native && native->actor == actor && native->type == a.type &&
                i > 2 && native->targeting)
                a.skillRules = native->skillRules;

            if (maxTU <= 0 || currentTU <= 0)
            {
                a.type = BA_NONE;
                continue;
            }
            int spent = 0;
            if (i < 3)
            {
                if ((i == 1 && !actor->getArmor()->allowsRunning(actor->isSmallUnit())) ||
                    (i == 2 && !actor->getArmor()->allowsSneaking(actor->isSmallUnit())))
                {
                    a.type = BA_NONE;
                    continue;
                }
                const BattleActionMove moveType =
                    i == 1 ? BAM_RUN : (i == 2 ? BAM_SNEAK : BAM_NORMAL);
                // When the player has chosen a path, cost its next tile
                // using native terrain, stance and move-mode rules.
                // Otherwise use the currently facing adjacent tile; an
                // invalid direction falls back to the 4-TU flat step.
                spent = Pathfinding::DEFAULT_MOVE_COST;
                if (path && stepDir >= 0 && stepDir <= Pathfinding::DIR_DOWN)
                {
                    const PathfindingStep cost = path->getTUCost(
                        actor->getPosition(), stepDir, actor, nullptr, moveType);
                    if (cost.cost.time > 0 &&
                        cost.cost.time < Pathfinding::INVALID_MOVE_COST)
                        spent = cost.cost.time;
                }
            }
            else if (i == 9)
            {
                // The kneel key toggles both kneeling and standing. The
                // native kneel() path spends the change cost BEFORE it calls
                // checkReactionFire() (BattlescapeGame.cpp).
                if (!actor->getArmor()->allowsKneeling(actor->getType() == "SOLDIER") ||
                    actor->isFloating())
                {
                    a.type = BA_NONE;
                    continue;
                }
                spent = actor->getKneelChangeCost();
            }
            else
            {
                a.weapon = findWeapon(a.type);
                if (!a.weapon)
                {
                    a.type = BA_NONE;
                    continue;
                }
                const BattleActionCost cost(a.type, actor, a.weapon);
                spent = cost.Time;
            }
            if (spent <= 0 || spent > currentTU)
            {
                a.type = BA_NONE;
                continue;
            }
            _r37ReactionTUCosts[i] = spent;
            postScores[i] =
                static_cast<double>(actor->getBaseStats()->reactions) *
                static_cast<double>(currentTU - spent) /
                static_cast<double>(maxTU);
        }
        _r37ReactionRisks = _save->getTileEngine()->
            r37VisibleReactionChances(actor, actions, postScores,
                                      &_r37VisibleEnemyThreshold);

        // R39: conditional reaction AFTER a confirmed shot hit its currently
        // visible, alive target. A successful hit records wasHitBy; unlike
        // the normal branch, it bypasses that enemy's initial facing sector.
        // No damage, turn, RNG advancement or actor position is simulated.
        // The percentage is CONDITIONAL on hit + enemy surviving the burst;
        // it is NOT a made-up shot-hit probability.
        if (awaitingShotConfirmation && knownShotTarget && maxTU > 0 &&
            native && native->weapon &&
            _save->canUseWeapon(native->weapon, actor, false, native->type) &&
            native->weapon->getAmmoForAction(native->type))
        {
            BattleAction selected = *native;
            selected.actor = actor;
            selected.target = pendingShotTarget;
            const BattleActionCost cost(selected.type, actor, selected.weapon);
            if (cost.Time > 0 && cost.Time <= currentTU)
            {
                _r39ShotTU = cost.Time;
                const double postScore = double(actor->getBaseStats()->reactions) *
                    double(currentTU - cost.Time) / double(maxTU);
                const std::vector<BattleAction> oneAction(1, selected);
                const std::vector<double> oneScore(1, postScore);
                const std::vector<int> before = _save->getTileEngine()->
                    r37VisibleReactionChances(actor, oneAction, oneScore);
                const std::vector<int> afterHit = _save->getTileEngine()->
                    r37VisibleReactionChances(actor, oneAction, oneScore,
                                               nullptr, knownShotTarget);
                if (!before.empty()) _r39ShotRiskNow = before.front();
                if (!afterHit.empty()) _r39ShotRiskIfHit = afterHit.front();
            }
        }

        if (pathPending && path && path->getStartDirection() >= 0)
        {
            std::vector<Position> positions;
            std::vector<int> spentTU;
            Position pos = actor->getPosition();
            int totalTU = actor->isKneeled() ? actor->getKneelUpCost() : 0;
            int energy = actor->getEnergy();
            const int firstDir = path->getStartDirection();
            if (actor->getArmor()->getTurnBeforeFirstStep() &&
                firstDir != actor->getDirection() && firstDir < Pathfinding::DIR_UP)
            {
                int turns = std::abs(actor->getDirection() - firstDir);
                if (turns > 4) turns = 8 - turns;
                totalTU += turns * actor->getTurnCost();
            }
            for (auto it = path->getPath().rbegin();
                 it != path->getPath().rend() && positions.size() < 64U; ++it)
            {
                const PathfindingStep step = path->getTUCost(
                    pos, *it, actor, nullptr, pathMove);
                if (step.cost.time < 0 ||
                    step.cost.time >= Pathfinding::INVALID_MOVE_COST ||
                    !_save->getTile(step.pos))
                    break;
                if (positions.empty()) _r38PathFirstTU = step.cost.time;
                totalTU += step.cost.time;
                energy -= step.cost.energy;
                if (totalTU > currentTU || energy < 0) break;
                pos = step.pos;
                positions.push_back(pos);
                spentTU.push_back(totalTU);
            }
            if (!positions.empty())
            {
                const std::vector<int> chances = _save->getTileEngine()->
                    r38VisiblePathReactionChances(actor, positions, spentTU, pathMove);
                _r38PathStepCount = static_cast<int>(positions.size());
                _r38PathTotalTU = spentTU.back();
                _r38PathFirstRisk = chances.front();
                for (size_t i = 0; i < chances.size(); ++i)
                {
                    if (chances[i] > _r38PathMaxRisk)
                    {
                        _r38PathMaxRisk = chances[i];
                        _r38PathMaxStep = static_cast<int>(i + 1);
                    }
                }
            }
        }
    }

    const SDL_Color *palette = getPalette();
    if (!palette) return;
    int dark = 1, light = 15;
    int minLum = 2147483647, maxLum = -1;
    for (int c = 1; c < 256; ++c)
    {
        const int lum = 2126 * int(palette[c].r) +
                        7152 * int(palette[c].g) + 722 * int(palette[c].b);
        if (lum < minLum) { minLum = lum; dark = c; }
        if (lum > maxLum) { maxLum = lum; light = c; }
    }
    // F8-only, compact two-column readout. NEXT is ADDITIONAL TU to spend
    // to reach the visible enemy's reaction-score threshold.
    // O = 0%, X = 100%, 1-99% = intermediate scripted chance;
    // -- = unavailable. This uses only known enemies, never hidden ones.
    const char *names[10] = {
        "WLK", "RUN", "SNK", "SNP", "AIM", "AUT",
        "THR", "MEL", "LCH", actor->isKneeled() ? "STD" : "KNL"
    };
    // Six native-action rows have a fixed bottom-anchored location. Any
    // first-click preview goes ABOVE NEXT, never shifting these columns.
    std::string rows[9];
    int rowCount = 6;
    {
        std::ostringstream s;
        s << "NEXT ";
        if (_r37VisibleEnemyThreshold < 0.0)
            s << "--";
        else
        {
            const double ownScore = actor->getReactionScore();
            const int baseReactions = actor->getBaseStats()->reactions;
            const int maxTU = actor->getBaseStats()->tu;
            const int needed = ownScore <= _r37VisibleEnemyThreshold ? 0 :
                baseReactions > 0 && maxTU > 0 ?
                static_cast<int>(std::ceil(
                    (ownScore - _r37VisibleEnemyThreshold) * maxTU /
                    double(baseReactions) - 1e-9)) : 0;
            s << needed << "TU";
        }
        rows[0] = s.str();
    }
    std::string actionText[10];
    for (int i = 0; i < 10; ++i)
    {
        std::ostringstream s;
        const int risk = i < int(_r37ReactionRisks.size()) ?
            _r37ReactionRisks[i] : -1;
        const int tuCost = i < int(_r37ReactionTUCosts.size()) ?
            _r37ReactionTUCosts[i] : -1;
        s << std::left << std::setw(4) << names[i] << std::right;
        if (risk < 0 || tuCost < 0)
            s << std::setw(3) << "--" << ' ' << std::setw(4) << "--";
        else
        {
            s << std::setw(3) << tuCost << ' ';
            if (risk == 0)
                s << std::setw(4) << 'O';
            else if (risk == 100)
                s << std::setw(4) << 'X';
            else
                s << std::setw(3) << risk << '%';
        }
        actionText[i] = s.str();
    }
    for (int line = 0; line < 5; ++line)
        rows[line + 1] = actionText[line * 2] + "   " + actionText[line * 2 + 1];

    auto riskLabel = [](int risk) {
        if (risk < 0) return std::string("--");
        if (risk == 0) return std::string("O");
        if (risk == 100) return std::string("X");
        return std::to_string(risk) + "%";
    };
    // The first click fixes the target and reveals the risk conditional on
    // the known target surviving a direct hit. NOW is the existing state;
    // HIT is the native wasHitBy reaction override AFTER actual damage.
    if (awaitingShotConfirmation && knownShotTarget && _r39ShotTU > 0)
    {
        const char *modeName = native->type == BA_AUTOSHOT ? "AUT" :
            native->type == BA_AIMEDSHOT ? "AIM" : "SNP";
        std::ostringstream selected;
        selected << "TGT " << modeName << ' ' << _r39ShotTU << "TU "
                 << "NOW " << riskLabel(_r39ShotRiskNow) << " HIT+LIVE "
                 << riskLabel(_r39ShotRiskIfHit);
        rows[rowCount++] = selected.str();
    }
    // After the FIRST movement click, show only the selected path.
    // P1 is its next tile; MAX is the maximum ONE-STEP fire probability.
    if (pathPending)
    {
        const char *modeName = pathMove == BAM_RUN ? "RUN" :
            pathMove == BAM_SNEAK ? "SNK" :
            pathMove == BAM_STRAFE ? "STR" : "WLK";
        std::ostringstream first;
        first << "P1  " << std::left << std::setw(4) << modeName
              << std::right << std::setw(3) << (_r38PathFirstTU >= 0 ?
                  std::to_string(_r38PathFirstTU) : std::string("--"))
              << ' ' << std::setw(4) << riskLabel(_r38PathFirstRisk);
        rows[rowCount++] = first.str();
        if (_r38PathStepCount > 1)
        {
            const bool complete = static_cast<size_t>(_r38PathStepCount) ==
                preview->getPath().size();
            std::ostringstream entire;
            entire << (complete ? "PTH " : "RCH ")
                   << _r38PathTotalTU << "TU MAX "
                   << riskLabel(_r38PathMaxRisk) << " @" << _r38PathMaxStep;
            rows[rowCount++] = entire.str();
        }
    }
    size_t widthChars = 0;
    for (int i = 0; i < rowCount; ++i)
        widthChars = std::max(widthChars, rows[i].size());
    const int panelWidth = std::min(getWidth(),
        5 + static_cast<int>(widthChars) * 8);
    const int baseRows = 6;
    const int bottom = std::min(getHeight(), _visibleMapHeight);
    const int baseHeight = baseRows * 10 + 3;
    const int baseY = std::max(0, bottom - baseHeight);
    // FIXED native rows; their Y never changes when a preview appears.
    drawRect(0, baseY, panelWidth, baseHeight, static_cast<Uint8>(dark));
    for (int i = 0; i < baseRows; ++i)
        drawString(2, baseY + 2 + i * 10, rows[i].c_str(),
            static_cast<Uint8>(light));
    // Additional information grows upwards into unused map space.
    const int extraRows = rowCount - baseRows;
    if (extraRows > 0 && baseY > 0)
    {
        const int extraHeight = std::min(baseY, extraRows * 10);
        const int extraY = baseY - extraHeight;
        drawRect(0, extraY, panelWidth, extraHeight, static_cast<Uint8>(dark));
        for (int i = 0; i < extraRows; ++i)
        {
            const int textY = extraY + 1 + i * 10;
            if (textY + 9 <= baseY)
                drawString(2, textY, rows[baseRows + i].c_str(),
                    static_cast<Uint8>(light));
        }
    }
}

// R32: the hypothetical shooter stands on the actual raised voxel floor,
// not at the lower tile's nominal z=0. Match native stair-top adjustment
// without calculating a path or altering a live unit's position.
Position Map::r32VirtualStandPosition(const Position &hover, const BattleUnit *actor) const
{
    (void)actor;
    if (!_save || !_save->getTile(hover)) return hover;
    Position pos = hover;
    // Partial (-8/-16) stairs remain on the SAME map level. Their
    // height belongs to the floor's voxel Z, never a forced Z+1 tile.
    while (pos.z + 1 < _save->getMapSizeZ())
    {
        Tile *tile = _save->getTile(pos);
        if (!tile || tile->getTerrainLevel() != -24) break;
        Tile *top = _save->getTile(Position(pos.x,pos.y,pos.z+1));
        if (!top || top->hasNoFloor(_save)) break;
        ++pos.z;
    }
    return pos;
}

// R32: the engine's native getOriginVoxel clamps tall occupants to a lower
// storey when a roof exists. This is correct for REAL actors but wrong for
// a hypothetical actor previewed on a -8/-16 raised stair tile. Keep the
// native direction/XY offset and raise only the hypothetical voxel origin.
Position Map::r32VirtualMuzzle(BattleAction &action, Tile *sourceTile,
    int stanceDelta, bool hypothetical) const
{
    Position muzzle = _save->getTileEngine()->getOriginVoxel(action,sourceTile);
    muzzle.z += stanceDelta;
    if (hypothetical && sourceTile && action.actor &&
        sourceTile->getTerrainLevel() < 0)
    {
        const Position source = sourceTile->getPosition();
        const int desiredZ = source.z * 24 - sourceTile->getTerrainLevel() +
            action.actor->getHeight() + action.actor->getFloatHeight() +
            stanceDelta - (action.type == BA_THROW ? 3 : 4);
        muzzle.z = static_cast<Sint16>(std::max<int>(muzzle.z, desiredZ));
    }
    return muzzle;
}

// Explicit census. This intentionally includes unseen enemies because it is
// only requested by Shift+F8; it never alters visibility or tactical AI.
// FIGHT includes INTENT (units still able to fight despite a past surrender wish).
// SURRENDERING only counts capturable enemies already flagged as surrendering
// by the battle engine. INTENT requires a surrender wish without an active
// surrender flag, and remains a subset of FIGHT rather than a separate bucket.
void Map::r32DrawEnemyCounts()
{
    if (!_save || getHeight() < 30 || getWidth() < 110) return;
    int fighting = 0, intent = 0, surrendered = 0, knockedOut = 0;
    int remaining = 0, approximateStart = 0;
    std::vector<std::string> activeEnemyCoordinates;
    for (const BattleUnit *unit : *_save->getUnits())
    {
        if (!unit || unit->getOriginalFaction() != FACTION_HOSTILE)
            continue;
        if (!unit->isIgnored()) ++approximateStart;
        if (unit->isIgnored() || unit->getStatus() == STATUS_DEAD)
            continue;
        ++remaining;
        if (unit->getStatus() == STATUS_UNCONSCIOUS || unit->isOutThresholdExceed())
        {
            ++knockedOut;
            continue;
        }
        // Mirror tallyUnits() without invoking isSurrendering(bu), which would
        // change the tactical state merely because the player opened the HUD.
        const bool psiCaptured = Options::allowPsionicCapture &&
            unit->getFaction() == FACTION_PLAYER && unit->getCapturable();
        if (unit->isSurrendering() && unit->getCapturable() && !psiCaptured)
        {
            ++surrendered;
            continue;
        }
        if (unit->getFaction() == FACTION_HOSTILE && !unit->isOut())
        {
            ++fighting;
            const Position &pos = unit->getPosition();
            std::ostringstream coord;
            coord << "XYZ " << pos.x << "," << pos.y << "," << pos.z;
            activeEnemyCoordinates.push_back(coord.str());
            if (unit->wantsToSurrender() && !unit->isSurrendering())
                ++intent;
        }
    }
    const int initial = _save->getR32InitialHostiles();
    const SDL_Color *pal = getPalette();
    if (!pal) return;
    int darkest = 1, brightest = 15, darkestLum = 2147483647, brightestLum = -1;
    for (int i = 1; i < 256; ++i)
    {
        const int lum = 2126*int(pal[i].r) + 7152*int(pal[i].g) + 722*int(pal[i].b);
        if (lum < darkestLum) { darkestLum = lum; darkest = i; }
        if (lum > brightestLum) { brightestLum = lum; brightest = i; }
    }
    // Six figures in two compact columns (three text rows). INTENT is an
    // informational subset of FIGHT, so it is never added to TOTAL.
    std::ostringstream fightText, intentText, surrenderText, koText, totalText, startText;
    fightText << "FIGHT " << fighting;
    intentText << "INTENT " << intent;
    surrenderText << "SURRENDERING " << surrendered;
    koText << "KO " << knockedOut;
    totalText << "TOTAL " << remaining;
    startText << "START ";
    if (initial >= 0) startText << initial;
    else startText << '~' << approximateStart; // No precise starting count in older saves.
    const std::string fight = fightText.str(), intention = intentText.str();
    const std::string surrender = surrenderText.str(), ko = koText.str();
    const std::string total = totalText.str(), start = startText.str();
    // SDL bitmap characters are 8 pixels wide. Size each column to the data,
    // so large counts never spill into the adjoining column or off screen.
    const int leftWidth = 6 + 8 * std::max(int(total.size()),
        std::max(int(fight.size()), int(intention.size())));
    const int rightWidth = 4 + 8 * std::max(int(start.size()),
        std::max(int(surrender.size()), int(ko.size())));
    const int panelWidth = std::min(getWidth(), leftWidth + rightWidth);
    // Reveal exact locations only after at most two active hostiles remain.
    // KO/dead enemies are deliberately excluded; keep the existing totals intact.
    const bool showCoordinates = fighting > 0 && fighting <= 2;
    const int panelHeight = 30 + (showCoordinates ? 9 * fighting : 0);
    const int x = std::max(0, getWidth() - panelWidth);
    // Previous row began at y=32. Move down two 11px text lines.
    // When the expanded 20-type resistance table is visible, put counts
    // after its final hint row (y=104..113) rather than painting over it.
    const int expandedTableBottom = 27 + ((DAMAGE_TYPES + 2) / 3) * 11 + 10;
    const int preferredY = (_r22On && _r30FullResists) ? expandedTableBottom : 54;
    const int y = std::min(preferredY, std::max(0, _visibleMapHeight - panelHeight));
    const int secondX = x + leftWidth;
    drawRect(x, y, panelWidth, panelHeight, Uint8(darkest));
    drawString(x+2, y+1, fight.c_str(), Uint8(brightest));
    drawString(secondX, y+1, surrender.c_str(), Uint8(brightest));
    drawString(x+2, y+10, intention.c_str(), Uint8(brightest));
    drawString(secondX, y+10, ko.c_str(), Uint8(brightest));
    drawString(x+2, y+19, total.c_str(), Uint8(brightest));
    drawString(secondX, y+19, start.c_str(), Uint8(brightest));
    if (showCoordinates)
    {
        for (size_t i = 0; i < activeEnemyCoordinates.size(); ++i)
            drawString(x+2, y+28+int(i)*9, activeEnemyCoordinates[i].c_str(), Uint8(brightest));
    }
}

// LOSLOF_R22_RECON_PREVIEW.
// This preview is not a replacement for the R21 ballistics, pellet or risk engine.
// R22 HUD: contrast backplate, 5-letter stance, fixed 42px stats origin.
// Only draws; leaves targeting state and input untouched.
void Map::r22DrawContrastHud(const char *stance, bool simulated,
                             const std::string &tail)
{
    const SDL_Color *palette=getPalette();
    if (!palette) return;
    Uint8 dark=1, bright=15, accent=15;
    int lowest=2147483647, highest=-1, warmest=-1;
    // Palette index zero can be transparent; choose from currently drawable
    // colors rather than assuming palette slots 73/160 are always visible.
    for (int i=1;i<256;++i)
    {
        const SDL_Color &rgb=palette[i];
        const int lum=2126*int(rgb.r)+7152*int(rgb.g)+722*int(rgb.b);
        if (lum<lowest) { lowest=lum; dark=static_cast<Uint8>(i); }
        if (lum>highest) { highest=lum; bright=static_cast<Uint8>(i); }
        if (int(rgb.r)>int(rgb.b)+35 && int(rgb.g)>int(rgb.b)+20
            && rgb.r>110 && rgb.g>90 && lum>warmest)
        {
            warmest=lum;
            accent=static_cast<Uint8>(i);
        }
    }
    if (warmest<highest*65/100) accent=bright;
    // SDL_gfx bitmap text is 8 pixels per glyph. Both STAND and KNEEL
    // occupy 5 glyphs / 40 pixels; right-hand data always starts at x=42.
    const int width=std::min(getWidth(),44+int(tail.size())*8);
    if (width<2) return;
    drawRect(0,0,width,12,dark);
    drawLine(0,11,width-1,11,bright);
    // A tiny fixed bar also marks SIM when the palette lacks a distinct hue.
    if (simulated) drawRect(0,1,2,10,accent);
    drawString(2,2,stance,simulated ? accent : bright);
    drawString(42,2,tail.c_str(),bright);
    r40RememberHudRect(0, 0, width, 12);
}

void Map::r22DrawOverlay()
{
    BattleUnit *soldier = _save->getSelectedUnit();
    if (!soldier || !_save->getTileEngine() || !_camera)
        return;
    BattleAction *native = _save->getBattleGame() ?
        _save->getBattleGame()->getCurrentAction() : nullptr;
    // A hidden cursor means a projectile is firing, a turn is resolving,
    // or another native action owns input. Retire stale preview caches first.
    const bool nativeAim = _cursorType != CT_NONE && native &&
        native->targeting && native->weapon &&
        native->actor == soldier &&
        (native->type == BA_SNAPSHOT || native->type == BA_AIMEDSHOT ||
         native->type == BA_AUTOSHOT || native->type == BA_THROW);
    if (_r22StanceActor != soldier)
    {
        _r22StanceActor = soldier;
        _r22StanceOverride = false;
        _r22Kneel = soldier->isKneeled();
        _r22StatsKey = 0;
        _r22HullHash = 0;
    }
    // Movement remains native. Keep planned LOS only during an actual path
    // preview; do NOT calculate gun rays or probabilities on a move cursor.
    if (!nativeAim)
    {
        _r22StanceOverride = false;
        _r22StatsKey = 0;
        _r22ThrowCacheKey = 0;
        _r22StatsText.clear();
        _r22TileRisks.clear();
        _r22SampleCount = 0;
        _r22HullWorkPending = false;
        r29ClearBlockGrid();
        if (_cursorType == CT_NONE) return;
        Pathfinding *finder = _save->getPathfinding();
        if (finder && finder->isPathPreviewed())
        {
            const Position planned = r22PlannedPosition(soldier);
            Tile *tile = _save->getTile(planned);
            if (tile)
            {
                const Position eye(planned.x*16+8, planned.y*16+8,
                    planned.z*24-tile->getTerrainLevel()+
                    soldier->getHeight()+soldier->getFloatHeight()-1);
                r22DrawVisibilityHull(planned,eye,_camera->getViewLevel());
            }
        }
        return;
    }
    Position cursor;
    getSelectorPosition(&cursor);
    // Clicks are owned by native primaryAction(), including movement and
    // optional battleConfirmFireMode's first target-confirmation click.
    // A spray's first waypoint is also a pinned target. The old check
    // explicitly excluded it and prevented the range grid from appearing.
    const bool confirmedTarget = (Options::battleConfirmFireMode ||
        native->type == BA_THROW || native->sprayTargeting) &&
        !native->waypoints.empty();
    // A first-click cursor still resting on its target must retain the HUD:
    // fall back to the true soldier position rather than trying a zero-length ray.
    const Position target = confirmedTarget ? native->waypoints.front() : cursor;
    // R42: first-click target confirmation previews the path FROM the
    // current hover tile TO the pinned target, for throws as for shots.
    // If the cursor still rests on the pinned target, keep the actor's
    // actual origin instead of drawing a zero-length hypothetical throw.
    // This is a read-only origin; the second click still uses the live actor.
    const Position source = confirmedTarget
        ? (cursor != target ? r32VirtualStandPosition(cursor, soldier)
                            : soldier->getPosition())
        : r22PlannedPosition(soldier);

    Tile *startTile = _save->getTile(source);
    Tile *targetTile = _save->getTile(target);
    if (!startTile || !targetTile) return;
    // Preview actor replaces an existing ally at the SOURCE tile only.
    // Never alter either BattleUnit, its tile, or the saved game.
    BattleUnit *previewVacatedUnit = source != soldier->getPosition() ?
        startTile->getOverlappingUnit(_save) : nullptr;
    if (previewVacatedUnit &&
        (previewVacatedUnit == soldier ||
         previewVacatedUnit->getFaction() != soldier->getFaction()))
        previewVacatedUnit = nullptr;
    const int viewZ = _camera->getViewLevel();
    const int width = _save->getMapSizeX(), length = _save->getMapSizeY();
    // LOSLOF_R22_HARDENED_VISIBLE_ONLY: native armor-specific stance height.
    int stanceDelta = (_r22StanceOverride && (_r22Kneel != soldier->isKneeled())) ?
        ((_r22Kneel ? soldier->getKneelHeight() : soldier->getStandHeight())
         - soldier->getHeight()) : 0;
    const Position eye(source.x*16+8, source.y*16+8,
        source.z*24 - startTile->getTerrainLevel() +
        soldier->getHeight() + soldier->getFloatHeight() - 1 + stanceDelta);
    const BattleUnit *targetUnit = targetTile->getUnit();
    int aimHeight = targetUnit && targetUnit->getVisible() ?
        std::max(3, targetUnit->getHeight()/2) : 12;
    Position goal(target.x*16+8, target.y*16+8,
        target.z*24-targetTile->getTerrainLevel()+aimHeight);
    std::vector<Position> vision;
    _save->getTileEngine()->calculateLineVoxel(eye, goal, true, &vision, soldier, nullptr, true);

    // Tile-centred floor projection. Exactly one pixel per visited tile.
    std::set<int> seen;
    for (const Position& voxel : vision)
    {
        if (voxel.x < 0 || voxel.y < 0 || voxel.z < 0) continue;
        const int tx=voxel.x/16, ty=voxel.y/16, tz=voxel.z/24;
        if (tx>=width || ty>=length || tz>=_save->getMapSizeZ() || tz>viewZ) continue;
        if (!seen.insert((tz*length+ty)*width+tx).second) continue;
        Tile *t = _save->getTile(Position(tx,ty,tz));
        if (!t || !t->isDiscovered(O_FLOOR)) continue;
        Position xy;
        _camera->convertVoxelToScreen(Position(tx*16+8,ty*16+8,
            tz*24-t->getTerrainLevel()+1), &xy);
        setPixel(xy.x,xy.y,48);
    }

    r22DrawVisibilityHull(source,eye,viewZ);

    const BattleAction *selectedAction=_save->getBattleGame() ?
        _save->getBattleGame()->getCurrentAction() : nullptr;
    if(selectedAction && selectedAction->actor==soldier &&
       selectedAction->type==BA_THROW)
    {
        // R32: preview originates from the ACTUAL 1/3 or 2/3 stair
        // landing elevation, never from the tile's z*24 base plane.
        const Position foot(source.x * 16, source.y * 16,
            source.z * 24 - startTile->getTerrainLevel() + 1);
        const Position corners[] = {foot, foot + Position(16,0,0),
            foot + Position(16,16,0), foot + Position(0,16,0)};
        if (source.z <= viewZ)
        {
            Position pixel[4];
            for (int i = 0; i < 4; ++i)
                _camera->convertVoxelToScreen(corners[i], &pixel[i]);
            for (int i = 0; i < 4; ++i)
                drawLine(pixel[i].x, pixel[i].y,
                    pixel[(i+1)%4].x, pixel[(i+1)%4].y, 160);
        }
        r22DrawThrowPreview(source,target,startTile,targetTile);
        if (confirmedTarget) r29DrawTargetBlockGrid(soldier, native, target);
        else r29ClearBlockGrid();
        return;
    }
    BattleAction testAction = *native; // read-only action snapshot
    testAction.actor = soldier;
    testAction.target = target;

    // LOSLOF_R22_NATIVE_BALLISTIC_AIM_20261013
    // Reuse native OXCE canTargetUnit's multi-voxel scan on a visible enemy.
    // This matters most when the centre is hidden but a head/side is exposed.
    // Off-centre firing tries CENTRE, LEFT, RIGHT in the same order as OXCE.
    // potentialUnit MUST be null for a REAL visible enemy: passing aimUnit
    // marks the target hypothetical and incorrectly accepts empty rays.
    // Never touch native BattleAction or mark obstacles on the real map.
    // The user may have locked a visible 2x2 unit by its overlapping tile.
    // Resolve its owning tile for the engine's voxel scanner. Critically,
    // this ray probe must NOT gate H/B/M: it can find no straight line
    // while the probabilistic simulation still needs to show blockage.
    BattleUnit *aimUnit=targetTile->getOverlappingUnit(_save);
    Tile *aimRootTile=aimUnit ? _save->getTile(aimUnit->getPosition()) : nullptr;
    if (aimUnit && aimRootTile && aimUnit->getVisible() && aimUnit!=soldier &&
        !testAction.sprayTargeting &&
        !(Options::forceFire && _save->isCtrlPressed(true)) &&
        (targetTile->isDiscovered(O_FLOOR) || aimUnit->getVisible()))
    {
        unsigned long long aimKey=1469598103934665603ULL;
        auto aimMix=[&](unsigned long long v) {
            aimKey^=v; aimKey*=1099511628211ULL;
        };
        for(int v : std::initializer_list<int>{
            soldier->getId(),source.x,source.y,source.z,
            target.x,target.y,target.z,stanceDelta,
            (int)testAction.type, (int)Options::oxceEnableOffCentreShooting,
            aimUnit->getPosition().x,aimUnit->getPosition().y,
            aimUnit->getPosition().z,aimUnit->getHeight()})
            aimMix(static_cast<unsigned>(v));
        aimMix(static_cast<unsigned long long>(reinterpret_cast<uintptr_t>(aimUnit)));
        aimMix(static_cast<unsigned long long>(reinterpret_cast<uintptr_t>(previewVacatedUnit)));
        aimMix(static_cast<unsigned long long>(reinterpret_cast<uintptr_t>(native->weapon)));
        const Uint32 aimNow=SDL_GetTicks();
        if (aimKey != _r22NativeAimKey ||
            aimNow-_r22NativeAimCheckedAt>900U)
        {
            _r22NativeAimFound=false;
            _r22NativeAimSide=0;
            _r22NativeAimGoal=goal;
            const BattleActionOrigin sides[3]={
                BattleActionOrigin::CENTRE,BattleActionOrigin::LEFT,
                BattleActionOrigin::RIGHT};
            for(int side=0;side<3;++side)
            {
                if (side>0 && !Options::oxceEnableOffCentreShooting) break;
                BattleAction testSide=testAction;
                testSide.relativeOrigin=sides[side];
                Position candidateOrigin=r32VirtualMuzzle(testSide,startTile,
                    stanceDelta,source!=soldier->getPosition());
                Position candidateGoal=goal;
                if (_save->getTileEngine()->canTargetUnit(
                    &candidateOrigin,aimRootTile,&candidateGoal,soldier,
                    false,nullptr,true,previewVacatedUnit))
                {
                    _r22NativeAimFound=true;
                    _r22NativeAimSide=side;
                    _r22NativeAimGoal=candidateGoal;
                    break;
                }
            }
            _r22NativeAimKey=aimKey;
            _r22NativeAimCheckedAt=aimNow;
        }
        if (_r22NativeAimFound)
        {
            goal=_r22NativeAimGoal;
            testAction.relativeOrigin=
                _r22NativeAimSide==1 ? BattleActionOrigin::LEFT :
                _r22NativeAimSide==2 ? BattleActionOrigin::RIGHT :
                BattleActionOrigin::CENTRE;
        }
        else
        {
            // No direct exposed voxel from this VIRTUAL firing tile.
            // Keep the default geometric aim point and sample native
            // trajectories. B may reach 100%, but never erase the HUD.
            testAction.relativeOrigin=BattleActionOrigin::CENTRE;
        }
    }
    Position muzzle = r32VirtualMuzzle(testAction,startTile,stanceDelta,
        source!=soldier->getPosition());
    std::vector<Position> bullet;
    VoxelType collision = _save->getTileEngine()->calculateLineVoxel(muzzle,goal,true,&bullet,soldier,nullptr,true,previewVacatedUnit);
    seen.clear();
    for (const Position& voxel : bullet)
    {
        if (voxel.x < 0 || voxel.y < 0 || voxel.z < 0) continue;
        const int tx=voxel.x/16, ty=voxel.y/16, tz=voxel.z/24;
        if (tx>=width || ty>=length || tz>=_save->getMapSizeZ() || tz>viewZ) continue;
        if (!seen.insert((tz*length+ty)*width+tx).second) continue;
        Tile *t = _save->getTile(Position(tx,ty,tz));
        if (!t || !t->isDiscovered(O_FLOOR)) continue;
        Position xy;
        _camera->convertVoxelToScreen(Position(tx*16+8,ty*16+8,
            tz*24-t->getTerrainLevel()+1), &xy);
        setPixel(xy.x+1,xy.y,73);
    }
    if (source.z <= viewZ)
    {
        const Position v(source.x*16, source.y*16,
            source.z*24-startTile->getTerrainLevel()+1);
        Position corners[4] = {v, v+Position(16,0,0),v+Position(16,16,0),v+Position(0,16,0)};
        Position xy[4];
        for (int i=0;i<4;++i) _camera->convertVoxelToScreen(corners[i], &xy[i]);
        for (int i=0;i<4;++i)
            drawLine(xy[i].x,xy[i].y,xy[(i+1)%4].x,xy[(i+1)%4].y,160);
    }
    if (!bullet.empty() && source.z<=viewZ)
    {
        Position a,b;
        _camera->convertVoxelToScreen(muzzle,&a);
        _camera->convertVoxelToScreen(bullet.back(),&b);
        drawLine(a.x,a.y,b.x,b.y,73);
    }
    // Never show hidden-target hit probabilities or unexplored geometry.
    // Confirmed native target is independent of the real soldier's
    // firing line. ALWAYS sample H/B/M from source=cursor when discovered.
    // Even an impossible straight line is a legitimate B/M probability.
    if((targetTile->isDiscovered(O_FLOOR) ||
        (aimUnit && aimUnit->getVisible())) &&
        (!aimUnit || aimUnit->getVisible()))
        r22DrawStats(source,target,goal,muzzle);
    else
        _r22StatsText.clear();
    r22DrawRemoteTargetHud(target,goal);
    const double dx=goal.x-muzzle.x,dy=goal.y-muzzle.y,dz=goal.z-muzzle.z;
    const double intended=dx*dx+dy*dy+dz*dz;
    const Position impact=bullet.empty()?goal:bullet.back();
    const double traveled=(impact.x-muzzle.x)*dx+
        (impact.y-muzzle.y)*dy+(impact.z-muzzle.z)*dz;
    if(collision!=V_EMPTY && !bullet.empty() && intended>0 &&
       traveled<intended &&
       _save->getTile(impact.toTile()) &&
       _save->getTile(impact.toTile())->isDiscovered(O_FLOOR))
    {
        Position xy;
        _camera->convertVoxelToScreen(bullet.back(), &xy);
        drawLine(xy.x-2,xy.y-2,xy.x+2,xy.y+2,32);
        drawLine(xy.x-2,xy.y+2,xy.x+2,xy.y-2,32);
        Tile *impactTile=_save->getTile(impact.toTile());
        if(impactTile)
        {
            bool explosive=false;
            for(int part=0;part<=3;++part)
            {
                MapData *piece=impactTile->getMapData(static_cast<TilePart>(part));
                if(piece && piece->getExplosive()>0)explosive=true;
            }
            if (explosive)
            {
                drawString(xy.x+3,xy.y-4,"MCD!",32);
            }
        }
    }
    // R29: draw this *after* legacy trajectory/risk markings so candidate
    // B colors stay visible; this never touches native click processing.
    if (confirmedTarget && native->type != BA_THROW)
    {
        if (native->sprayTargeting || native->weapon->getArcingShot(native->type))
        {
            r29ClearBlockGrid();
            r36DrawArcRangeGrid(soldier, native, target);
        }
        else r29DrawTargetBlockGrid(soldier, native, target);
    }
    else r29ClearBlockGrid();
    // Fixed-width 5-letter stance and readable backplate for any terrain.
    if (!_r22StatsText.empty())
    {
        const bool simulated = _r22StanceOverride &&
            (_r22Kneel != soldier->isKneeled());
        const bool kneel = simulated ? _r22Kneel : soldier->isKneeled();
        r22DrawContrastHud(kneel ? "KNEEL" : "STAND",simulated,
                           " | "+_r22StatsText);
    }

    // R30.2: default to ONE contextual resistance, not the twenty-type
    // fullscreen table. Shift+F8 toggles the expanded reference on demand.
    // Draw-only: never reveal hidden targets or edit tactical state.
    BattleUnit *resistTarget = targetTile->getOverlappingUnit(_save);
    if (resistTarget && resistTarget != soldier && resistTarget->getVisible() &&
        resistTarget->getArmor() && resistTarget->getFaction() != soldier->getFaction())
    {
        static const char codes[DAMAGE_TYPES] = {
            'C','P','F','H','L','A','D','K','X','S',
            'N','B','E','M','W','I','T','R','O','Q'
        };
        // RuleDamageType index (ResistType), not arbitrary local naming.
        static const char* names[DAMAGE_TYPES] = {
            "CHARM","PIERC","FIRE","IMPACT","LASER",
            "PLASMA","DAZE","CUT","CHEM","CHOKE",
            "AE511","BIO","ELEC","EMP","WARP",
            "MIND","STAB","HEAT","COLD","TYPE19"
        };
        const SDL_Color *pal=getPalette();
        if (pal)
        {
            Uint8 dark=1, bright=15;
            int low=2147483647, high=-1;
            for (int c=1;c<256;++c)
            {
                const SDL_Color &rgb=pal[c];
                const int lum=2126*int(rgb.r)+7152*int(rgb.g)+722*int(rgb.b);
                if (lum<low) { low=lum; dark=static_cast<Uint8>(c); }
                if (lum>high) { high=lum; bright=static_cast<Uint8>(c); }
            }
            if (_r30FullResists)
            {
                // Explicitly requested reference view. F8 alone still toggles
                // the original R22/R29 overlay; Shift+F8 closes this view.
                const int cols=3;
                for (int dt=0;dt<DAMAGE_TYPES;++dt)
                {
                    const float modifier=resistTarget->getArmor()->getDamageModifier(
                        static_cast<ItemDamageType>(dt));
                    const int taken=static_cast<int>(modifier*100.0f+
                        (modifier>=0 ? 0.5f : -0.5f));
                    std::ostringstream cell;
                    cell << codes[dt] << ':' << names[dt] << '=' << taken;
                    const std::string label=cell.str();
                    const int x=(dt%cols)*104;
                    const int y=27+(dt/cols)*11;
                    const int width=std::min(getWidth()-x,
                        5+static_cast<int>(label.size())*8);
                    if (width>6 && y+10<=getHeight())
                    {
                        drawRect(x,y,width,10,dark);
                        drawString(x+2,y+1,label.c_str(),bright);
                        r40RememberHudRect(x, y, width, 10);
                    }
                }
                const std::string hint="SHIFT+F8 BACK | 0 IMM 100 NORM 200 2X";
                const int y=27+((DAMAGE_TYPES+cols-1)/cols)*11;
                const int width=std::min(getWidth(),
                    5+static_cast<int>(hint.size())*8);
                if (width>6 && y+10<=getHeight())
                {
                    drawRect(0,y,width,10,dark);
                    drawString(2,y+1,hint.c_str(),bright);
                    r40RememberHudRect(0, y, width, 10);
                }
            }
            else
            {
                // Match OXCE's actual ammo selection: the loaded ammunition
                // determines the projectile's damage type, not gun identity.
                // A thrown non-grenade has no reliable projectile damage type.
                BattleItem *damageItem=nullptr;
                if (native->type == BA_THROW)
                {
                    const BattleType type=native->weapon->getRules()->getBattleType();
                    if (type == BT_GRENADE || type == BT_PROXIMITYGRENADE)
                        damageItem=native->weapon;
                }
                else
                    damageItem=native->weapon->getAmmoForAction(
                        native->type,nullptr,nullptr);
                const RuleDamageType *damage=damageItem && damageItem->getRules()
                    ? damageItem->getRules()->getDamageType() : nullptr;
                if (damage && damage->ResistType >= DT_NONE &&
                    damage->ResistType < DAMAGE_TYPES)
                {
                    const ItemDamageType dt=damage->ResistType;
                    const float modifier=resistTarget->getArmor()->getDamageModifier(dt);
                    const int taken=static_cast<int>(modifier*100.0f+
                        (modifier>=0 ? 0.5f : -0.5f));
                    std::ostringstream label;
                    label << codes[dt] << ':' << names[dt] << ' ' << taken << '%';
                    const std::string cell=label.str();
                    const int width=std::min(getWidth(),
                        5+static_cast<int>(cell.size())*8);
                    // y=27 is below existing stance/stats (y=2) and R29
                    // block-grid key (y=16): no overlap even at 320x200.
                    if (width>6 && getHeight()>=38)
                    {
                        drawRect(0,27,width,10,dark);
                        drawString(2,28,cell.c_str(),bright);
                        r40RememberHudRect(0, 27, width, 10);
                    }
                }
            }
        }
    }
}


// LOSLOF_R22_STATISTICS_EXPERIMENTAL:
// EXPERIMENTAL - uses actual OXCE Projectile trace and accuracy, but hypothetical
// actor position/stance, pellet mode and world side effects aren't fully verified.
// Snapshot the global RNG and restore it before returning (including exceptions).

// LOSLOF_R22_RECOVERY_BETA_20261012
// Read only the already-calculated path; do not calculate/change a player's path.
Position Map::r22PlannedPosition(const BattleUnit *unit) const
{
    const Position actual=unit->getPosition();
    Pathfinding *finder=_save ? _save->getPathfinding() : nullptr;
    if(!finder || !finder->isPathPreviewed()) return actual;
    const std::vector<int>& path=finder->getPath();
    if(path.empty()) return actual;
    const bool ctrl=finder->isModifierCtrlUsed(),alt=finder->isModifierAltUsed();
    const bool running=ctrl && unit->getArmor()->allowsRunning(unit->isSmallUnit())
        && (path.size()>1 || alt);
    const bool strafing=!running && ctrl &&
        unit->getArmor()->allowsStrafing(unit->isSmallUnit()) && path.size()==1;
    const bool sneaking=!running && alt &&
        unit->getArmor()->allowsSneaking(unit->isSmallUnit());
    const BattleActionMove move=strafing ? BAM_STRAFE :
        running ? BAM_RUN : sneaking ? BAM_SNEAK : BAM_NORMAL;
    Position pos=actual;
    for(auto it=path.rbegin();it!=path.rend();++it)
    {
        if(*it<0 || *it>=10) return actual;
        const PathfindingStep step=finder->getTUCost(pos,*it,unit,nullptr,move);
        if(step.cost.time>=Pathfinding::INVALID_MOVE_COST ||
           !_save->getTile(step.pos)) return actual;
        pos=step.pos;
    }
    return pos;
}

// Restore LOS outward perimeter while retaining R21's 1x1 INTERNAL pixel dots.
// Bound voxel traces to 64 candidates per 90ms batch. A completed
// hull is cached for three seconds; moving/stance/position changes
// reset it immediately. Render cached candidates without resampling.
void Map::r22DrawVisibilityHull(const Position &source,const Position &eye,int level)
{
    if(level<0 || level>=_save->getMapSizeZ()) return;
    BattleUnit *observer=_save->getSelectedUnit();
    Tile *virtualTile=_save->getTile(source);
    BattleUnit *previewVacatedUnit = observer && virtualTile && source!=observer->getPosition() ?
        virtualTile->getOverlappingUnit(_save) : nullptr;
    if(previewVacatedUnit &&
       (previewVacatedUnit==observer ||
        previewVacatedUnit->getFaction()!=observer->getFaction()))
        previewVacatedUnit=nullptr;
    const int width=_save->getMapSizeX(),length=_save->getMapSizeY();
    const int range=std::min(16,_save->getTileEngine()->getMaxViewDistance());
    if(range<=0 || width<1 || length<1) return;

    unsigned long long key=1469598103934665603ULL;
    const int factors[]={_save->getSelectedUnit()->getId(),source.x,source.y,
        source.z,eye.x,eye.y,eye.z,level,width,length,range};
    for(int x:factors)
    {
        key^=static_cast<unsigned>(x);
        key*=1099511628211ULL;
    }
    const int minX=std::max(0,source.x-range);
    const int maxX=std::min(width-1,source.x+range);
    const int minY=std::max(0,source.y-range);
    const int maxY=std::min(length-1,source.y+range);
    if(minX>maxX || minY>maxY) return;
    const int spanX=maxX-minX+1;
    const size_t scanTotal=size_t(spanX)*size_t(maxY-minY+1);
    const Uint32 tick=SDL_GetTicks();
    // Refresh terrain/door changes, but only after the preceding scan finishes.
    const bool restart =
        _r22VisibleHull.size()!=size_t(width*length) || key!=_r22HullHash ||
        (_r22HullNextIndex>=scanTotal && tick-_r22HullCheckedAt>3000U);
    if(restart)
    {
        _r22VisibleHull.assign(size_t(width*length),0);
        _r22HullNextIndex=0;
        _r22HullHash=key;
        _r22HullCheckedAt=tick;
        _r22HullLastBatchTick=0;
    }
    const bool wasPending=_r22HullNextIndex<scanTotal;
    if(restart || tick-_r22HullLastBatchTick>=90U)
    {
        _r22HullLastBatchTick=tick;
        unsigned processed=0;
        const int radius2=range*range;
        while(_r22HullNextIndex<scanTotal && processed<64U)
        {
            const size_t index=_r22HullNextIndex++;
            ++processed; // even out-of-range candidates consume budget
            const int x=minX+int(index%size_t(spanX));
            const int y=minY+int(index/size_t(spanX));
            const int dx=x-source.x,dy=y-source.y;
            if(dx*dx+dy*dy>radius2) continue;
            Tile *tile=_save->getTile(Position(x,y,level));
            if(!tile || !tile->isDiscovered(O_FLOOR)) continue;
            const Position goal(x*16+8,y*16+8,
                level*24-tile->getTerrainLevel()+10);
            std::vector<Position> path;
            const int voxelResult=_save->getTileEngine()->calculateLineVoxel(
                eye,goal,true,&path,_save->getSelectedUnit(),nullptr,true,previewVacatedUnit);
            if(voxelResult==V_EMPTY || (!path.empty() &&
                path.back().toTile()==tile->getPosition()))
                _r22VisibleHull[size_t(y*width+x)]=1;
        }
    }
    _r22HullWorkPending = _r22HullNextIndex < scanTotal;
    if(wasPending && !_r22HullWorkPending) _r22HullCheckedAt=tick;
    // Avoid forcing a complete terrain repaint inside the render loop.

    const auto visible=[&](int x,int y)->bool
    {
        return x>=0 && y>=0 && x<width && y<length &&
            _r22VisibleHull[size_t(y*width+x)]!=0;
    };
    // Painting is also restricted to the local vision bounding rectangle.
    for(int y=minY;y<=maxY;++y)
    for(int x=minX;x<=maxX;++x)
    {
        if(!visible(x,y)) continue;
        Tile *t=_save->getTile(Position(x,y,level));
        if(!t) continue;
        const int z=level*24-t->getTerrainLevel()+1;
        Position mid;
        _camera->convertVoxelToScreen(Position(x*16+8,y*16+8,z),&mid);
        setPixel(mid.x,mid.y,48); // one game pixel per visible tile
        const Position world[4]={
            Position(x*16,y*16,z),Position((x+1)*16,y*16,z),
            Position((x+1)*16,(y+1)*16,z),Position(x*16,(y+1)*16,z)};
        const bool edge[4]={
            !visible(x,y-1),!visible(x+1,y),!visible(x,y+1),!visible(x-1,y)};
        Position screen[4];
        for(int i=0;i<4;++i)
            _camera->convertVoxelToScreen(world[i],&screen[i]);
        for(int i=0;i<4;++i)
        {
            if(edge[i])drawLine(screen[i].x,screen[i].y,
                screen[(i+1)%4].x,screen[(i+1)%4].y,48);
        }
    }
}

void Map::r22DrawRemoteTargetHud(const Position &target,const Position &aim)
{
    Position screen;
    _camera->convertVoxelToScreen(aim,&screen);
    const int width=getWidth(),height=_visibleMapHeight;
    const int zDiff=target.z-_camera->getViewLevel();
    const int displayedX = screen.x;
    const bool outside=displayedX<5 || displayedX>width-8 ||
        screen.y<31 || screen.y>height-15;
    if(!outside && !zDiff) return;
    const int px=std::max(3,std::min(displayedX,std::max(3,width-136)));
    const int py=std::max(30,std::min(int(screen.y),std::max(30,height-24)));
    const char *arrow=displayedX<5?"<":displayedX>width-8?">":
        screen.y<31?"^":screen.y>height-15?"v":"*";
    std::ostringstream label;
    label<<arrow<<" Z"<<(zDiff>=0?"+":"")<<zDiff;
    // Offscreen HUD is direction and Z only; do not duplicate statistics.
    std::string result=label.str();
    if(result.size()>60)result.resize(60);
    drawString(px,py,result.c_str(),160);
}


// R41: Side-effect-free sampled landing distribution for a PINNED, real-origin
// throw. A private RNG feeds the very same Projectile::calculateThrow()
// (including its 100-attempt acceptance policy) as actual gameplay.
// Percentages are estimates, NEVER deterministic hit guarantees.
std::string Map::r41DrawThrowHeatmap(BattleAction action, const Position &target,
    const Position &from, const Position &muzzle, bool virtualKneeled)
{
    if (!_save || !_camera || !action.actor || !action.weapon ||
        action.type != BA_THROW || _save->getSide() != FACTION_PLAYER)
        return "";
    Tile *targetTile = _save->getTile(target);
    if (!targetTile || (!targetTile->getVisible() &&
                        !targetTile->isDiscovered(O_FLOOR)))
        return " | ARC UNKNOWN (FOG)";

    action.target = target;
    // Preserve the live relativeOrigin rather than forcing center.
    // Snapshot the entire RNG stream, including accuracy script calls.
    struct RestoreR41Rng
    {
        RNG::RandomState snapshot;
        RestoreR41Rng() : snapshot(RNG::globalRandomState()) {}
        ~RestoreR41Rng() { RNG::globalRandomState() = snapshot; }
    } preserveRng;
    const int accuracyPct = BattleUnit::getFiringAccuracy(
        BattleActionAttack::GetAferShoot(action, nullptr), _game->getMod());
    const double accuracy = accuracyPct / 100.0;
    // Accuracy and range/scatter depend on the proposed muzzle, not on
    // the real soldier's position while the target is pinned. The
    // projectile runs the native throw algorithm with preview-only inputs.
    const Uint32 now = SDL_GetTicks();

    unsigned long long signature = 1469598103934665603ULL;
    auto mix = [&](unsigned long long value) {
        signature ^= value; signature *= 1099511628211ULL;
    };
    mix(static_cast<unsigned>(action.actor->getId()));
    mix(reinterpret_cast<uintptr_t>(action.weapon));
    const int parts[] = { target.x, target.y, target.z, muzzle.x,
        muzzle.y, muzzle.z, from.x, from.y, from.z,
        int(virtualKneeled), int(action.actor->getTimeUnits()),
        action.actor->getBaseStats()->strength, action.weapon->getTotalWeight(),
        accuracyPct, targetTile->getTerrainLevel(), _save->getTurn(),
        _save->getDepth(), _save->getMapSizeX(), _save->getMapSizeY() };
    for (int p : parts) mix(static_cast<unsigned>(p));

    // Include known units because ally movement changes the blast-risk
    // estimate and visible units can change collision paths.
    // Hidden enemies must never enter the HUD cache signature.
    for (const BattleUnit *unit : *_save->getUnits())
    {
        if (!unit || (unit->getFaction() != FACTION_PLAYER &&
                      !unit->getVisible())) continue;
        const Position u = unit->getPosition();
        mix(static_cast<unsigned>(unit->getId()));
        mix(static_cast<unsigned>(u.x));
        mix(static_cast<unsigned>(u.y));
        mix(static_cast<unsigned>(u.z));
        mix(static_cast<unsigned>(unit->isOut()));
    }

    // Cheap local terrain signature; global changes are covered by a
    // conservative age limit. Do not read hidden unit statistics.
    for (int dY = -2; dY <= 2; ++dY)
    for (int dX = -2; dX <= 2; ++dX)
    {
        Tile *t = _save->getTile(target + Position(dX,dY,0));
        if (!t) continue;
        for (int part = 0; part <= 3; ++part)
            mix(reinterpret_cast<uintptr_t>(t->getMapData(static_cast<TilePart>(part))));
        mix(static_cast<unsigned>(t->getTerrainLevel()));
    }
    if (_r41ThrowSignature != signature ||
        (now - _r41ThrowChangedAt > 15000U && _r41ThrowSamples >= 256))
    {
        _r41ThrowSignature = signature;
        _r41ThrowChangedAt = now;
        _r41ThrowBatchAt = 0;
        _r41LandingCells.clear();
        _r41ThrowSamples = _r41Target = _r41Scatter = _r41Early = 0;
        _r41FriendlyRadius = _r41Unknown = _r41Failed = 0;
    }

    // Conditional Monte Carlo samples: 12 per redraw, never 256 in a
    // single frame. Each trial runs the engine's FULL 100-retry policy.
    if (_r41ThrowSamples < 256U && now - _r41ThrowBatchAt >= 45U)
    {
        _r41ThrowBatchAt = now;
        const unsigned batch = std::min(12U, 256U - _r41ThrowSamples);
        const bool explosive = action.weapon->getRules()->isGrenadeOrProxy();
        const int radius = explosive ? std::max(0,
            action.weapon->getRules()->getExplosionRadius(
                {action.type, action.actor, action.weapon, action.weapon})) : 0;
        const Uint32 batchStarted = SDL_GetTicks();
        for (unsigned i = 0; i < batch; ++i)
        {
            // Give the UI a soft 8ms budget, resume next refresh.
            if (i && SDL_GetTicks() - batchStarted >= 8U) break;
            const unsigned sampleId = _r41ThrowSamples++;
            RNG::RandomState previewRng(
                signature ^ (0x9e3779b97f4a7c15ULL * (sampleId + 1)));
            // Constructing a Projectile does not create or move a real item.
            // No Map::setProjectile(), ammo, fuse, or TU methods are called.
            Projectile test(_game->getMod(), _save, action,
                from, target.toVoxel(), nullptr);
            const int collision = test.calculateThrow(accuracy, &previewRng,
                &from, &muzzle, virtualKneeled ? 1 : 0);
            const auto &trace = test.getTrajectoryForPreview();
            if (trace.empty() ||
                (collision != V_FLOOR && collision != V_UNIT &&
                 collision != V_OBJECT))
            {
                ++_r41Failed;
                continue;
            }
            const Position landing = Projectile::getPositionFromEnd(
                trace, Projectile::ItemDropVoxelOffset).toTile();
            Tile *landTile = _save->getTile(landing);
            if (!landTile) { ++_r41Failed; continue; }

            // No fog / unseen-unit leakage: never draw a result if any
            // visited tile lacks player-discovered terrain. Suppress the
            // entire probability readout when any sample is unknown.
            bool unknown = false;
            for (const Position &voxel : trace)
            {
                Tile *pathTile = _save->getTile(voxel.toTile());
                if (!pathTile ||
                    (!pathTile->getVisible() &&
                     !pathTile->isDiscovered(O_FLOOR)))
                { unknown = true; break; }
                // A hidden hostile standing on a previously visited tile
                // must never be discoverable via the probability heatmap.
                BattleUnit *other = pathTile->getOverlappingUnit(_save);
                if (other && other != action.actor && !other->getVisible()
                    && other->getFaction() != FACTION_PLAYER)
                { unknown = true; break; }
            }
            if (unknown || (!landTile->getVisible() &&
                            !landTile->isDiscovered(O_FLOOR)))
            {
                ++_r41Unknown;
                continue;
            }
            if (landing == target) ++_r41Target;
            else ++_r41Scatter;

            // EARLY is an independent indicator and may overlap SCATTER.
            const Position firstHit = trace.back().toTile();
            const bool early = (collision == V_OBJECT || collision == V_UNIT)
                && firstHit != target;
            if (early) ++_r41Early;

            bool friendlyInRadius = false;
            if (radius > 0)
            {
                for (BattleUnit *unit : *_save->getUnits())
                {
                    if (!unit || unit->isOut() ||
                        unit->getFaction() != FACTION_PLAYER) continue;
                    const Position other = unit->getPosition();
                    const int dx = other.x - landing.x, dy = other.y - landing.y;
                    const int dz = other.z - landing.z;
                    // Radius-only conservative candidate, NOT a damage
                    // probability: blast occlusion/power falloff not sampled.
                    if (dx*dx + dy*dy + dz*dz <= radius*radius)
                    { friendlyInRadius = true; break; }
                }
            }
            if (friendlyInRadius) ++_r41FriendlyRadius;
            const int index = (landing.z * _save->getMapSizeY() + landing.y)
                * _save->getMapSizeX() + landing.x;
            R41LandingCell &cell = _r41LandingCells[index];
            cell.tile = landing;
            ++cell.count;
            if (early) ++cell.early;
            if (friendlyInRadius) ++cell.friendlyRadius;
        }
        // preserveRng restores even if a native script consumes RNG.
    }

    if (_r41Unknown > 0)
        return " | ARC UNKNOWN (FOG)";
    if (_r41ThrowSamples < 32U)
    {
        std::ostringstream text;
        text << " | SAMPLING " << _r41ThrowSamples << "/256";
        return text.str();
    }

    const int observed = static_cast<int>(_r41ThrowSamples);
    // Use the active X-Piratez palette to choose actual green/yellow/
    // orange/red rather than assuming the same indexes in every mission.
    auto paletteColor = [&](int r, int g, int b) -> Uint8 {
        const SDL_Color *palette = getPalette();
        int best = 1, score = 0x7fffffff;
        if (!palette) return 1;
        for (int i = 1; i < 256; ++i)
        {
            const int dr = r - int(palette[i].r);
            const int dg = g - int(palette[i].g);
            const int db = b - int(palette[i].b);
            const int dist = dr*dr + dg*dg + db*db;
            if (dist < score) { score = dist; best = i; }
        }
        return static_cast<Uint8>(best);
    };
    const Uint8 green = paletteColor(30,230,100);
    const Uint8 yellow = paletteColor(250,225,40);
    const Uint8 orange = paletteColor(255,130,30);
    const Uint8 red = paletteColor(245,50,55);
    for (const auto &entry : _r41LandingCells)
    {
        const R41LandingCell &cell = entry.second;
        if (cell.tile.z > _camera->getViewLevel()) continue;
        Tile *t = _save->getTile(cell.tile);
        if (!t || (!t->getVisible() && !t->isDiscovered(O_FLOOR)))
            continue;
        const int strength = static_cast<int>(100 * cell.count / observed);
        Position screen;
        _camera->convertVoxelToScreen(
            cell.tile.toVoxel() + Position(8,8,1-t->getTerrainLevel()), &screen);
        const Uint8 color = cell.friendlyRadius ? red :
            (cell.early ? orange : cell.tile == target ? green : yellow);
        // Pixel footprint conveys the observed landing weight. Keep every
        // sampled cell visible even below 1%; N indicates uncertainty.
        const int size = strength >= 25 ? 7 :
            strength >= 10 ? 5 : strength >= 3 ? 3 : 1;
        drawRect(screen.x - size/2, screen.y - size/2, size, size, color);
    }
    // Aim cross remains visible over the distribution.
    Position targetScreen;
    _camera->convertVoxelToScreen(
        target.toVoxel() + Position(8,8,1-targetTile->getTerrainLevel()),
        &targetScreen);
    drawLine(targetScreen.x-7,targetScreen.y,targetScreen.x+7,targetScreen.y,green);
    drawLine(targetScreen.x,targetScreen.y-5,targetScreen.x,targetScreen.y+5,green);

    // The labels are *estimated* percentages of ALL sampled attempts.
    // EARLY overlaps SCATTER. FRIENDLY-R is radius inclusion only.
    auto percentage = [observed](unsigned n) -> int {
        return (int)((100U * n + observed/2) / observed);
    };
    std::ostringstream text;
    // Compact 320px HUD: tilde marks MC estimates, not exact odds.
    // T=target, S=scatter, E=early (can overlap S),
    // F=ally within item blast RADIUS (not confirmed damage), n=trials.
    text << " | ~T" << percentage(_r41Target)
         << " S" << percentage(_r41Scatter)
         << " E" << percentage(_r41Early)
         << " F" << percentage(_r41FriendlyRadius)
         << " n" << observed;
    if (_r41Failed)
        text << " X" << percentage(_r41Failed);
    return text.str();
}

// LOSLOF_R22_THROW_PREVIEW_RECOVERY
// Read-only world preview; virtual position and stance actually affect
// native engine throw range and parabolic collision. Re-evaluate cache
// immediately if thrower, target, weapon, stance, floor or 300ms changes.
void Map::r22DrawThrowPreview(const Position& from,const Position& destination,
    const Tile* originTile,const Tile* targetTile)
{
    BattleUnit *actor=_save->getSelectedUnit();
    BattleAction *active=_save->getBattleGame()->getCurrentAction();
    if(!actor || !active || active->actor!=actor || !active->weapon ||
       !originTile || !targetTile) return;
    BattleAction action=*active;
    // Match ProjectileFlyBState::init(): elevated -24 terrain retargets to
    // the floor directly above BEFORE native validateThrow/calculateThrow.
    Position executionTarget = destination;
    const Tile *executionTargetTile = targetTile;
    if (targetTile->getTerrainLevel() == -24 &&
        destination.z + 1 < _save->getMapSizeZ())
    {
        executionTarget.z += 1;
        executionTargetTile = _save->getTile(executionTarget);
        if (!executionTargetTile) return;
    }
    action.target=executionTarget;
    const bool virtualKneeled=_r22StanceOverride ? _r22Kneel : actor->isKneeled();
    const int stanceDelta=(virtualKneeled?actor->getKneelHeight():
        actor->getStandHeight())-actor->getHeight();
    // Native origin is mandatory for a real, pinned throw. Virtual
    // previews retain the old geometry and are labeled hypothetical.
    const bool realSource = from == actor->getPosition() &&
        virtualKneeled == actor->isKneeled();
    // A hypothetical source is not a way of scouting unexplored tiles.
    BattleUnit *sourceOccupant = originTile->getOverlappingUnit(_save);
    if ((!originTile->getVisible() && !originTile->isDiscovered(O_FLOOR)) ||
        (sourceOccupant && sourceOccupant != actor &&
         sourceOccupant->getFaction() != FACTION_PLAYER &&
         !sourceOccupant->getVisible()))
    {
        _r22StatsText.clear();
        r22DrawContrastHud(virtualKneeled ? "KNEEL" : "STAND",
            !realSource, " | SIM ARC UNKNOWN (FOG)");
        return;
    }
    // For a hypothetical origin occupied by an ally, vacate the preview
    // collision only, just as the pinned shooting HUD already does.
    BattleUnit *previewVacatedUnit = !realSource && from != actor->getPosition() &&
        sourceOccupant && sourceOccupant != actor &&
        sourceOccupant->getFaction() == actor->getFaction()
        ? sourceOccupant : nullptr;
    Position origin = realSource
        ? _save->getTileEngine()->getOriginVoxel(action, nullptr)
        : r32VirtualMuzzle(action,const_cast<Tile*>(originTile),
            stanceDelta,from!=actor->getPosition());
    const Position goal=executionTarget.toVoxel()+
        Position(8,8,1-executionTargetTile->getTerrainLevel());

    unsigned long long key=1469598103934665603ULL;
    const int args[]={actor->getId(),from.x,from.y,from.z,
        executionTarget.x,executionTarget.y,executionTarget.z,
        origin.x,origin.y,origin.z,
        executionTargetTile->getTerrainLevel(), int(virtualKneeled),
        active->weapon->getTotalWeight()};
    for(int x:args){key^=static_cast<unsigned>(x);key*=1099511628211ULL;}
    key^=reinterpret_cast<uintptr_t>(active->weapon);
    key*=1099511628211ULL;
    const Uint32 time=SDL_GetTicks();
    if(key!=_r22ThrowCacheKey || time-_r22ThrowCacheTime>300U)
    {
        _r22ThrowTrajectory.clear();
        _r22ThrowValid=false;
        double curve=0.0;
        int nativeCollision=V_EMPTY;
        // Modified ONLY for preview with 3 trailing arguments.
        // Default real-shot semantics stay identical in TileEngine.
        const bool nativeArc=_save->getTileEngine()->validateThrow(action,origin,goal,
             _save->getDepth(),&curve,&nativeCollision,false,
             false,&from,virtualKneeled?1:0,true,previewVacatedUnit);
        if(nativeArc)
        {
            const int result=_save->getTileEngine()->calculateParabolaVoxel(
                origin,goal,true,&_r22ThrowTrajectory,actor,curve,
                Position(0,0,0),false,previewVacatedUnit);
            // LOSLOF_R22_THROW_WINDOW_AND_LIVE_GRENADE_OPTION
            // Same accepted impact kinds as native throw execution, NOT
            // merely result!=V_OUTOFBOUNDS (which includes window/walls).
            bool accepted=(result==V_FLOOR || result==V_UNIT ||
                           result==V_OBJECT) &&
                          !_r22ThrowTrajectory.empty();
            if(accepted)
            {
                // Exactly mirror Projectile::calculateThrow's item-drop
                // position and impassable-object rejection.
                const Position itemTile=Projectile::getPositionFromEnd(
                    _r22ThrowTrajectory,Projectile::ItemDropVoxelOffset).toTile();
                Tile *endTile=_save->getTile(itemTile);
                if(!endTile) accepted=false;
                else if(endTile->getMapData(O_OBJECT) &&
                        endTile->getMapData(O_OBJECT)->getTUCost(MT_WALK)
                            ==Pathfinding::INVALID_MOVE_COST &&
                        !(endTile->isBigWall() &&
                          (endTile->getMapData(O_OBJECT)->getBigWall()<1 ||
                           endTile->getMapData(O_OBJECT)->getBigWall()>3)))
                    accepted=false;
            }
            _r22ThrowValid=accepted;
        }
        else
        {
            // Show the blocked/parabola path too, rather than an empty
            // screen when range, railings or low ceilings reject the arc.
            const double strength=std::max<int>(1,actor->getBaseStats()->strength);
            const double weight=std::max(1,active->weapon->getTotalWeight());
            const double firstCurve=std::max(0.48,
                1.73/std::sqrt(std::sqrt(strength/weight))+
                (virtualKneeled ? 0.1 : 0.0));
            _save->getTileEngine()->calculateParabolaVoxel(origin,goal,true,
                &_r22ThrowTrajectory,actor,firstCurve,Position(0,0,0),
                false,previewVacatedUnit);
        }
        _r22ThrowCacheKey=key;
        _r22ThrowCacheTime=time;
    }
    // R32: render the real parabolic VOXEL path (not floor-level dots).
    // Filter by already explored XY map positions; don't reveal fog tiles.
    const int width=_save->getMapSizeX(),length=_save->getMapSizeY();
    Position previous(0,0,0);
    bool hasPrevious=false;
    // Draw sampled landing heatmap BEFORE the reference arc so both stay
    // readable in overlapping tiles and across 90-degree view rotations.
    const bool pinned = !active->waypoints.empty() && active->targeting;
    bool baselineFog = false;
    for (const Position &voxel : _r22ThrowTrajectory)
    {
        Tile *seen = _save->getTile(voxel.toTile());
        if (!seen || (!seen->getVisible() && !seen->isDiscovered(O_FLOOR)))
        { baselineFog = true; break; }
        BattleUnit *occupant = seen->getOverlappingUnit(_save);
        if (occupant && occupant != actor && !occupant->getVisible() &&
            occupant->getFaction() != FACTION_PLAYER)
        { baselineFog = true; break; }
    }
    // Never expose a hidden collision via a prematurely terminated arc.
    if (baselineFog)
    {
        _r22StatsText.clear();
        r22DrawContrastHud(virtualKneeled ? "KNEEL" : "STAND",
            !realSource, " | ARC UNKNOWN (FOG)");
        return;
    }
    // Both real and hypothetical origins use the SAME native 100-retry
    // throw sampler. The cursor's world XY/Z and muzzle are passed to
    // every probability trial, not just to the reference parabola.
    std::string probabilityText = pinned
        ? r41DrawThrowHeatmap(action,executionTarget,from,origin,virtualKneeled)
        : " | CLICK TARGET FOR PROB";
    // A sampled trajectory encountering hidden geometry must not leave
    // a colored baseline or impact X that can locate an unseen enemy.
    if (probabilityText.find("FOG") != std::string::npos)
    {
        _r22StatsText.clear();
        r22DrawContrastHud(virtualKneeled ? "KNEEL" : "STAND",
            !realSource, " | ARC UNKNOWN (FOG)");
        return;
    }
    const Uint8 arcColor=_r22ThrowValid ? 73 : 32;
    const size_t step=std::max<size_t>(1,_r22ThrowTrajectory.size()/80);
    for(size_t i=0;i<_r22ThrowTrajectory.size();i+=step)
    {
        const Position &voxel=_r22ThrowTrajectory[i];
        if(voxel.x<0 || voxel.y<0 || voxel.z<0) { hasPrevious=false; continue; }
        const int x=voxel.x/16,y=voxel.y/16,z=voxel.z/24;
        if(x>=width || y>=length || z>=_save->getMapSizeZ())
        { hasPrevious=false; continue; }
        // The path can rise above camera Z without changing the XY tile's
        // visibility; use view-level discovery to avoid exposing new ground.
        Tile *known=_save->getTile(Position(x,y,
            std::min(z,_camera->getViewLevel())));
        if(!known || (!known->isDiscovered(O_FLOOR) && !known->getVisible()))
        { hasPrevious=false; continue; }
        Position point;
        _camera->convertVoxelToScreen(voxel,&point);
        if(hasPrevious) drawLine(previous.x,previous.y,point.x,point.y,arcColor);
        else setPixel(point.x,point.y,arcColor);
        previous=point;
        hasPrevious=true;
    }
    if(!_r22ThrowTrajectory.empty())
    {
        const Position impactVoxel=_r22ThrowTrajectory.back();
        Tile *known=_save->getTile(impactVoxel.toTile());
        if(known && (known->isDiscovered(O_FLOOR) || known->getVisible()))
        {
            Position impact;
            _camera->convertVoxelToScreen(impactVoxel,&impact);
            const Uint8 marker=_r22ThrowValid ? 73 : 32;
            drawLine(impact.x-3,impact.y-3,impact.x+3,impact.y+3,marker);
            drawLine(impact.x-3,impact.y+3,impact.x+3,impact.y-3,marker);
        }
    }
    _r22StatsText.clear(); // Never display stale gun H/B/M while throwing.
    const bool simulated = !realSource;
    std::string arcReason = _r22ThrowValid ? "ARC CLEAR" : "ARC BLOCKED";
    if (!_r22ThrowValid)
    {
        const bool blockedObject = executionTargetTile->getMapData(O_OBJECT) &&
            executionTargetTile->getMapData(O_OBJECT)->getTUCost(MT_WALK) ==
                Pathfinding::INVALID_MOVE_COST &&
            !(executionTargetTile->isBigWall() &&
                (executionTargetTile->getMapData(O_OBJECT)->getBigWall() < 1 ||
                 executionTargetTile->getMapData(O_OBJECT)->getBigWall() > 3));
        if (blockedObject) arcReason = "ARC BLOCKED: OBSTACLE";
        else
        {
            BattleAction rangeAction = action;
            rangeAction.target = destination;
            if (!ProjectileFlyBState::validThrowRange(&rangeAction, origin,
                    const_cast<Tile*>(targetTile), _save->getDepth(), &from))
                arcReason = "ARC BLOCKED: RANGE";
            else arcReason = "ARC BLOCKED: TRAJECTORY / LANDING";
        }
    }
    // Neither live collision state nor sampled percentages may disclose
    // hidden terrain or an unseen enemy through a nominal "ARC CLEAR".
    if (baselineFog || probabilityText.find("FOG") != std::string::npos)
    {
        arcReason = "ARC UNKNOWN (FOG)";
        probabilityText.clear();
    }
    std::string hudText = " | " +
        (simulated ? std::string("SIM ") : std::string()) +
        arcReason + probabilityText;
    // On the standard 320px tactical canvas the verbose arc reason can
    // push all probability digits offscreen. Keep T/S/E/F readable first;
    // the drawn reference arc and OK/NO still express its validity.
    if (probabilityText.find("~T") != std::string::npos)
    {
        const std::string shortReason = _r22ThrowValid ? "OK" : "NO";
        hudText = " | " + (simulated ? std::string("SIM ") : std::string()) +
            shortReason + probabilityText;
        const int capacity = std::max(0, (getWidth() - 42) / 8);
        if (int(hudText.size()) > capacity)
        {
            const size_t countPos = hudText.find(" n");
            if (countPos != std::string::npos)
            {
                const size_t nextMetric = hudText.find(" X", countPos);
                hudText.erase(countPos, nextMetric == std::string::npos ?
                    std::string::npos : nextMetric - countPos);
            }
        }
    }
    r22DrawContrastHud(virtualKneeled ? "KNEEL" : "STAND",simulated,
                       hudText);
    r22DrawRemoteTargetHud(executionTarget,goal);
}

void Map::r22DrawStats(const Position& origin, const Position& target,
                      const Position& aim, const Position& muzzle)
{
    // Never display a previous weapon's probabilities after deselection or
    // switching to an action that the ballistic sampler does not support.
    auto clearInvalidPreview = [this]() {
        _r22StatsText.clear();
        _r22TileRisks.clear();
        _r22StatsKey = 0;
        _r22SampleCount = 0;
        _r22HitSamples = 0;
        _r22BlockedSamples = 0;
        _r22MissSamples = 0;
        _r22RiskSamples = 0;
    };
    BattleUnit *shooter = _save->getSelectedUnit();
    if (!shooter || !_save->getBattleGame()) { clearInvalidPreview(); return; }
    BattleAction *current = _save->getBattleGame()->getCurrentAction();
    if (!current || current->actor != shooter || !current->weapon) {
        clearInvalidPreview(); return;
    }
    if (current->type != BA_SNAPSHOT && current->type != BA_AIMEDSHOT &&
        current->type != BA_AUTOSHOT) { clearInvalidPreview(); return; }

    BattleItem *weapon = current->weapon;
    if (weapon->getArcingShot(current->type)) { clearInvalidPreview(); return; }
    BattleItem *ammo = weapon->getAmmoForAction(current->type,nullptr,nullptr);
    if (!ammo || !ammo->getRules()) { clearInvalidPreview(); return; }
    const RuleItemAction *conf = weapon->getActionConf(current->type);
    const int shots = conf ? conf->shots : 1;
    // Fully loaded for the action? A lower-but-still-sufficient clip
    // DOES NOT change weapon accuracy or the burst distribution.
    // Saturating the clip cache signature keeps the same deterministic
    // Monte Carlo stream after spending 6 of 42 SMG rounds.
    // Below full-burst capacity, preserve distinct cache keys.
    const int roundsPerShot = conf ? std::max(1, conf->spendPerShot) : 1;
    const int roundsForBurst = shots * roundsPerShot;
    const int ammoSignature = ammo->getRules()->getClipSize() > 0
        ? std::min(ammo->getAmmoQuantity(), roundsForBurst)
        : ammo->getAmmoQuantity();
    const bool shotgun = ammo->getRules()->getShotgunPellets() > 0 &&
                         ammo->getRules()->getDamageType()->isDirect();
    const int pellets = shotgun ? ammo->getRules()->getShotgunPellets() : 1;
    // Unsupported action sizes don't show invented probabilities.
    // Never exceed 256 engine bullet traces in a render frame, even in
    // unusual ammunition containing many pellets and huge bursts.
    if (shots < 1 || shots > 16 || pellets < 1 || pellets > 20 ||
        shots*pellets > 256) {
        clearInvalidPreview(); return;
    }
    // Resolve actual occupier, not merely the owner/root tile. Multi-tile
    // soldiers and units intersecting the floor above use native overlap rules.
    Tile *targetTile=_save->getTile(target);
    BattleUnit *targetUnit=targetTile ?
        targetTile->getOverlappingUnit(_save) : nullptr;
    if (targetUnit && !targetUnit->getVisible()) targetUnit=nullptr;
    Tile *originTile=_save->getTile(origin);
    BattleUnit *previewVacatedUnit = originTile && origin!=shooter->getPosition() ?
        originTile->getOverlappingUnit(_save) : nullptr;
    if (previewVacatedUnit &&
        (previewVacatedUnit==shooter ||
         previewVacatedUnit->getFaction()!=shooter->getFaction()))
        previewVacatedUnit=nullptr;

    // Compute current accuracy BEFORE the cache key. Skills, injuries,
    // buffs, ammo and selected action can change without moving the cursor.
    BattleAction action=*current;
    action.actor=shooter;
    action.target=target;
    BattleActionAttack attack=BattleActionAttack::GetAferShoot(action,ammo);
    double accuracy=BattleUnit::getFiringAccuracy(attack,_game->getMod())/100.0;
    const bool virtualKneelChange = _r22StanceOverride &&
        _r22Kneel != shooter->isKneeled();
    const double kneelFactor = weapon->getRules()->getKneelBonus(_game->getMod())/100.0;
    if (virtualKneelChange && kneelFactor > 0.0)
        accuracy *= _r22Kneel ? kneelFactor : 1.0 / kneelFactor;
    const int stanceDelta = virtualKneelChange ?
        ((_r22Kneel ? shooter->getKneelHeight() : shooter->getStandHeight())
        - shooter->getHeight()) : 0;
    // Resolve no-LOS from the exact firing SOURCE. Native firing is
    // unchanged; TileEngine copies the pinned OXCE rules read-only.
    const int noLosPenalty = weapon->getRules()->getNoLOSAccuracyPenalty(_game->getMod());
    int virtualHasLOS = -1;
    if (noLosPenalty != -1)
    {
        Tile *aimedTile = _save->getTile(aim.toTile());
        if (aimedTile)
        {
            bool visible = aimedTile->getUnit() ?
                _save->getTileEngine()->r25VirtualVisible(shooter,aimedTile,origin,stanceDelta) :
                _save->getTileEngine()->r25VirtualTileInLOS(&action,aimedTile,false,origin,stanceDelta);
            virtualHasLOS = visible ? 1 : 0;
        }
    }
    // Native crosshair uses tile-centre (ceil) distance, not the
    // voxel distance used by the trajectory's fractional dropoff.
    int dx=origin.x-target.x,dy=origin.y-target.y,dz=origin.z-target.z;
    if (shooter->isBigUnit())
    {
        if (origin.x < target.x) ++dx;
        if (origin.y < target.y) ++dy;
    }
    const int distanceSq=dx*dx+dy*dy+dz*dz;
    const int distance=int(std::ceil(std::sqrt(float(distanceSq))));
    int upperLimit=0, lowerLimit=0;
    const int dropoff=weapon->getRules()->calculateLimits(
        upperLimit,lowerLimit,_save->getDepth(),action.type);
    int displayedAccuracy=BattleUnit::getFiringAccuracy(
        BattleActionAttack::GetBeforeShoot(action),_game->getMod());
    if (virtualKneelChange && kneelFactor>0.0)
        displayedAccuracy=int(displayedAccuracy*(_r22Kneel ? kneelFactor : 1.0/kneelFactor));
    if (distance>upperLimit) displayedAccuracy-=(distance-upperLimit)*dropoff;
    else if (distance<lowerLimit) displayedAccuracy-=(lowerLimit-distance)*dropoff;
    if (noLosPenalty!=-1 && virtualHasLOS==0)
        displayedAccuracy=displayedAccuracy*noLosPenalty/100;
    const bool outOfRange=!action.sprayTargeting &&
        weapon->getRules()->isOutOfRange(distanceSq);
    if (outOfRange || displayedAccuracy<=0) displayedAccuracy=0;
    // Real ProjectileFlyBState rejects fire beyond the weapon max range.
    // Never show an attainable hit chance when native fire is forbidden.
    if (outOfRange)
    {
        clearInvalidPreview();
        _r22StatsText="ACC~0% OUT OF RANGE";
        return;
    }

    unsigned long long key=1469598103934665603ULL;
    auto mix=[&](unsigned long long value) {
        key^=value; key*=1099511628211ULL;
    };
    for (int x : std::initializer_list<int>{shooter->getId(), origin.x,origin.y,origin.z,
                  target.x,target.y,target.z,aim.x,aim.y,aim.z,
                  muzzle.x,muzzle.y,muzzle.z,(int)current->type,
                  (int)_r22Kneel,(int)shooter->isKneeled(),
                  ammoSignature,shots,pellets})
        mix((unsigned int)x);
    mix((unsigned long long)(uintptr_t)weapon);
    mix((unsigned long long)(uintptr_t)weapon->getRules());
    mix((unsigned long long)(uintptr_t)ammo);
    mix((unsigned long long)(uintptr_t)ammo->getRules());
    mix((unsigned long long)(uintptr_t)targetUnit);
    mix((unsigned long long)(uintptr_t)previewVacatedUnit);
    mix((unsigned long long)(uintptr_t)targetTile);
    mix((unsigned long long)(static_cast<long long>(accuracy*1000000.0)));
    mix((unsigned int)(virtualHasLOS+1));
    mix((unsigned int)displayedAccuracy);
    // A newly opened door, destroyed wall or newly blocking target must
    // invalidate Monte Carlo results without waiting for cache expiration.
    // Native voxel obstruction probing consumes no RNG and respects fog.
    std::vector<Position> obstructionPoint;
    const int directCollision=_save->getTileEngine()->calculateLineVoxel(
        muzzle,aim,false,&obstructionPoint,shooter,nullptr,true,previewVacatedUnit);
    mix(static_cast<unsigned>(directCollision));
    if (!obstructionPoint.empty())
    {
        const Position& p=obstructionPoint.back();
        mix(static_cast<unsigned>(p.x));
        mix(static_cast<unsigned>(p.y));
        mix(static_cast<unsigned>(p.z));
    }
    // Probabilities on nearby off-ray terrain still fall back to expiry.
    // Conservatively expire on timer: terrain changes may leave other stale state.
    unsigned long now=SDL_GetTicks();
    // Replay-free batched Monte Carlo: never perform more than 256
    // projectile traces in one frame. 1,024 trials are accumulated across
    // frames, while risk tiles stop at 384 trials (R19 performance budget).
    const bool newScenario = (key != _r22StatsKey);
    const bool staleFinished = (_r22SampleCount >= 1024U &&
        now-_r22StatsUpdated > 4500UL);
    if (newScenario || staleFinished)
    {
        _r22StatsText.clear();
        _r22TileRisks.clear();
        _r22SampleCount=0;
        _r22HitSamples=0;
        _r22BlockedSamples=0;
        _r22MissSamples=0;
        _r22RiskSamples=0;
        _r22StatsKey=key;
        _r22StatsUpdated=now;
        _r22StatsBatchTick=0;
    }
    // Animation redraws and mouse movement may run much faster than the
    // sampling budget. Do not repeat the expensive native traces each draw.
    if (_r22SampleCount < 1024U &&
        (newScenario || staleFinished || now-_r22StatsBatchTick>=95U))
    {
        _r22StatsBatchTick=now;
        const unsigned projectilesPerTrial=static_cast<unsigned>(shots*pellets);
        // Keep the first hover responsive. Allow more samples only when
        // the same cursor/weapon scenario persists. Worst case <=256 traces.
        const unsigned traceBudget=newScenario ? 24U : 96U;
        const unsigned frameBudget=std::max(1U,
            std::min(64U,std::min(256U,traceBudget)/projectilesPerTrial));
        const unsigned samples=std::min(1024U-_r22SampleCount,frameBudget);
        // Each batch has its own deterministic seed; never reseed every
        // frame to the same prefix of the old samples.
        const unsigned long long sampleSeed=key^
            (0x9e3779b97f4a7c15ULL*(_r22SampleCount+1ULL));
        struct KeepRng {
            RNG::RandomState previous;
            explicit KeepRng(unsigned long long seed)
                : previous(RNG::globalRandomState()) {
                RNG::globalRandomState()=RNG::RandomState(seed);
            }
            ~KeepRng() { RNG::globalRandomState()=previous; }
        } keep(sampleSeed ? sampleSeed : 1ULL);
        RNG::RandomState previewRng(sampleSeed ? sampleSeed : 1ULL);

        const int width=_save->getMapSizeX();
        const int length=_save->getMapSizeY();
        const int height=_save->getMapSizeZ();
        unsigned hit=0, blocked=0, missed=0;
        auto shot=[&](const Position& aimed, double acc, int shotIndex,
                      bool& isHit, bool& isBlocked,
                      std::set<int>& risk, Position& impact, Position& preImpact,
                      bool& rejectedByNative)
        {
            BattleAction fired=action;
            fired.autoShotCounter=shotIndex;
            Projectile projectile(_game->getMod(), _save, fired, origin, aimed, ammo);
            const int status=projectile.calculateTrajectory(acc,muzzle,true,true,&previewRng,virtualHasLOS,previewVacatedUnit);
            const std::vector<Position>& path=projectile.getTrajectoryForPreview();
            if (path.empty())
            {
                // The first projectile was NOT launched in OXCE.
                // Its burst cannot continue into later shot counters.
                rejectedByNative=true;
                isBlocked = true;
                return;
            }
            impact=path.back();
            preImpact=path.size()>2 ? path[path.size()-3] : path.front();
            // Only the first 384 trials contribute to risk. Avoid building
            // enormous voxel->tile sets for the remaining 640 H/B/M trials.
            if (_r22RiskSamples < 384U)
            {
                int previousTile=-1;
                for (const Position& voxel : path)
                {
                    if (voxel.x<0 || voxel.y<0 || voxel.z<0) continue;
                    int tx=voxel.x/16,ty=voxel.y/16,tz=voxel.z/24;
                    if (tx>=width || ty>=length || tz>=height) continue;
                    const int tileIndex=(tz*length+ty)*width+tx;
                    // Many voxels share one tile; insert once per contiguous
                    // tile segment, while the set still deduplicates pellets.
                    if (tileIndex != previousTile)
                    {
                        risk.insert(tileIndex);
                        previousTile=tileIndex;
                    }
                }
            }
            const Position collisionTile=impact.toTile();
            Tile *t=_save->getTile(collisionTile);
            BattleUnit *victim=t ? t->getOverlappingUnit(_save) : nullptr;
            if (victim && !victim->getVisible()) victim=nullptr;
            if (status==V_UNIT && victim && targetUnit && victim==targetUnit)
            {
                isHit=true; return;
            }
            if (!targetUnit && t && collisionTile==target &&
                status!=V_EMPTY && status!=V_OUTOFBOUNDS && status!=V_UNIT)
            {
                isHit=true; return;
            }
            if (status==V_EMPTY || status==V_OUTOFBOUNDS) return;
            const double dx=aim.x-muzzle.x,dy=aim.y-muzzle.y,dz=aim.z-muzzle.z;
            const double den=dx*dx+dy*dy+dz*dz;
            if (den>0)
            {
                const double proj=((impact.x-muzzle.x)*dx+
                     (impact.y-muzzle.y)*dy+(impact.z-muzzle.z)*dz)/den;
                if (proj<1.0) isBlocked=true;
            }
        };

        for (unsigned sample=0; sample<samples; ++sample)
        {
            bool anyHit=false, allBlocked=true;
            bool firstShotRejected=false;
            std::set<int> tileRisk;
            for (int shotIndex=1; shotIndex<=shots; ++shotIndex)
            {
                Position firstImpact=aim;
                for (int pellet=0; pellet<pellets; ++pellet)
                {
                    Position aimed=aim;
                    double pelletAcc=accuracy;
                    if (pellet && shotgun)
                    {
                        const int spread=ammo->getRules()->getShotgunSpread();
                        if (ammo->getRules()->getShotgunBehaviorType()==1)
                        {
                            if (firstImpact != muzzle) aimed=firstImpact;
                            pelletAcc=std::max(0.0,(1.0-spread/100.0)*
                                weapon->getRules()->getShotgunChoke()/100.0);
                        }
                        else pelletAcc=std::max(0.0,
                            accuracy-pellet*5.0*spread/100.0);
                    }
                    bool oneHit=false, oneBlocked=false;
                    Position collision=aim, nearCollision=aim;
                    bool nativeRejected=false;
                    shot(aimed,pelletAcc,shotIndex,oneHit,oneBlocked,
                         tileRisk,collision,nearCollision,nativeRejected);
                    if (shotIndex==1 && pellet==0 && nativeRejected)
                    {
                        firstShotRejected=true;
                        break;
                    }
                    if (pellet==0) firstImpact=nearCollision;
                    if (oneHit) anyHit=true;
                    if (!oneBlocked && !oneHit) allBlocked=false;
                }
                if (firstShotRejected) break;
            }
            if (firstShotRejected) ++blocked;
            else if (anyHit) ++hit;
            else if (allBlocked) ++blocked;
            else ++missed;
            if (_r22RiskSamples < 384U)
            {
                for (int t : tileRisk) ++_r22TileRisks[t];
                ++_r22RiskSamples;
            }
        }
        _r22HitSamples+=hit;
        _r22BlockedSamples+=blocked;
        _r22MissSamples+=missed;
        _r22SampleCount+=samples;
        std::ostringstream label;
        // All H/B/M samples are estimates, NOT the native hit stat.
        // Show n to distinguish an unstable 20-burst sample from
        // 1,024-burst convergence; auto counts whole bursts, not shots.
        label << "ACC~" << displayedAccuracy << "% "
              << "H~" << _r22HitSamples*100U/_r22SampleCount
              << "% B " << _r22BlockedSamples*100U/_r22SampleCount
              << "% M " << _r22MissSamples*100U/_r22SampleCount
              << "% n" << _r22SampleCount;
        _r22StatsText=label.str();
        if (_r22SampleCount >= 1024U) _r22StatsUpdated=now;
        // Map::think() schedules the next incremental redraw at a bounded
        // rate; never force another full frame from within drawing.
    }

    // Show at most one outline per tile, no opaque filled surfaces.
    int width=_save->getMapSizeX(), length=_save->getMapSizeY();
    for (const auto& entry : _r22TileRisks)
    {
        if (!_r22RiskSamples || entry.second*100U<_r22RiskSamples)
            continue; // 1% risk threshold, independent 384-trial budget
        int tx=entry.first%width,ty=(entry.first/width)%length;
        int tz=entry.first/(width*length);
        if (tz>_camera->getViewLevel()) continue;
        Tile *t=_save->getTile(Position(tx,ty,tz));
        if (!t || !t->isDiscovered(O_FLOOR)) continue;
        Position p;
        _camera->convertVoxelToScreen(Position(tx*16+8,ty*16+8,
            tz*24-t->getTerrainLevel()+1),&p);
        const unsigned riskPct=entry.second*100U/_r22RiskSamples;
        const int color=riskPct>=40U ? 32 : riskPct>=10U ? 160 : 73;
        // Open, one-pixel diamond perimeter; R19-style graduated hatching
        // without opaque fill or oversized LOS dots.
        drawLine(p.x-4,p.y,p.x,p.y-2,color);
        drawLine(p.x,p.y-2,p.x+4,p.y,color);
        drawLine(p.x+4,p.y,p.x,p.y+2,color);
        drawLine(p.x,p.y+2,p.x-4,p.y,color);
        if (riskPct>=25U)
        {
            drawLine(p.x-2,p.y-1,p.x,p.y+1,color);
            drawLine(p.x,p.y-1,p.x+2,p.y+1,color);
        }
        if (riskPct>=50U)
        {
            drawLine(p.x-4,p.y+1,p.x,p.y-1,color);
            drawLine(p.x,p.y-1,p.x+4,p.y+1,color);
        }
    }
    // The compact HUD is rendered once by Map::r22DrawOverlay().
}

void Map::r29ClearBlockGrid()
{
    _r29BlockCells.clear();
    _r29BlockKey = 0;
    _r29BlockNext = 0;
    _r29BlockPass = 3;
    _r29BlockStamp = 0;
    _r29BlockBatchStamp = 0;
}

// R29: map the chance that a COMPLETE trigger pull is blocked when firing
// from nearby hypothetical origins toward the first-click locked target.
// Separate isolated RNG, read-only snapshots, fog-limited drawing, and a
// bounded 128-projectile budget per UI refresh preserve native gameplay.
// R36: first-click candidate tiles for curved trajectories and spray fire.
// A flame/rocket/spit weapon may use calculateThrow(), not a straight-line
// Projectile. Never apply the straight-shot H/B/M Monte Carlo to its arc:
// show only origins that satisfy the SAME RuleItem::isOutOfRange predicate
// used by native fire. A range-valid tile is not a guaranteed clear shot.
void Map::r36DrawArcRangeGrid(BattleUnit *shooter, BattleAction *action,
                             const Position &target)
{
    if (!_r22On || !shooter || !action || !action->weapon ||
        !_save || !_camera || !action->targeting ||
        _camera->getViewLevel() < 0)
        return;
    Tile *targetTile = _save->getTile(target);
    if (!targetTile) return;
    BattleUnit *victim = targetTile->getOverlappingUnit(_save);
    if (victim && !victim->getVisible()) return;
    if (!victim && !targetTile->getVisible() &&
        !targetTile->isDiscovered(O_FLOOR)) return;

    const RuleItem *rule = action->weapon->getRules();
    if (!rule) return;
    const int maxRange = rule->getMaxRange();
    const int z = _camera->getViewLevel();
    // A maximum of 24 tiles in each axis keeps very-long-range mod
    // weapons bounded; only visible/discovered and traversable tiles
    // are drawn. The native range check is still applied to every tile.
    const int radius = std::min(24, std::max(2, maxRange + 2));
    const SDL_Color *palette = getPalette();
    if (!palette) return;
    int best = 1, score = 2147483647;
    for (int i = 1; i < 256; ++i)
    {
        const int dr = int(palette[i].r) - 50;
        const int dg = int(palette[i].g) - 220;
        const int db = int(palette[i].b) - 125;
        const int d = 2*dr*dr + 3*dg*dg + db*db;
        if (d < score) { score = d; best = i; }
    }
    const Uint8 rangeColor = static_cast<Uint8>(best);
    for (int dy = -radius; dy <= radius; ++dy)
    for (int dx = -radius; dx <= radius; ++dx)
    {
        const Position origin(target.x + dx, target.y + dy, z);
        Tile *tile = _save->getTile(origin);
        if (!tile || (!tile->getVisible() &&
            !tile->isDiscovered(O_FLOOR))) continue;
        if (tile->hasNoFloor(_save) && origin != shooter->getPosition())
            continue;
        MapData *object = tile->getMapData(O_OBJECT);
        if (object &&
            object->getTUCost(MT_WALK) >= Pathfinding::INVALID_MOVE_COST)
            continue;
        BattleUnit *occupant = tile->getOverlappingUnit(_save);
        if (occupant && occupant != shooter &&
            (occupant->getFaction() != shooter->getFaction() ||
             !occupant->getVisible())) continue;
        int ddx = origin.x - target.x;
        int ddy = origin.y - target.y;
        const int ddz = origin.z - target.z;
        if (shooter->isBigUnit())
        {
            if (origin.x < target.x) ++ddx;
            if (origin.y < target.y) ++ddy;
        }
        if (rule->isOutOfRange(ddx*ddx + ddy*ddy + ddz*ddz))
            continue;
        // Floor diamond uses the tile's own raised terrain level.
        const Position foot(origin.x*16, origin.y*16,
            origin.z*24 - tile->getTerrainLevel() + 1);
        const Position points[4] = {
            foot, foot + Position(16,0,0),
            foot + Position(16,16,0), foot + Position(0,16,0)
        };
        Position px[4];
        for (int i = 0; i < 4; ++i)
            _camera->convertVoxelToScreen(points[i], &px[i]);
        for (int i = 0; i < 4; ++i)
            drawLine(px[i].x, px[i].y, px[(i+1)%4].x,
                     px[(i+1)%4].y, rangeColor);
    }
    // Explicit distinction: these are range-permitted origins, never
    // hit probabilities or evidence that a wall-free arc exists.
    drawString(2, 16, action->sprayTargeting ?
        "SPRAY: RANGE-ONLY" : "ARC: RANGE-ONLY", rangeColor);
    r40RememberHudRect(0, 13, std::min(165, getWidth()), 13);
}

void Map::r29DrawTargetBlockGrid(BattleUnit *shooter, BattleAction *native,
                                  const Position &target)
{
    if (!_r22On || !shooter || !native || !native->weapon ||
        !_save || !_camera || !_save->getTileEngine())
    {
        r29ClearBlockGrid();
        return;
    }
    const bool throwing = native->type == BA_THROW;
    if (!throwing && native->type != BA_SNAPSHOT &&
        native->type != BA_AIMEDSHOT && native->type != BA_AUTOSHOT)
    {
        r29ClearBlockGrid();
        return;
    }
    BattleItem *weapon = native->weapon;
    if (!throwing && weapon->getArcingShot(native->type))
    {
        r29ClearBlockGrid();
        return;
    }
    BattleItem *ammo = throwing ? nullptr :
        weapon->getAmmoForAction(native->type, nullptr, nullptr);
    Tile *targetTile = _save->getTile(target);
    if ((!throwing && (!ammo || !ammo->getRules())) || !targetTile)
    {
        r29ClearBlockGrid();
        return;
    }
    BattleUnit *targetUnit = targetTile->getOverlappingUnit(_save);
    if (targetUnit && !targetUnit->getVisible()) targetUnit = nullptr;
    if (!targetUnit && !targetTile->getVisible() &&
        !targetTile->isDiscovered(O_FLOOR))
    {
        r29ClearBlockGrid(); // Never reveal a genuinely unknown target.
        return;
    }
    const RuleItemAction *config = throwing ? nullptr : weapon->getActionConf(native->type);
    unsigned shots = config ? std::max(1, config->shots) : 1;
    const int spend = config ? std::max(1, config->spendPerShot) : 1;
    if (!throwing && ammo->getRules()->getClipSize() > 0 &&
        ammo->getAmmoQuantity() >= 0 && ammo->getAmmoQuantity() < int(shots) * spend)
        shots = unsigned(ammo->getAmmoQuantity() / spend);
    const bool shotgun = !throwing && ammo->getRules()->getShotgunPellets() > 0 &&
                          ammo->getRules()->getDamageType()->isDirect();
    const unsigned pellets = shotgun ?
        unsigned(ammo->getRules()->getShotgunPellets()) : 1U;
    if (shots == 0 || shots > 16 || pellets == 0 || pellets > 20 ||
        shots * pellets > 48)
    {
        r29ClearBlockGrid(); // Unsupported large volleys must not freeze UI.
        return;
    }

    const int viewZ = _camera->getViewLevel();
    if (viewZ < 0 || viewZ >= _save->getMapSizeZ())
    {
        r29ClearBlockGrid();
        return;
    }
    const bool changedStance = _r22StanceOverride &&
                               _r22Kneel != shooter->isKneeled();
    const int stanceDelta = changedStance ?
        (_r22Kneel ? shooter->getKneelHeight() : shooter->getStandHeight())
          - shooter->getHeight() : 0;
    BattleAction baseAction = *native;
    baseAction.actor = shooter;
    baseAction.target = target;
    double accuracy = throwing ? 1.0 : BattleUnit::getFiringAccuracy(
        BattleActionAttack::GetAferShoot(baseAction, ammo), _game->getMod()) / 100.0;
    const double kneelFactor = weapon->getRules()->getKneelBonus(_game->getMod()) / 100.0;
    if (!throwing && changedStance && kneelFactor > 0.0)
        accuracy *= _r22Kneel ? kneelFactor : 1.0 / kneelFactor;

    unsigned long long key = 1469598103934665603ULL;
    auto mix = [&key](unsigned long long value) {
        key ^= value; key *= 1099511628211ULL;
    };
    mix(reinterpret_cast<uintptr_t>(shooter));
    mix(reinterpret_cast<uintptr_t>(weapon));
    mix(reinterpret_cast<uintptr_t>(ammo));
    mix(reinterpret_cast<uintptr_t>(targetUnit));
    for (int v : {int(target.x), int(target.y), int(target.z), viewZ,
                  int(shooter->getPosition().x), int(shooter->getPosition().y),
                  int(shooter->getPosition().z), int(native->type),
                  stanceDelta, int(shots), int(pellets),
                  throwing ? weapon->getTotalWeight() :
                  std::min(ammo->getAmmoQuantity(), int(shots) * spend),
                  int(accuracy * 100000.0)})
        mix(unsigned(v));
    const Uint32 now = SDL_GetTicks();
    if (key != _r29BlockKey ||
        ( _r29BlockPass == 3 && now - _r29BlockStamp > 8500U ))
    {
        r29ClearBlockGrid();
        _r29BlockKey = key;
        _r29BlockStamp = now;
        _r29BlockPass = 0;
        // R32: expand radius 9 -> 18. Work remains incremental; unknown
        // map cells and impassable origins are never scanned or painted.
        for (int radius = 1; radius <= 30; ++radius)
            for (int dy = -radius; dy <= radius; ++dy)
                for (int dx = -radius; dx <= radius; ++dx)
                {
                    if (std::max(std::abs(dx), std::abs(dy)) != radius ||
                        dx * dx + dy * dy > 900) continue;
                    const Position pos(target.x + dx, target.y + dy, viewZ);
                    Tile *tile = _save->getTile(pos);
                    if (!tile || (!tile->isDiscovered(O_FLOOR) && !tile->getVisible()))
                        continue;
                    if (tile->hasNoFloor(_save) && pos != shooter->getPosition())
                        continue;
                    MapData *object = tile->getMapData(O_OBJECT);
                    if (object && object->getTUCost(MT_WALK) >= Pathfinding::INVALID_MOVE_COST)
                        continue;
                    BattleUnit *occupant = tile->getOverlappingUnit(_save);
                    if (occupant && occupant != shooter &&
                        (throwing || (occupant->getVisible() &&
                         occupant->getFaction() != shooter->getFaction())))
                        continue;
                    int dxRange = pos.x - target.x, dyRange = pos.y - target.y;
                    int dzRange = pos.z - target.z;
                    if (shooter->isBigUnit())
                    {
                        if (pos.x < target.x) ++dxRange;
                        if (pos.y < target.y) ++dyRange;
                    }
                    if (!throwing && weapon->getRules()->isOutOfRange(
                            dxRange * dxRange + dyRange * dyRange + dzRange * dzRange))
                        continue;
                    R29BlockCell cell;
                    cell.source = pos;
                    _r29BlockCells.push_back(cell);
                }
        if (_r29BlockCells.empty()) _r29BlockPass = 3;
    }

    // Up to 128 native projectile trajectories per refresh, never per mouse
    // position. Sample 1, 4, then 8 full trigger pulls per candidate.
    if (_r29BlockPass < 3 &&
        ( _r29BlockBatchStamp == 0 || now - _r29BlockBatchStamp >= 85U ))
    {
        _r29BlockBatchStamp = now;
        TileEngine *engine = _save->getTileEngine();
        Tile *aimRoot = targetUnit ? _save->getTile(targetUnit->getPosition()) : nullptr;
        // Throws are geometric 5-point samples within the same target
        // tile, not gun RNG trials. Mark the legend accordingly below.
        const unsigned targetSamples[] = {1U, throwing ? 3U : 4U,
                                            throwing ? 5U : 8U};
        unsigned budget = throwing ? 12U : 128U;
        unsigned checkedOrigins = 0U;
        const unsigned cost = throwing ? 1U : shots * pellets;
        // Every call that could use global RNG is guarded as an additional
        // safety layer beyond Projectile's own isolated preview stream.
        struct RestoreRng
        {
            RNG::RandomState saved;
            RestoreRng() : saved(RNG::globalRandomState()) {}
            ~RestoreRng() { RNG::globalRandomState() = saved; }
        } keepRng;
        // Native canTargetUnit and LOS scans can be much costlier than
        // projectile traces. Cap them separately to avoid frame spikes.
        while (_r29BlockPass < 3 && budget >= cost &&
               checkedOrigins < (throwing ? 6U : 12U))
        {
            if (_r29BlockNext >= _r29BlockCells.size())
            {
                _r29BlockNext = 0;
                ++_r29BlockPass;
                if (_r29BlockPass == 3)
                    _r29BlockStamp = now; // Refresh after settling, not mid-scan.
                continue;
            }
            R29BlockCell &cell = _r29BlockCells[_r29BlockNext];
            if (cell.trials >= targetSamples[_r29BlockPass])
            {
                ++_r29BlockNext;
                continue;
            }
            ++checkedOrigins;
            Tile *sourceTile = _save->getTile(cell.source);
            if (!sourceTile)
            {
                cell.trials = throwing ? 5 : 8;
                ++_r29BlockNext;
                continue;
            }
            if (throwing)
            {
                // Same native range + parabola + target-tile collision test
                // as the live throw; never modify real unit/action/obstacles.
                // 5 voxel sample points reveal partial window/railing cover.
                const int deltaX[5] = {0, -4, 4, 0, 0};
                const int deltaY[5] = {0, 0, 0, -4, 4};
                const unsigned remaining = targetSamples[_r29BlockPass] - cell.trials;
                const unsigned count = std::min(remaining, budget);
                BattleAction throwingAction = baseAction;
                throwingAction.relativeOrigin = BattleActionOrigin::CENTRE;
                const Position throwOrigin = r32VirtualMuzzle(throwingAction,
                    sourceTile,stanceDelta,cell.source!=shooter->getPosition());
                for (unsigned n = 0; n < count; ++n)
                {
                    const unsigned sample = cell.trials;
                    const Position goal(target.x * 16 + 8 + deltaX[sample],
                        target.y * 16 + 8 + deltaY[sample],
                        target.z * 24 - targetTile->getTerrainLevel() + 1);
                    double arc = 0.0;
                    int collision = V_EMPTY;
                    bool clear = engine->validateThrow(throwingAction, throwOrigin,
                        goal, _save->getDepth(), &arc, &collision, false,
                        false, &cell.source,
                        (_r22StanceOverride ? _r22Kneel : shooter->isKneeled()) ? 1 : 0,
                        true);
                    if (clear)
                    {
                        std::vector<Position> trace;
                        const int end = engine->calculateParabolaVoxel(throwOrigin,
                            goal, true, &trace, shooter, arc,
                            Position(0,0,0), true);
                        clear = (end == V_FLOOR || end == V_UNIT || end == V_OBJECT) &&
                                !trace.empty();
                        if (clear)
                        {
                            Tile *landed = _save->getTile(Projectile::getPositionFromEnd(
                                trace, Projectile::ItemDropVoxelOffset).toTile());
                            if (!landed) clear = false;
                            else if (landed->getMapData(O_OBJECT) &&
                                landed->getMapData(O_OBJECT)->getTUCost(MT_WALK) ==
                                    Pathfinding::INVALID_MOVE_COST &&
                                !(landed->isBigWall() &&
                                  (landed->getMapData(O_OBJECT)->getBigWall() < 1 ||
                                   landed->getMapData(O_OBJECT)->getBigWall() > 3)))
                                clear = false;
                        }
                    }
                    if (!clear) ++cell.blocked;
                    else ++cell.hits;
                    ++cell.trials;
                }
                budget -= count;
                if (cell.trials >= targetSamples[_r29BlockPass]) ++_r29BlockNext;
                continue;
            }
            BattleUnit *vacated = cell.source != shooter->getPosition() ?
                sourceTile->getOverlappingUnit(_save) : nullptr;
            if (vacated && (vacated == shooter ||
                vacated->getFaction() != shooter->getFaction()))
                vacated = nullptr;
            BattleAction firing = baseAction;
            firing.relativeOrigin = BattleActionOrigin::CENTRE;
            firing.autoShotCounter = 1;
            Position muzzle = r32VirtualMuzzle(firing,sourceTile,stanceDelta,
                cell.source!=shooter->getPosition());
            Position aim(target.x * 16 + 8, target.y * 16 + 8,
                target.z * 24 - targetTile->getTerrainLevel() +
                (targetUnit ? std::max(3, targetUnit->getHeight() / 2) : 12));
            // Pick an actually exposed native target voxel, including a
            // visible unit whose underlying FLOOR remains undiscovered.
            if (targetUnit && aimRoot)
            {
                const BattleActionOrigin sides[3] = {
                    BattleActionOrigin::CENTRE,
                    BattleActionOrigin::LEFT, BattleActionOrigin::RIGHT
                };
                for (int side = 0; side < 3; ++side)
                {
                    if (side > 0 && !Options::oxceEnableOffCentreShooting) break;
                    BattleAction test = firing;
                    test.relativeOrigin = sides[side];
                    Position trialMuzzle = r32VirtualMuzzle(test,sourceTile,stanceDelta,
                        cell.source!=shooter->getPosition());
                    Position trialAim = aim;
                    if (engine->canTargetUnit(&trialMuzzle, aimRoot, &trialAim,
                        shooter, false, nullptr, true, vacated))
                    {
                        firing.relativeOrigin = sides[side];
                        muzzle = trialMuzzle;
                        aim = trialAim;
                        break;
                    }
                }
            }
            else
            {
                TilePart part = O_FLOOR;
                if (targetTile->getMapData(O_OBJECT)) part = O_OBJECT;
                else if (targetTile->getMapData(O_NORTHWALL)) part = O_NORTHWALL;
                else if (targetTile->getMapData(O_WESTWALL)) part = O_WESTWALL;
                Position trialAim = aim;
                if (engine->canTargetTile(&muzzle, targetTile, part,
                    &trialAim, shooter, false, vacated))
                    aim = trialAim;
            }
            // A failed direct-voxel scan must NOT force B=100: native
            // scatter can still produce a reachable trajectory. Use the
            // geometric fallback and actually sample its projectiles.
            int virtualLOS = 1;
            if (weapon->getRules()->getNoLOSAccuracyPenalty(_game->getMod()) != -1)
            {
                Tile *aimTile = _save->getTile(aim.toTile());
                if (!aimTile) aimTile = targetTile;
                virtualLOS = aimTile->getUnit() ?
                    (engine->r25VirtualVisible(shooter, aimTile, cell.source, stanceDelta) ? 1 : 0) :
                    (engine->r25VirtualTileInLOS(&firing, aimTile, false,
                        cell.source, stanceDelta) ? 1 : 0);
            }
            const unsigned remaining = targetSamples[_r29BlockPass] - cell.trials;
            const unsigned count = std::min(remaining, budget / cost);
            for (unsigned n = 0; n < count; ++n)
            {
                unsigned long long seed = key;
                for (int v : {int(cell.source.x), int(cell.source.y), int(cell.source.z), int(cell.trials)})
                {
                    seed ^= unsigned(v);
                    seed *= 1099511628211ULL;
                }
                RNG::RandomState previewRng(seed ? seed : 1ULL);
                bool hit = false, allBlocked = true, nativeRejected = false;
                for (unsigned shot = 1; shot <= shots && !nativeRejected; ++shot)
                {
                    Position firstImpact = aim;
                    for (unsigned pellet = 0; pellet < pellets; ++pellet)
                    {
                        Position pelletAim = aim;
                        double pelletAccuracy = accuracy;
                        if (pellet && shotgun)
                        {
                            const int spread = ammo->getRules()->getShotgunSpread();
                            if (ammo->getRules()->getShotgunBehaviorType() == 1)
                            {
                                if (firstImpact != muzzle) pelletAim = firstImpact;
                                pelletAccuracy = std::max(0.0,
                                    (1.0 - spread / 100.0) *
                                    weapon->getRules()->getShotgunChoke() / 100.0);
                            }
                            else
                                pelletAccuracy = std::max(0.0,
                                    accuracy - pellet * 5.0 * spread / 100.0);
                        }
                        firing.autoShotCounter = shot;
                        Projectile projectile(_game->getMod(), _save, firing,
                            cell.source, pelletAim, ammo);
                        const int status = projectile.calculateTrajectory(
                            pelletAccuracy, muzzle, true, true,
                            &previewRng, virtualLOS, vacated);
                        const std::vector<Position> &trace =
                            projectile.getTrajectoryForPreview();
                        if (trace.empty())
                        {
                            if (shot == 1 && pellet == 0)
                                nativeRejected = true;
                            continue;
                        }
                        if (pellet == 0)
                            firstImpact = trace.size() > 2 ?
                                trace[trace.size() - 3] : trace.front();
                        const Position &end = trace.back();
                        const Position endTilePos = end.toTile();
                        Tile *endTile = _save->getTile(endTilePos);
                        BattleUnit *victim = endTile ?
                            endTile->getOverlappingUnit(_save) : nullptr;
                        if (victim && !victim->getVisible()) victim = nullptr;
                        const bool oneHit = (status == V_UNIT &&
                            targetUnit && victim == targetUnit) ||
                            (!targetUnit && endTile && endTilePos == target &&
                             status != V_EMPTY && status != V_OUTOFBOUNDS &&
                             status != V_UNIT);
                        if (oneHit)
                        {
                            hit = true;
                            continue;
                        }
                        bool oneBlocked = false;
                        if (status != V_EMPTY && status != V_OUTOFBOUNDS)
                        {
                            const double vx = aim.x - muzzle.x;
                            const double vy = aim.y - muzzle.y;
                            const double vz = aim.z - muzzle.z;
                            const double denom = vx*vx + vy*vy + vz*vz;
                            if (denom > 0.0)
                                oneBlocked = ((end.x-muzzle.x)*vx +
                                    (end.y-muzzle.y)*vy +
                                    (end.z-muzzle.z)*vz) < denom;
                        }
                        if (!oneBlocked) allBlocked = false;
                    }
                }
                if (!hit && (nativeRejected || allBlocked))
                    ++cell.blocked;
                if (hit) ++cell.hits;
                ++cell.trials;
            }
            budget -= count * cost;
            if (cell.trials >= targetSamples[_r29BlockPass])
                ++_r29BlockNext;
        }
    }

    // Explicitly display B, not H, and never display unvisited cells. Using
    // real voxel-plane floor diamonds keeps slope/raised terrain aligned.
    const SDL_Color *palette = getPalette();
    if (!palette) return;
    auto nearest = [palette](int red, int green, int blue) -> Uint8 {
        int best = 1, score = 2147483647;
        for (int i = 1; i < 256; ++i)
        {
            const int dr = int(palette[i].r) - red;
            const int dg = int(palette[i].g) - green;
            const int db = int(palette[i].b) - blue;
            const int dist = 2*dr*dr + 3*dg*dg + db*db;
            if (dist < score) { score = dist; best = i; }
        }
        return Uint8(best);
    };
    const Uint8 colors[] = {
        nearest(48, 245, 95), nearest(179, 239, 57),
        nearest(255, 223, 46), nearest(255, 135, 27),
        nearest(246, 48, 48)
    };
    for (const R29BlockCell &cell : _r29BlockCells)
    {
        if (!cell.trials) continue;
        Tile *tile = _save->getTile(cell.source);
        if (!tile || (!tile->getVisible() && !tile->isDiscovered(O_FLOOR)))
            continue;
        const unsigned h = (100U * cell.hits + cell.trials / 2U) / cell.trials;
        const unsigned band = h >= 75U ? 0 : h >= 50U ? 1 :
                              h >= 25U ? 2 : h >= 10U ? 3 : 4;
        const Uint8 color = colors[band];
        const Position floor(cell.source.x * 16, cell.source.y * 16,
            cell.source.z * 24 - tile->getTerrainLevel() + 1);
        const Position voxels[] = {floor, floor+Position(16,0,0),
            floor+Position(16,16,0), floor+Position(0,16,0)};
        Position pixel[4];
        for (int i = 0; i < 4; ++i)
            _camera->convertVoxelToScreen(voxels[i], &pixel[i]);
        for (int i = 0; i < 4; ++i)
            drawLine(pixel[i].x, pixel[i].y, pixel[(i+1)%4].x,
                pixel[(i+1)%4].y, color);
        // Denser marking for severe blockage; leave terrain readable.
        if (band >= 2)
        {
            drawLine(pixel[0].x, pixel[0].y+1, pixel[2].x,
                pixel[2].y-1, color);
        }
        if (band >= 4)
        {
            drawLine(pixel[3].x, pixel[3].y, pixel[1].x,
                pixel[1].y, color);
        }
    }
    // Five immutable bands; each cursor-position HUD still gives its more
    // precise n=1024 H/B/M estimator. Cells here refine n=1 -> n=4 -> n=8.
    const Uint8 dark = nearest(15, 15, 22);
    const Uint8 bright = nearest(255, 255, 255);
    drawRect(0, 13, std::min(320, getWidth()), 13, dark);
    drawString(2, 16, throwing ? "ARC H GRID n1-5" : "H GRID n1-8", bright);
    const char *labels[] = {"75+", "50", "25", "10", "<10"};
    for (int i = 0; i < 5; ++i)
    {
        const int x = 103 + i * 41;
        drawRect(x, 17, 6, 6, colors[i]);
        drawString(x + 8, 16, labels[i], bright);
    }
    r40RememberHudRect(0, 13, std::min(320, getWidth()), 13);
}

void Map::refreshAIProgress(int progress)
{
	if (_save->getSide() == FACTION_NEUTRAL)
	{
		_message->setProgressBarColor(_neutralBarColor, _borderBarColor);
	}
	else
	{
		_message->setProgressBarColor(_hostileBarColor, _borderBarColor);
	}
	_message->setProgressValue(progress);
}

/**
 * Replaces a certain amount of colors in the surface's palette.
 * @param colors Pointer to the set of colors.
 * @param firstcolor Offset of the first color to replace.
 * @param ncolors Amount of colors to replace.
 */
void Map::setPalette(const SDL_Color *colors, int firstcolor, int ncolors)
{
	Surface::setPalette(colors, firstcolor, ncolors);
	for (auto* mds : *_save->getMapDataSets())
	{
		mds->getSurfaceset()->setPalette(colors, firstcolor, ncolors);
	}
	_message->setPalette(colors, firstcolor, ncolors);
	refreshHiddenMovementBackground();
	_message->initText(_game->getMod()->getFont("FONT_BIG"), _game->getMod()->getFont("FONT_SMALL"), _game->getLanguage());
	_message->setText(_game->getLanguage()->getString("STR_HIDDEN_MOVEMENT"), _game->getLanguage()->getString("STR_THINKING"));
}

void Map::refreshHiddenMovementBackground()
{
	_message->setBackground(_game->getMod()->getSurface(_save->getHiddenMovementBackground()));
}

/**
 * Get shade of wall.
 * @param part For what wall do calculations.
 * @param tileFrot Tile of wall.
 * @return Current shade of wall.
 */
int Map::getWallShade(TilePart part, Tile* tileFrot)
{
	int shade;
	if (tileFrot->isDiscovered(O_FLOOR))
	{
		shade = reShade(tileFrot);
	}
	else
	{
		shade = 16;
	}
	if (part)
	{
		if ((tileFrot->isDoor(part) || tileFrot->isUfoDoor(part)) && tileFrot->isDiscovered(part))
		{
			Position offset =
				part == O_NORTHWALL ? Position(1,0,0) :
				part == O_WESTWALL ? Position(0,1,0) :
					throw Exception("Unsupported tile part for wall shade");

			Tile *tileBehind = _save->getTile(tileFrot->getPosition() - offset);

			shade = std::min(reShade(tileFrot), tileBehind ? tileBehind->getShade() + 5 : 16);
		}
	}
	return shade;
}

/**
 * Check two positions if have same XY cords
 */
static bool positionHaveSameXY(Position a, Position b)
{
	return a.x == b.x && a.y == b.y;
}

/**
 * Check two positions if have same XY cords
 */
static bool positionInRangeXY(Position a, Position b, int diff)
{
	return std::abs(a.x - b.x) <= diff && std::abs(a.y - b.y) <= diff;
}

namespace
{

static const int ArrowBobOffsets[8] = {0,1,2,1,0,1,2,1};

static const int ArrowColorsUFO[4]  = { 6,  3, 14, 4 }; // white,    red, blue, green
static const int ArrowColorsTFTD[4] = { 4, 11, 16, 6 }; // white, orange, blue, green

int getArrowBobForFrame(int frame)
{
	return ArrowBobOffsets[frame % 8];
}

int getShadePulseForFrame(int shade, int frame)
{
	if (shade > 7) shade = 7;
	if (shade < 2) shade = 2;
	shade += (ArrowBobOffsets[frame % 8] * 2 - 2);
	return shade;
}

}
/**
 * R41: draw a physically-owned world wall on its rotated visual edge.
 * Source wall art is never modified: swap-side 90/270 deg perspectives
 * are cached as 8-bit horizontal mirrors for smooth frame rendering.
 * The wall's discovery, shade, door frame and obstacle flags remain
 * attached to its original world tile; battle physics are untouched.
 */
void Map::r41BlitWall(Surface *surface, Tile *owner, TilePart part,
    int x, int y, bool half, bool mirror)
{
    // Mirrored walls may belong to an adjacent tile. Do not expose
    // undiscovered geometry merely because the display tile is known.
    if (!owner || (!owner->isDiscovered(O_FLOOR) && !owner->isDiscovered(part)))
        return;
    SurfaceRaw<const Uint8> wall = owner->getSprite(part);
    if (!wall) return;
    if (mirror)
    {
        const int width = wall.getWidth(), height = wall.getHeight();
        const int pitch = wall.getPitch();
        auto key = std::make_tuple(wall.getBuffer(),width,height,pitch);
        auto found = _r41WallFlipCache.find(key);
        if (found == _r41WallFlipCache.end())
        {
            std::vector<Uint8> flipped(static_cast<size_t>(width) * height);
            const Uint8 *data = wall.getBuffer();
            for (int sy = 0; sy < height; ++sy)
            for (int sx = 0; sx < width; ++sx)
                flipped[static_cast<size_t>(sy) * width + sx] =
                    data[static_cast<size_t>(sy) * pitch + (width - 1 - sx)];
            found = _r41WallFlipCache.emplace(key,std::move(flipped)).first;
        }
        wall = SurfaceRaw<const Uint8>(found->second.data(),width,height,width);
    }
    const int wallShade = getWallShade(part,owner);
    const int shade = owner->getObstacle(part)
        ? getShadePulseForFrame(wallShade,_animFrame) : wallShade;
    Surface::blitRaw(surface,wall,x,y-owner->getYOffset(part),shade,half,_nvColor);
}

/**
 * Draw part of unit graphic that overlap current tile.
 * @param surface
 * @param unitTile
 * @param currTile
 * @param currTileScreenPosition
 * @param shade
 * @param obstacleShade
 * @param topLayer
 */
void Map::drawUnit(UnitSprite &unitSprite, Tile *unitTile, Tile *currTile, Position currTileScreenPosition, bool topLayer, BattleUnit* movingUnit)
{
	const int tileFoorWidth = 32;
	const int tileFoorHeight = 16;
	const int tileHeight = 40;

	if (!unitTile)
	{
		return;
	}
	BattleUnit* bu = unitTile->getOverlappingUnit(_save, TUO_ALWAYS);
	Position unitOffset;
	bool unitFromBelow = false;
	bool unitFromAbove = false;
	if (bu)
	{
		if (bu != unitTile->getUnit())
		{
			unitFromBelow = true;
		}
	}
	else if (movingUnit && unitTile == currTile)
	{
		auto* upperTile = _save->getAboveTile(unitTile);
		if (upperTile && upperTile->hasNoFloor(_save))
		{
			bu = upperTile->getUnit();
		}
		if (bu != movingUnit)
		{
			return;
		}
		unitFromAbove = true;
	}
	else
	{
		return;
	}

	if (!(bu->getVisible() || _save->getDebugMode()))
	{
		return;
	}

	unitOffset.x = unitTile->getPosition().x - bu->getPosition().x;
	unitOffset.y = unitTile->getPosition().y - bu->getPosition().y;
	int part = unitOffset.x + unitOffset.y*2;

	bool moving = bu->getStatus() == STATUS_WALKING || bu->getStatus() == STATUS_FLYING;
	int bonusWidth = moving ? 0 : tileFoorWidth;
	int topMargin = 0;
	int bottomMargin = 0;

	//if unit is from below then we draw only part that in in tile
	if (unitFromBelow)
	{
		bottomMargin = -tileFoorHeight / 2;
		topMargin = tileFoorHeight;
	}
	else if (topLayer)
	{
		topMargin = 2 * tileFoorHeight;
	}
	else
	{
		const Tile *top = _save->getAboveTile(unitTile);
		if (top && top->getOverlappingUnit(_save, TUO_ALWAYS) == bu)
		{
			topMargin = -tileFoorHeight / 2;
		}
		else
		{
			topMargin = tileFoorHeight;
		}
	}

	GraphSubset mask = GraphSubset(tileFoorWidth + bonusWidth, tileHeight + topMargin + bottomMargin).offset(currTileScreenPosition.x - bonusWidth / 2, currTileScreenPosition.y - topMargin);

	if (moving)
	{
		GraphSubset leftMask = mask.offset(-tileFoorWidth/2, 0);
		GraphSubset rightMask = mask.offset(+tileFoorWidth/2, 0);
		// Moving-unit slice masks follow the rotated screen direction.
		int direction = (bu->getDirection() + 8 - 2 * _r41Rotation) & 7;
		auto visualToWorld = [&](Position offset) -> Position
		{
			switch (_r41Rotation)
			{
			case 1: return Position(-offset.y,offset.x,offset.z);
			case 2: return Position(-offset.x,-offset.y,offset.z);
			case 3: return Position(offset.y,-offset.x,offset.z);
			default: return offset;
			}
		};
		Position partCurr = currTile->getPosition();
		Position partDest = bu->getDestination() + unitOffset;
		Position partLast = bu->getLastPosition() + unitOffset;
		bool isTileDestPos = positionHaveSameXY(partDest, partCurr);
		bool isTileLastPos = positionHaveSameXY(partLast, partCurr);

		if (unitFromAbove && partLast != unitTile->getPosition())
		{
			//this tile is below moving unit and it do not change levels, nothing to draw
			return;
		}

		//adjusting mask
		if (positionHaveSameXY(partLast, partDest))
		{
			if (currTile == unitTile)
			{
				//no change
			}
			else
			{
				//nothing to draw
				return;
			}
		}
		else if (isTileDestPos)
		{
			//unit is moving to this tile
			switch (direction)
			{
			case 0:
			case 1:
				mask = GraphSubset::intersection(mask, rightMask);
				break;
			case 2:
				//no change
				break;
			case 3:
				//no change
				break;
			case 4:
				//no change
				break;
			case 5:
			case 6:
				mask = GraphSubset::intersection(mask, leftMask);
				break;
			case 7:
				//nothing to draw
				return;
			}
		}
		else if (isTileLastPos)
		{
			//unit is exiting this tile
			switch (direction)
			{
			case 0:
				//no change
				break;
			case 1:
			case 2:
				mask = GraphSubset::intersection(mask, leftMask);
				break;
			case 3:
				//nothing to draw
				return;
			case 4:
			case 5:
				mask = GraphSubset::intersection(mask, rightMask);
				break;
			case 6:
				//no change
				break;
			case 7:
				//no change
				break;
			}
		}
		else
		{
			Position leftPos = partCurr + visualToWorld(Position(-1, 0, 0));
			Position rightPos = partCurr + visualToWorld(Position(0, -1, 0));
			if (!topLayer && (partDest.z > partCurr.z || partLast.z > partCurr.z))
			{
				//unit change layers, it will be drawn by upper layer not lower.
				return;
			}
			else if (
				(direction == 1 && (partDest == rightPos || partLast == leftPos)) ||
				(direction == 5 && (partDest == leftPos || partLast == rightPos)))
			{
				mask = GraphSubset(tileFoorWidth, tileHeight + 2 * tileFoorHeight).offset(currTileScreenPosition.x, currTileScreenPosition.y - 2 * tileFoorHeight);
			}
			else
			{
				//unit is not moving close to tile
				return;
			}
		}
	}
	else if (unitTile != currTile || unitFromAbove)
	{
		return;
	}

	Position tileScreenPosition;
	_camera->convertMapToScreen(unitTile->getPosition() + Position(0,0, (-unitFromBelow) + (+unitFromAbove)), &tileScreenPosition);
	tileScreenPosition += _camera->getMapOffset();

	//get shade helpers
	auto getTileShade = [&](Tile* tile)
	{
		return tile ? (tile->isDiscovered(O_FLOOR) ? reShade(tile) : 16) : 16;
	};
	auto getMixedTileShade = [&](Tile* tile, int heightOffset, bool below)
	{
		int shadeLower = 0;
		int shadeUpper = 0;
		if (below)
		{
			shadeLower = getTileShade(_save->getBelowTile(tile));
			shadeUpper = getTileShade(tile);
		}
		else
		{
			shadeLower = getTileShade(tile);
			shadeUpper = getTileShade(_save->getAboveTile(tile));
		}

		return Interpolate(shadeLower, shadeUpper, -heightOffset, Position::TileZ);
	};

	// draw unit
	int shade = 0;
	UnitWalkingOffset offsets = calculateWalkingOffset(bu);
	if (moving)
	{
		const Position start = bu->getPosition();
		const Position end = bu->getDestination();
		const auto minLevel = std::min(start.z, end.z); // Sint16
		const int startShade = getMixedTileShade(_save->getTile(start), start.z == minLevel ? offsets.TerrainLevelOffset : 0, false);
		const int endShade = getMixedTileShade(_save->getTile(end), end.z == minLevel ? offsets.TerrainLevelOffset : 0, false);
		shade = Interpolate(startShade, endShade, offsets.NormalizedMovePhase, 16);
	}
	else
	{
		shade = getMixedTileShade(currTile, offsets.TerrainLevelOffset, unitFromBelow);
		if (_showObstacles && unitTile->getObstacle(4))
		{
			shade = getShadePulseForFrame(shade, _animFrame);
		}
	}
	if (_debugVisionMode == 1)
	{
		shade = std::min(+NIGHT_VISION_SHADE, shade);
	}
	unitSprite.draw(bu, part, tileScreenPosition.x + offsets.ScreenOffset.x, tileScreenPosition.y + offsets.ScreenOffset.y, shade, mask, _isAltPressed && !_isCtrlPressed);
}

/**
 * Draw the terrain.
 * Keep this function as optimised as possible. It's big to minimise overhead of function calls.
 * @param surface The surface to draw on.
 */
void Map::drawTerrain(Surface *surface)
{
	_isAltPressed = _game->isAltPressed(true);
	_isCtrlPressed = _game->isCtrlPressed(true);
	int frameNumber = 0;
	SurfaceRaw<const Uint8> tmpSurface;
	Tile *tile;
	int beginX = 0, endX = _save->getMapSizeX() - 1;
	int beginY = 0, endY = _save->getMapSizeY() - 1;
	int beginZ = 0, endZ = _save->getMapSizeZ() - 1;
	Position mapPosition, screenPosition, bulletPositionScreen, movingUnitPosition;
	int bulletLowX=16000, bulletLowY=16000, bulletLowZ=16000, bulletHighX=0, bulletHighY=0, bulletHighZ=0;
	int dummy;
	BattleUnit *movingUnit = _save->getTileEngine()->getMovingUnit();
	int tileShade, tileColor, obstacleShade;
	UnitSprite unitSprite(surface, _game->getMod(), _save, _animFrame, _save->getDepth() != 0,
		_isTFTD ? ArrowColorsTFTD[1] : ArrowColorsUFO[1], _isTFTD ? ArrowColorsTFTD[2] : ArrowColorsUFO[2], _r41Rotation);
	ItemSprite itemSprite(surface, _game->getMod(), _save, _animFrame);

	const int halfAnimFrame = (_animFrame / 2) % 4;
	const int halfAnimFrameRest = (_animFrame % 2);

	NumberText *_numWaypid = 0;

	// if we got bullet, get the highest x and y tiles to draw it on
	if (_projectile && _explosions.empty())
	{
		int part = _projectile->getItem() ? 0 : BULLET_SPRITES-1;
		for (int i = 0; i <= part; ++i)
		{
			if (_projectile->getPosition(1-i).x < bulletLowX)
				bulletLowX = _projectile->getPosition(1-i).x;
			if (_projectile->getPosition(1-i).y < bulletLowY)
				bulletLowY = _projectile->getPosition(1-i).y;
			if (_projectile->getPosition(1-i).z < bulletLowZ)
				bulletLowZ = _projectile->getPosition(1-i).z;
			if (_projectile->getPosition(1-i).x > bulletHighX)
				bulletHighX = _projectile->getPosition(1-i).x;
			if (_projectile->getPosition(1-i).y > bulletHighY)
				bulletHighY = _projectile->getPosition(1-i).y;
			if (_projectile->getPosition(1-i).z > bulletHighZ)
				bulletHighZ = _projectile->getPosition(1-i).z;
		}
		// divide by 16 to go from voxel to tile position
		bulletLowX = bulletLowX / 16;
		bulletLowY = bulletLowY / 16;
		bulletLowZ = bulletLowZ / 24;
		bulletHighX = bulletHighX / 16;
		bulletHighY = bulletHighY / 16;
		bulletHighZ = bulletHighZ / 24;

		// if the projectile is outside the viewport - center it back on it
		_camera->convertVoxelToScreen(_projectile->getPosition(), &bulletPositionScreen);

		if (_projectileInFOV && _followProjectile)
		{
			Position newCam = _camera->getMapOffset();
			if (newCam.z != bulletHighZ) //switch level
			{
				newCam.z = bulletHighZ;
				if (_projectileInFOV)
				{
					_camera->setMapOffset(newCam);
					_camera->convertVoxelToScreen(_projectile->getPosition(), &bulletPositionScreen);
				}
			}
			if (_smoothCamera)
			{
				if (_launch)
				{
					_launch = false;
					if ((bulletPositionScreen.x < 1 || bulletPositionScreen.x > surface->getWidth() - 1 ||
						bulletPositionScreen.y < 1 || bulletPositionScreen.y > _visibleMapHeight - 1))
					{
						_camera->centerOnPosition(Position(bulletLowX, bulletLowY, bulletHighZ), false);
						_camera->convertVoxelToScreen(_projectile->getPosition(), &bulletPositionScreen);
					}
				}
				if (!_smoothingEngaged)
				{
					if (bulletPositionScreen.x < 1 || bulletPositionScreen.x > surface->getWidth() - 1 ||
						bulletPositionScreen.y < 1 || bulletPositionScreen.y > _visibleMapHeight - 1)
					{
						_smoothingEngaged = true;
					}
				}
				else
				{
					_camera->jumpXY(surface->getWidth() / 2 - bulletPositionScreen.x, _visibleMapHeight / 2 - bulletPositionScreen.y);
				}
			}
			else
			{
				bool enough;
				do
				{
					enough = true;
					if (bulletPositionScreen.x < 0)
					{
						_camera->jumpXY(+surface->getWidth(), 0);
						enough = false;
					}
					else if (bulletPositionScreen.x > surface->getWidth())
					{
						_camera->jumpXY(-surface->getWidth(), 0);
						enough = false;
					}
					else if (bulletPositionScreen.y < 0)
					{
						_camera->jumpXY(0, +_visibleMapHeight);
						enough = false;
					}
					else if (bulletPositionScreen.y > _visibleMapHeight)
					{
						_camera->jumpXY(0, -_visibleMapHeight);
						enough = false;
					}
					_camera->convertVoxelToScreen(_projectile->getPosition(), &bulletPositionScreen);
				}
				while (!enough);
			}
		}
	}

	// R41: the original culler assumes X grows down-right and Y down-left.
	// Use native fast culling at 0 degrees, but the full map bounds when
	// rotated to avoid losing tiles on any of the four projection quadrants.
	if (_r41Rotation == 0)
	{
		_camera->convertScreenToMap(0, 0, &beginX, &dummy);
		_camera->convertScreenToMap(surface->getWidth(), 0, &dummy, &beginY);
		_camera->convertScreenToMap(surface->getWidth() + _spriteWidth, surface->getHeight() + _spriteHeight, &endX, &dummy);
		_camera->convertScreenToMap(0, surface->getHeight() + _spriteHeight, &dummy, &endY);
		beginY -= (_camera->getViewLevel() * 2);
		beginX -= (_camera->getViewLevel() * 2);
		if (beginX < 0) beginX = 0;
		if (beginY < 0) beginY = 0;
	}
	else
	{
		// Conservative rotation-independent viewport culling. Four corners
		// padded for upper layers, shadows and tall walls, clipped to map.
		const int px = _spriteWidth * 2, py = _spriteHeight * 2;
		const int corners[4][2] = {
			{-px,-py}, {surface->getWidth()+px,-py},
			{-px,surface->getHeight()+py},
			{surface->getWidth()+px,surface->getHeight()+py}
		};
		int loX = _save->getMapSizeX(), hiX = 0;
		int loY = _save->getMapSizeY(), hiY = 0;
		for (const auto &corner : corners)
		{
			int x = 0, y = 0;
			_camera->convertScreenToMap(corner[0],corner[1],&x,&y);
			loX = std::min(loX,x); hiX = std::max(hiX,x);
			loY = std::min(loY,y); hiY = std::max(hiY,y);
		}
		const int margin = 4 + _camera->getViewLevel() * 2;
		beginX = std::max(0,loX-margin);
		beginY = std::max(0,loY-margin);
		endX = std::min(_save->getMapSizeX(),hiX+margin+1);
		endY = std::min(_save->getMapSizeY(),hiY+margin+1);
	}

	if (!_camera->getShowAllLayers())
	{
		endZ = std::min(endZ, _camera->getViewLevel());
	}
	if (_camera->getShowSingleLayer())
	{
		beginZ = _camera->getViewLevel();
		endZ = _camera->getViewLevel();
	}


	bool pathfinderTurnedOn = _save->getPathfinding()->isPathPreviewed();

	if (!_waypoints.empty() || (pathfinderTurnedOn && (_previewSettingTu || _previewSettingEnergy)))
	{
		_numWaypid = new NumberText(15, 15, 20, 30);
		_numWaypid->setPalette(getPalette());
		_numWaypid->setColor(pathfinderTurnedOn ? _messageColor + 1 : Palette::blockOffset(1));
	}

	if (movingUnit)
	{
		movingUnitPosition = movingUnit->getPosition();
	}

	// R43_QA_ONLY: keep the craft centered without moving the real mouse.
	if (r43QaPin && _camera)
	{
		_camera->stopMouseScrolling();
		_camera->stopKeyScrolling();
		_camera->centerOnPosition(r43QaCenter,false);
	}
	surface->lock();
	const Position cameraPos = _camera->getMapOffset();
	// R44: Terrain-data driven stair reprojection. Unlike the aircraft's
	// special ramp, architectural stair sprites contain both treads and
	// their vertical risers. Never rotate every negative terrain-level
	// object: rocks and cliffs use the same MCD height field.
	auto r44RotatedStair = [&](Tile *paintTile, TilePart part,
		SurfaceRaw<const Uint8> source) -> SurfaceRaw<const Uint8>
	{
		if (_r41Rotation == 0 || !source || !paintTile ||
			source.getWidth() != 32 || source.getHeight() != 40)
			return source;
		MapData *data = paintTile->getMapData(part);
		if (!data || !data->getDataset() ||
			(part != O_OBJECT && part != O_FLOOR) ||
			data->getYOffset() != 0 || data->getBigWall() > 1 ||
			data->getTUCost(MT_WALK) >= 255)
			return source;
		const int t = data->getTerrainLevel();
		if (t >= 0 || t <= -24) return source;
		const int topHeight = -t;
		// Locate a neighboring stair of a DIFFERENT height in the
		// SAME terrain family, then infer world-up instead of assuming
		// north, south, east or west. Contradictory axes are ambiguous.
		const Position steps[4] = {Position(1,0,0),Position(-1,0,0),
			Position(0,1,0),Position(0,-1,0)};
		int up = -1, rise = 0;
		for (int i = 0; i != 4; ++i)
		{
			Tile *neighbor = _save->getTile(paintTile->getPosition() + steps[i]);
			MapData *other = neighbor ? neighbor->getMapData(part) : nullptr;
			if (!other || !other->getDataset() ||
				other->getDataset()->getName() != data->getDataset()->getName() ||
				other->getYOffset() != 0 || other->getBigWall() > 1 ||
				other->getTUCost(MT_WALK) >= 255) continue;
			const int otherT = other->getTerrainLevel();
			const int delta = std::abs(t - otherT);
			if (otherT >= 0 || otherT <= -24 ||
				(delta != 4 && delta != 6 && delta != 8 && delta != 10))
				continue;
			const int inferred = otherT < t ? i : (i ^ 1);
			if (up >= 0 && (up != inferred || rise != delta))
				return source;
			up = inferred;
			rise = delta;
		}
		if (up < 0 || rise <= 0 || topHeight <= rise/2) return source;
		// All special handling is pure 8-bit sprite output. The MCD,
		// tile height, movement, collision and visibility remain native.
		const int keyMode = 3000 + up*600 + topHeight*20 + rise;
		const auto key = std::make_tuple(source.getBuffer(),32,40,
			source.getPitch(),_r41Rotation,keyMode);
		auto hit = _r42RampRotateCache.find(key);
		if (hit == _r42RampRotateCache.end())
		{
			std::vector<Uint8> pixels(32*40,0);
			const Uint8 *raw = source.getBuffer();
			const int pitch = source.getPitch();
			const double low = std::max(0,topHeight-rise);
			const int camX = (_r41Rotation == 0 || _r41Rotation == 3) ? 1 : -1;
			const int camY = (_r41Rotation == 0 || _r41Rotation == 1) ? 1 : -1;
			const int upX = up == 0 ? 1 : up == 1 ? -1 : 0;
			const int upY = up == 2 ? 1 : up == 3 ? -1 : 0;
			const bool riserVisible = camX*upX + camY*upY < 0;
			auto pixelAt = [&](int a,int b)->Uint8
			{
				return a>=0 && a<32 && b>=0 && b<40 ?
					raw[static_cast<size_t>(b)*pitch+a] : 0;
			};
			// Each input pixel is authored for the normal SE camera. The
			// reverse camera must borrow an actual painted *side* from
			// east/south, not a nearby top pixel (RC1 invented brown slabs).
			auto sample = [&](double wx,double wy,double z,
				bool top,bool outer,bool riser) -> Uint8
			{
				if (outer)
				{
					if (wx < 0.75) wx=16.0; // unseen west -> painted east
					if (wy < 0.75) wy=16.0; // unseen north -> painted south
				}
				const int sx=static_cast<int>(std::lround(16+wx-wy));
				const int sy=static_cast<int>(std::lround(24+(wx+wy)/2-z));
				Uint8 pixel=pixelAt(sx,sy);
				if (pixel) return pixel;
				// Small 1-pixel gaps can result from forward/inverse
				// isometric rounding; never extrapolate across three pixels.
				for (int d=1;d<=2;++d)
				for (int oy=-d;oy<=d;++oy)
				for (int ox=-d;ox<=d;++ox)
				{
					if (std::abs(ox)!=d && std::abs(oy)!=d) continue;
					pixel=pixelAt(sx+ox,sy+oy);
					if (pixel) return pixel;
				}
				return 0;
			};
			for (int y=0; y<40; ++y)
			for (int x=0; x<32; ++x)
			{
				Uint8 chosen=0;
				double bestDepth=-1e9;
				for (int zi=0; zi<=topHeight*2; ++zi)
				{
					const double z=zi*0.5;
					const double vu=y-24.0+z+(x-16.0)*0.5;
					const double vv=y-24.0+z-(x-16.0)*0.5;
					if (vu<0.0 || vv<0.0 || vu>=16.0 || vv>=16.0) continue;
					double wx=vu,wy=vv;
					switch (_r41Rotation)
					{
					case 1: wx=16.0-vv; wy=vu; break;
					case 2: wx=16.0-vu; wy=16.0-vv; break;
					case 3: wx=vv; wy=16.0-vu; break;
					default: break;
					}
					const double ascent=up==0 ? wx : up==1 ? 16.0-wx :
						up==2 ? wy : 16.0-wy;
					const int step=std::min(4,std::max(1,
						static_cast<int>(std::floor(ascent/4.0))+1));
					const double height=low+rise*step/4.0;
					const bool top=std::abs(z-height)<=0.35;
					const bool outerSide=(vu>=15.6 || vv>=15.6) && z<height;
					const double stepBoundary=ascent-4.0*std::floor(ascent/4.0);
					const bool riserSide=riserVisible && stepBoundary<0.7 &&
						z<height && z>=height-rise/4.0;
					if (!top && !outerSide && !riserSide) continue;
					const Uint8 pixel=sample(wx,wy,z,top,outerSide,riserSide);
					if (!pixel) continue;
					const double depth=vu+vv+z*0.05;
					if (depth>bestDepth) { bestDepth=depth; chosen=pixel; }
				}
				pixels[static_cast<size_t>(y)*32+x]=chosen;
			}
			hit=_r42RampRotateCache.emplace(key,std::move(pixels)).first;
		}
		return SurfaceRaw<const Uint8>(hit->second.data(),32,40,32);
	};

	// R42: reproject native PLANE/PLANE2 8-bit art, not external images.
	// A tread is planar; a fuselage is top + two vertical faces. World
	// tiles, MCD/LoFT collision, ballistics and pathfinding are immutable.
	auto r42RotatedRamp = [&](Tile *paintTile, TilePart part,
		SurfaceRaw<const Uint8> source) -> SurfaceRaw<const Uint8>
	{
		if (_r41Rotation == 0 || !source || !paintTile ||
			source.getWidth() != 32 || source.getHeight() != 40)
			return source;
		MapData *data = paintTile->getMapData(part);
		if (!data || !data->getDataset()) return source;
		const std::string &dataset = data->getDataset()->getName();
		const int frame = data->getSprite(0);
		const bool classic = (dataset == "PLANE" || dataset == "PLANE_VR");
		const bool later = (dataset == "PLANE2" || dataset == "PLANE2R");
		if (!classic && !later) return source; // Keep rejected R44 generic stairs out of this release.
		const bool rampTread = part == O_OBJECT && data->getTerrainLevel() < 0 &&
			((classic && frame == 62) || (later && frame == 50));
		// RC17: PLANE frame 62 is a real 3D slope (z rises with +Y),
		// NOT a flat stair. Do not apply this model to PLANE2 frame 50.
		const bool skyrangerSlope = classic && rampTread && frame == 62;
		// The thin overhangs, tiny tail tips and spar fragments are flat
		// native aircraft art, NOT volumetric hull cubes. In particular
		// they are O_OBJECT even though all their pixels lie on a floor.
		const bool thinAircraftPiece = part == O_OBJECT &&
			((classic && (frame == 16 || frame == 20 || frame == 25 ||
				frame == 38 || frame == 39 || frame == 40)) ||
			 (later && (frame == 12 || frame == 16 || frame == 21 ||
				frame == 34 || frame == 35 || frame == 36 || frame == 39)));
		const bool flatTread = part == O_FLOOR || thinAircraftPiece;
		// Some aircraft nose plates live at the TOP of a tile (y=0..20),
		// not on its floor (y=24..40). Rotating them as filled cubes
		// invents slab walls and breaks the silhouette on reverse views.
		const bool roofPlate = part == O_OBJECT &&
			((classic && frame >= 48 && frame <= 51) ||
			 (later && (frame == 120 || frame == 121)));
		// RC26: PLANE.MAP places actual port/starboard side runs at
		// x=3 (frames 5..8) and x=6 (frames 11..14), z=1.
		// Frame 3 occurs on the elevated aft hatch at x=4/5,z=2
		// and must not be treated as a longitudinal side wall.
		const bool pairedHullSide = classic && part == O_OBJECT &&
			((frame >= 5 && frame <= 8) || (frame >= 11 && frame <= 14));
		const bool landingGear = part == O_OBJECT && (frame == 0 || frame == 1);
		// R43_QA_RC7: aircraft roof strips and rear hatch lip are
		// encoded as FLOOR, but pixels extend beyond a 32x40 diamond.
		// Reproject them in a transparent overscan canvas so their
		// existing palette indices are not clipped by camera rotation.
		const bool oversizedRoof = classic && part == O_FLOOR &&
			(frame == 52 || frame == 53 || frame == 60 || frame == 61);
		const bool fuselage = part == O_OBJECT && !rampTread &&
			!thinAircraftPiece && !landingGear;
		if (!flatTread && !rampTread && !fuselage && !landingGear) return source;
		const int width = source.getWidth(), height = source.getHeight();
		// Extended roof strips need 16px overscan in every direction;
		// ramp overhang uses the existing one-pixel extension.
		const int outputMargin = rampTread ? 1 : oversizedRoof ? 16 : 0;
		// RC11 isolated QA: connect a PLANE F2 landing to the real
		// adjacent frame-62 ramp below without redrawing the native F2.
		int landingFaceHeight = 0;
		if (part == O_FLOOR && classic && frame == 2 &&
			(_r41Rotation == 2 || _r41Rotation == 3) &&
			paintTile->getPosition().z > 0)
		{
			Tile *outer = _save->getTile(paintTile->getPosition() + Position(0,-1,-1));
			MapData *outerData = outer ? outer->getMapData(O_OBJECT) : nullptr;
			if (outerData && outerData->getDataset() &&
				outerData->getDataset()->getName() == dataset &&
				outerData->getSprite(0) == 62 && outerData->getYOffset() == 16)
				landingFaceHeight = 8;
		}
		// RC14: the native PLANE ramp rises with world +Y. The first
		// two steps have 8px exposed faces; the terminal MCD-64 step
		// has P_Level=0 but still rises 4px (T_Level=-4) above sand.
		// Render that last lip only when the downhill neighbor is flat.
		const bool downhillFace = rampTread && (_r41Rotation == 2 || _r41Rotation == 3);
		const bool terminalLip = classic && rampTread && frame == 62 &&
			data->getYOffset() == 0 && data->getTerrainLevel() == -4;
		int exposedHeight = 0;
		if (downhillFace)
		{
			Tile *nextTile = _save->getTile(paintTile->getPosition() + Position(0, -1, 0));
			MapData *nextData = nextTile ? nextTile->getMapData(O_OBJECT) : nullptr;
			if (nextData && nextData->getDataset() &&
				nextData->getDataset()->getName() == dataset &&
				nextData->getSprite(0) == frame)
				exposedHeight = std::min(8, std::max(0,
					data->getYOffset() - nextData->getYOffset()));
			else if (terminalLip) // last step always exposes 4px above Z0 ground
				exposedHeight = 4;
		}
		// Native art already encodes the rise. Fake risers created
		// detached slabs on Q2/Q3; keep only true geometry.
		const int riserHeight = skyrangerSlope ? 0 : downhillFace ? exposedHeight :
			(rampTread ? std::min(8, std::max(0, terminalLip ? 4 : data->getYOffset())) : 0);
		const int outWidth = width + outputMargin*2;
		const int baseHeight = height + outputMargin*2;
		const int outHeight = baseHeight + std::max(riserHeight, landingFaceHeight);
		const int pitch = source.getPitch();
		// RC27: A middle hull tile joins native panels at both Y edges.
		// Roof donors from the opposite side must not overwrite its
		// continuous upper shoulder. Treat terminal tiles separately.
		auto adjacentHullPanel = [&](int dy) -> bool
		{
			if (!pairedHullSide) return false;
			Tile *neighbor = _save->getTile(paintTile->getPosition() + Position(0,dy,0));
			MapData *other = neighbor ? neighbor->getMapData(O_OBJECT) : nullptr;
			if (!other || !other->getDataset()) return false;
			const std::string &otherName = other->getDataset()->getName();
			const int otherFrame = other->getSprite(0);
			const bool sameSet = otherName == dataset;
			return sameSet && ((frame >= 5 && frame <= 8 && otherFrame >= 5 && otherFrame <= 8) ||
				(frame >= 11 && frame <= 14 && otherFrame >= 11 && otherFrame <= 14));
		};
		const bool continuousHullY = adjacentHullPanel(-1) && adjacentHullPanel(1);
		const auto key = std::make_tuple(source.getBuffer(),width,height,pitch,_r41Rotation,
			(landingFaceHeight ? 60+landingFaceHeight : rampTread ? 20+riserHeight : oversizedRoof ? 50 : roofPlate ? 4 : landingGear ? 3 : pairedHullSide ? (continuousHullY ? 102 : 2) : fuselage ? 1 : 0));
		auto found = _r42RampRotateCache.find(key);
		if (found == _r42RampRotateCache.end())
		{
			std::vector<Uint8> pixels(static_cast<size_t>(outWidth)*outHeight,0);
			const Uint8 *raw = source.getBuffer();
			// A fuselage side is a partial curved *surface*, not an
			// independent 32x40 cube. Its counterpart on the other side
			// of the aircraft is available as native indexed pixel art.
			// Reflected donor keeps the line-work and curved outline.
			SurfaceRaw<const Uint8> pairedSource;
			if (pairedHullSide)
			{
				int partner=(frame < 9) ? frame+6 : frame-6;
				if (auto* frames=data->getDataset()->getSurfaceset())
					pairedSource=frames->getFrame(partner);
			}
			// RC22 QA: retain the physical panel's own native roof and corner
			// art. The west exterior/interior face is unseen in the native
			// camera and needs its paired source only when facing Q1/Q2.
			// RC20 replaced the entire panel (including its ceiling/caps),
			// which visibly displaced the fuselage and unit occlusion.
			const bool useWestHullDonor = pairedHullSide && bool(pairedSource) &&
				(_r41Rotation == 1 || _r41Rotation == 2);
			const Uint8 *hullFace = raw;
			const int hullFacePitch = pitch;
			const Uint8 *hullOpposite = pairedSource ? pairedSource.getBuffer() : nullptr;
			const int hullOppositePitch = pairedSource ? pairedSource.getPitch() : 0;
			// Only three cached directional frames are built per native PCK
			// frame; zero-degree uses the exact original sprite pointer.
			auto sample = [&](double wx,double wy,double z,bool side,
				bool oppositeRoof) -> Uint8
			{
				// The native image exposes east/south faces. For unseen
				// north/west use a reflected native face (same palette).
				// RC24 QA: a PLANE hull panel is a curved OPEN shoulder,
				// not an opaque cube ceiling. Reproject its vertical faces
				// independently from a thin top-rim silhouette. RC23's
				// entire donor-filled top invented a solid cabin slab.
				// RC40 isolated diagnostic: middle longitudinal wall tiles
				// do not have an independent world-Y endcap. Their X-facing
				// exterior is real; repeated Y-facing cube walls are not.
				// Leave both physical terminal panels and Q0/Q3 untouched.
				if (side && pairedHullSide && continuousHullY &&
					(_r41Rotation == 1 || _r41Rotation == 2) &&
					(wy < 0.75 || wy > 15.25)) return 0;
				const bool westFaceDonor = side && useWestHullDonor && wx < 0.75;
				const Uint8 *faceArt = westFaceDonor ? hullOpposite : hullFace;
				const int facePitch = westFaceDonor ? hullOppositePitch : hullFacePitch;
				const Uint8 *gapArt = westFaceDonor ? hullFace : hullOpposite;
				const int gapPitch = westFaceDonor ? hullFacePitch : hullOppositePitch;
				if (side)
				{
					if (wx < 0.75) wx = 16.0;
					if (wy < 0.75) wy = 16.0;
				}
				const int sx = static_cast<int>(std::lround(16.0+wx-wy));
				const int sy = static_cast<int>(std::lround(24.0+(wx+wy)/2.0-z));
				if (sx<0 || sx>=width || sy<0 || sy>=height) return 0;
				// RC28 QA: a middle hull panel is an upright strip, not
				// an independent ceiling slab. Its upper edge is provided
				// by adjacent continuous panels; retain endcap top art.
				if (!side && continuousHullY && _r41Rotation == 2)
					return 0;
				const bool isolatedShoulder = !side && useWestHullDonor;
				const Uint8 *topArt = isolatedShoulder ? hullFace :
					(oppositeRoof ? pairedSource.getBuffer() : faceArt);
				const int topPitch = isolatedShoulder ? hullFacePitch :
					(oppositeRoof ? pairedSource.getPitch() : facePitch);
				Uint8 pixel=topArt[static_cast<size_t>(sy)*topPitch+sx];
				if (isolatedShoulder && pixel)
				{
					// RC25-26: keep ONLY the outer upper envelope of the
					// native panel. RC24's nearest-transparent search also
					// kept the inner C-shaped hole, producing jagged teeth
					// along the cabin in reverse views. Each native source
					// column yields at most three rim pixels, with no new
					// colors or fabricated solid horizontal surfaces.
					int firstOpaque=height;
					for (int iy=0; iy<height; ++iy)
						if (hullFace[static_cast<size_t>(iy)*hullFacePitch+sx])
						{ firstOpaque=iy; break; }
					if (firstOpaque>=24 || sy>firstOpaque+2)
						pixel=0;
				}
				// Fill only otherwise-empty back-face pixels using the
				// corresponding opposite native hull panel. Original
				// windows, edge lines and front-face textures survive.
				if (!pixel && side && gapArt && sx<width && sy<height)
				{
					// Repair one-pixel seams but never flood a large native
					// opening in either the outward or inward panel.
					bool nativeEdge=false;
					for (int oy=-1;oy<=1 && !nativeEdge;++oy)
					for (int ox=-1;ox<=1 && !nativeEdge;++ox)
					{
						const int nx=sx+ox,ny=sy+oy;
						if (nx>=0 && ny>=0 && nx<width && ny<height &&
							faceArt[static_cast<size_t>(ny)*facePitch+nx])
							nativeEdge=true;
					}
					if(nativeEdge)
						pixel=gapArt[static_cast<size_t>(sy)*gapPitch+sx];
				}
				// Repair isolated sampling gaps only inside native paired hull panels.
				if (!pixel && side && pairedHullSide &&
					sx > 0 && sx + 1 < width && sy > 0 && sy + 1 < height)
				{
					const Uint8 left = faceArt[static_cast<size_t>(sy)*facePitch+sx-1];
					const Uint8 right = faceArt[static_cast<size_t>(sy)*facePitch+sx+1];
					const Uint8 above = faceArt[static_cast<size_t>(sy-1)*facePitch+sx];
					const Uint8 below = faceArt[static_cast<size_t>(sy+1)*facePitch+sx];
					if (left && right && left == right) pixel=left;
					else if (above && below && above == below) pixel=above;
				}
				return pixel;
			};
			for (int y=0;y<baseHeight;++y)
			for (int x=0;x<outWidth;++x)
			{
				const int imageX=x-outputMargin;
				const int imageY=y-outputMargin;
				if (landingGear)
				{
					// A wheel and strut are vertical billboards, not solid
					// cubes; reflect the native indexed pixels for the
					// reverse camera hemisphere instead of voxel-warping.
					const int sx = (_r41Rotation == 1 || _r41Rotation == 2)
						? width-1-x : x;
					pixels[static_cast<size_t>(y)*outWidth+x] =
						raw[static_cast<size_t>(imageY)*pitch+sx];
					continue;
				}
				if (roofPlate)
				{
					// Inverse 90-degree diamond transform around the
					// ceiling anchor y=0 rather than the floor anchor y=24.
					int sx=imageX,sy=imageY;
					switch (_r41Rotation)
					{
					case 1: sx=32-2*imageY; sy=imageX/2; break;
					case 2: sx=32-imageX; sy=16-imageY; break;
					case 3: sx=2*imageY; sy=16-imageX/2; break;
					default: break;
					}
					if(sx>=0 && sy>=0 && sx<width && sy<height)
						pixels[static_cast<size_t>(y)*outWidth+x]=
							raw[static_cast<size_t>(sy)*pitch+sx];
					continue;
				}
				if (skyrangerSlope)
				{
					// The native sprite encodes z=worldY/2 (one height
					// voxel per 2 horizontal voxels) inside each 16x16 tile.
					// Native PCK: sx=16+worldX-worldY, sy=24+worldX/2.
					// Invert the *rotated* 3D isometric projection rather
					// than rotating its compressed image as a flat diamond.
					const double dx=static_cast<double>(imageX);
					const double dy=static_cast<double>(imageY);
					double wx=0.0,wy=0.0;
					switch (_r41Rotation)
					{
					case 1: wx=64.0-2.0*dy; wy=dx-wx; break;
					case 2: wx=(56.0-dx-dy)*2.0/3.0; wy=dx-16.0+wx; break;
					case 3: wx=(dy-dx)*2.0/3.0; wy=32.0-dx-wx; break;
					default: break;
					}
					if (wx>=0.0 && wy>=0.0 && wx<16.0 && wy<16.0)
					{
						const int sx=static_cast<int>(std::lround(16.0+wx-wy));
						const int sy=static_cast<int>(std::lround(24.0+wx/2.0));
						if (sx>=0 && sx<width && sy>=0 && sy<height)
							pixels[static_cast<size_t>(y)*outWidth+x]=
								raw[static_cast<size_t>(sy)*pitch+sx];
					}
					continue;
				}
				if (flatTread || rampTread)
				{
					// Isometric floor diamond: top (16,24), edges
					// (0,32), (32,32), and bottom (16,40).
					int sx=imageX,sy=imageY;
					switch (_r41Rotation)
					{
					case 1: sx=80-2*imageY; sy=24+imageX/2; break;
					case 2: sx=32-imageX; sy=64-imageY; break;
					case 3: sx=2*imageY-48; sy=40-imageX/2; break;
					default: break;
					}
					if (sx>=0&&sx<width&&sy>=0&&sy<height)
						pixels[static_cast<size_t>(y)*outWidth+x] =
							raw[static_cast<size_t>(sy)*pitch+sx];
					continue;
				}
				// Reconstruct three visible faces of the X-COM tile cube.
				// Screen (x,y) comes from (u,v,z) where the roof z=24,
				// the east face u=16 and the south face v=16.
				const double px=x+0.5, py=y+0.5, diff=px-16.0;
				const double u=py+diff/2.0, v=py-diff/2.0;
				double viewU=0.0, viewV=0.0, z=0.0;
				bool top=false, side=false;
				if (u>=0.0 && u<=16.0 && v>=0.0 && v<=16.0)
				{
					viewU=u; viewV=v; z=24.0; top=true;
				}
				else if (px<16.0)
				{
					viewU=px; viewV=16.0;
					z=24.0+(viewU+viewV)/2.0-py;
					side=z>=0.0 && z<=24.0;
				}
				else
				{
					viewU=16.0; viewV=32.0-px;
					z=24.0+(viewU+viewV)/2.0-py;
					side=z>=0.0 && z<=24.0;
				}
				if (!top && !side) continue;
				// RC27 diagnostic: remove ONLY the hypothetical flat
				// ceiling of the longitudinal hull panels. The original
				// PCK panels are open C-section walls; this isolates
				// whether the reverse-view slab is a top or side artifact.
				if (pairedHullSide && top &&
					(_r41Rotation == 1 || _r41Rotation == 2)) continue;
				double wx=viewU, wy=viewV;
				switch (_r41Rotation)
				{
				case 1: wx=16.0-viewV; wy=viewU; break;
				case 2: wx=16.0-viewU; wy=16.0-viewV; break;
				case 3: wx=viewV; wy=16.0-viewU; break;
				default: break;
				}
				// R43_QA_RC7: RC3 paired roof is retained; aircraft roof
				// overscan changes floor masks, not the object side art.
				const bool oppositeRoof=top && pairedHullSide && !continuousHullY &&
					frame>=11 && frame<=14 && _r41Rotation==2 && bool(pairedSource);
				pixels[static_cast<size_t>(y)*outWidth+x]=
					sample(wx,wy,z,side,oppositeRoof);
			}
			if (riserHeight > 0)
			{
				if (downhillFace)
				{
					// Only the native tread's downhill world-Y edge is
					// vertical here. The donor color is its own continuous
					// rim (row 31); checkerboard top pixels are NOT repeated
					// down the face (the rejected RC8 produced stripes).
					const Uint8 rim = raw[31 * pitch + 20];
					if (rim)
					for (int x = outputMargin; x < outWidth-outputMargin; ++x)
					{
						const int xx = x - outputMargin;
						if ((_r41Rotation == 2 && xx > 17) ||
							(_r41Rotation == 3 && xx < 15)) continue;
						int edge = -1;
						double nearest = 100.0;
						for (int y = 0; y < baseHeight; ++y)
						{
							if (!pixels[static_cast<size_t>(y)*outWidth+x]) continue;
							const int yy = y - outputMargin;
							const int sx = _r41Rotation == 2 ? 32-xx : 2*yy-48;
							const int sy = _r41Rotation == 2 ? 64-yy : 40-xx/2;
							const double worldY = (sy-24)-(sx-16)/2.0;
							if (worldY < -1.0 || worldY > 2.0) continue;
							if (std::abs(worldY) < nearest)
							{
								nearest = std::abs(worldY);
								edge = y;
							}
						}
						// MCD64's native PCK is a very thin triangular tread.
						// On the far camera the analytic world-Y rim may miss
						// every nontransparent pixel. For this last 4px step
						// alone, anchor the face to the visible native edge.
						if (edge < 0 && terminalLip)
						{
							for (int y=baseHeight-1; y>=0; --y)
								if (pixels[static_cast<size_t>(y)*outWidth+x])
								{ edge=y; break; }
						}
						if (edge < 0) continue;
						const Uint8 topPixel = pixels[static_cast<size_t>(edge)*outWidth+x];
						for (int dy = 1; dy <= riserHeight && edge+dy < outHeight; ++dy)
						{
							const size_t i = static_cast<size_t>(edge+dy)*outWidth+x;
							if (!pixels[i]) pixels[i] = (dy == 1 ? topPixel : rim);
						}
					}
				}
				else
				{
					// Existing one-pixel-overscan RC7 riser for Q1.
					for (int x=outputMargin;x<outWidth-outputMargin;++x)
					{
						int bottom=-1;
						for (int y=baseHeight-1;y>=0;--y)
						{
							if (pixels[static_cast<size_t>(y)*outWidth+x])
							{
								bottom=y;
								break;
							}
						}
						if (bottom<0) continue;
						const Uint8 nativeEdge=pixels[static_cast<size_t>(bottom)*outWidth+x];
						const Uint8 riserColor=nativeEdge == 88 ? 86 : nativeEdge == 9 ? 8 : 6;
						for (int dy=1;dy<=riserHeight && bottom+dy<outHeight;++dy)
							pixels[static_cast<size_t>(bottom+dy)*outWidth+x]=riserColor;
					}
				}
			}
			// RC14: the 4px lip can be hidden by the adjacent ground tile
			// in reverse views. Shade only the last two *visible* pixels
			// of its native PCK edge, without fabricating a full dark slab.
			if (terminalLip && downhillFace && !skyrangerSlope)
			{
				const Uint8 lipShade=raw[31*pitch+20];
				if (lipShade)
				for (int x=outputMargin;x<outWidth-outputMargin;++x)
				{
					const int xx=x-outputMargin;
					if ((_r41Rotation==2 && xx>17) ||
						(_r41Rotation==3 && xx<15)) continue;
					int bottom=-1;
					for (int y=baseHeight-1;y>=0;--y)
						if (pixels[static_cast<size_t>(y)*outWidth+x])
						{ bottom=y; break; }
					if (bottom<1) continue;
					for (int dy=0;dy<2;++dy)
					{
						const size_t i=static_cast<size_t>(bottom-dy)*outWidth+x;
						if (pixels[i]) pixels[i]=lipShade;
					}
				}
			}
			if (landingFaceHeight)
			{
				// The original edge index is from the native F2 PCK.
				// RC10 was rejected: painting inside its original 40px
				// silhouette covered the hull with a bright slab. Limit
				// this mask to the genuinely NEW pixels below y=40.
				const Uint8 fascia = raw[29*pitch+4];
				if (fascia)
				for (int x=1; x<outWidth-1; ++x)
				{
					if ((_r41Rotation==2 && x>16) || (_r41Rotation==3 && x<16)) continue;
					int edge=-1; double nearest=100.0;
					for (int y=24; y<baseHeight; ++y)
					{
						if (!pixels[static_cast<size_t>(y)*outWidth+x]) continue;
						const int sx=_r41Rotation==2 ? 32-x : 2*y-48;
						const int sy=_r41Rotation==2 ? 64-y : 40-x/2;
						const double worldY=(sy-24)-(sx-16)/2.0;
						if (worldY<-1.0 || worldY>2.0) continue;
						if (std::abs(worldY)<nearest)
						{ nearest=std::abs(worldY); edge=y; }
					}
					if (edge<0) continue;
					for (int dy=1; dy<=landingFaceHeight && edge+dy<outHeight; ++dy)
					{
						const size_t i=static_cast<size_t>(edge+dy)*outWidth+x;
						if (edge+dy>=baseHeight && !pixels[i]) pixels[i]=fascia;
					}
				}
			}
			found=_r42RampRotateCache.emplace(key,std::move(pixels)).first;
		}
		return SurfaceRaw<const Uint8>(found->second.data(),outWidth,outHeight,outWidth);
	};

	// The neighbor offset lists below encode visual back/front tiles.
	// Convert them to world deltas rather than relying on world-north.
	auto viewToWorldDelta = [&](Position v) -> Position
	{
		switch (_r41Rotation)
		{
		case 1: return Position(-v.y, v.x, v.z);
		case 2: return Position(-v.x,-v.y, v.z);
		case 3: return Position( v.y,-v.x, v.z);
		default: return v;
		}
	};
	for (int itZ = beginZ; itZ <= endZ; itZ++)
	{
		bool topLayer = itZ == endZ;
		// Painter traversal follows rotated screen-space diagonal order.
		for (int row = 0; row < endY - beginY; ++row)
		{
			const int itY = (_r41Rotation == 2 || _r41Rotation == 3)
				? endY - 1 - row : beginY + row;
			for (int col = 0; col < endX - beginX; ++col)
			{
				const int itX = (_r41Rotation == 1 || _r41Rotation == 2)
					? endX - 1 - col : beginX + col;
				mapPosition = Position(itX, itY, itZ);
				tile = _save->getTile(mapPosition);
				if (!tile) continue;
				_camera->convertMapToScreen(mapPosition, &screenPosition);
				screenPosition += cameraPos;

				// only render cells that are inside the surface
				if (screenPosition.x > -_spriteWidth && screenPosition.x < surface->getWidth() + _spriteWidth &&
					screenPosition.y > -_spriteHeight && screenPosition.y < surface->getHeight() + _spriteHeight )
				{
					bool isUnitMovingNearby = movingUnit && positionInRangeXY(movingUnitPosition, mapPosition, 2);

					if (tile->isDiscovered(O_FLOOR))
					{
						tileShade = reShade(tile);
						obstacleShade = tileShade;
						if (_showObstacles)
						{
							if (tile->isObstacle())
							{
								obstacleShade = getShadePulseForFrame(tileShade, _animFrame);
							}
						}
					}
					else
					{
						tileShade = 16;
						obstacleShade = 16;
					}

					tileColor = tile->getMarkerColor();

					// R41: BIGWALL back/front classification is view-dependent.
					// 4=W, 5=N, 6=E, 7=S, 8=E+S, 9=W+N.
					// Physics and world-facing large-wall flags are unchanged.
					bool r41ObjectBack = tile->isBackTileObject(O_OBJECT);
					if (_r41Rotation != 0 && tile->getMapData(O_OBJECT))
					{
						MapData *objectData = tile->getMapData(O_OBJECT);
						const int bigWall = objectData->getBigWall();
						// RC26 corrected PLANE.MAP side-run identification:
						// west MCD 5..8; east MCD 11..14 (not elevated rear MCD 3).
						// Their BigWall flag is 1 (whole tile), so ordinary wall
						// classification never changes when the camera rotates.
						// Only the side facing the camera may cover foreground
						// units; the opposite side is drawn behind the cabin.
						const std::string datasetName = objectData->getDataset()
							? objectData->getDataset()->getName() : "";
						const int frame = objectData->getSprite(0);
						const bool planeSide = datasetName == "PLANE" || datasetName == "PLANE_VR";
						const bool westSide = planeSide && frame >= 5 && frame <= 8;
						const bool eastSide = planeSide && frame >= 11 && frame <= 14;
						if (westSide || eastSide)
						{
							const bool westFacesCamera = _r41Rotation == 1 || _r41Rotation == 2;
							r41ObjectBack = westSide ? !westFacesCamera : westFacesCamera;
						}
						else if (bigWall >= 4 && bigWall <= 9)
						{
							static constexpr bool viewBack[4][6] = {
								{true,true,false,false,false,true},   // W, N
								{false,true,true,false,true,true},   // N, E
								{false,false,true,true,true,false}, // E, S
								{true,false,false,true,true,true}   // S, W
							};
							r41ObjectBack = viewBack[_r41Rotation][bigWall - 4];
						}
					}

					// Draw floor. R43_QA_RC7: selected aircraft roof sprites
					// need a wider transparent canvas after 90-degree
					// projection. The drawing origin offsets by exactly
					// half the added width, so world tile geometry stays put.
					tmpSurface = r42RotatedRamp(tile,O_FLOOR,tile->getSprite(O_FLOOR));
					if (tmpSurface)
					{
						const int expandedPad=std::max(0,(tmpSurface.getWidth()-32)/2);
						const int px=screenPosition.x-expandedPad;
						const int py=screenPosition.y-expandedPad-tile->getYOffset(O_FLOOR);
						if (tile->getObstacle(O_FLOOR))
							Surface::blitRaw(surface, tmpSurface, px, py, obstacleShade, false, _nvColor);
						else
							Surface::blitRaw(surface, tmpSurface, px, py, tileShade, false, _nvColor);
					}

					// RC16: paint each exposed PLANE ramp riser AFTER the
					// next downhill (-Y) tile's floor, BEFORE its object/units.
					// Reverse-view painter order otherwise hides the 8/8/4px
					// downward faces under the front neighbor's floor.
					// This strictly affects art: terrain/MCD, collision, FOV
					// and pathfinding remain native.
					if ((_r41Rotation == 2 || _r41Rotation == 3) &&
						tile->isDiscovered(O_FLOOR))
					{
						Tile *uphill = _save->getTile(mapPosition + Position(0,1,0));
						MapData *step = uphill ? uphill->getMapData(O_OBJECT) : nullptr;
						if (step && step->getDataset() &&
							(step->getDataset()->getName() == "PLANE" ||
							 step->getDataset()->getName() == "PLANE_VR") &&
							step->getSprite(0) == 62 &&
							uphill->isDiscovered(O_FLOOR))
						{
							const int p = step->getYOffset();
							const int t = step->getTerrainLevel();
							// Only the native three-stage Skyranger stair.
							const bool validStep = (p == 0 || p == 8 || p == 16) &&
								t == -(p+4);
							MapData *lower = tile->getMapData(O_OBJECT);
							const bool neighboringStep = lower && lower->getDataset() &&
								lower->getDataset()->getName() == step->getDataset()->getName() &&
								lower->getSprite(0) == 62 && lower->getYOffset() == p-8;
							const bool validDownhill = p == 0 ? !neighboringStep : neighboringStep;
							const int riserH = p == 0 ? 4 : 8;
							if (validStep && validDownhill)
							{
								SurfaceRaw<const Uint8> whole = r42RotatedRamp(
									uphill,O_OBJECT,uphill->getSprite(O_OBJECT));
								if (whole && whole.getWidth() == 34 &&
									whole.getHeight() == 42+riserH)
								{
									const int w=whole.getWidth(),h=whole.getHeight();
									const int pitch=whole.getPitch();
									const int baseH=h-riserH;
									std::vector<Uint8> face(static_cast<size_t>(w)*h,0);
									int painted=0;
									for (int x=1; x<w-1; ++x)
									{
										const int xx=x-1;
										if ((_r41Rotation==2 && xx>17) ||
											(_r41Rotation==3 && xx<15)) continue;
										int edge=-1;
										double nearest=100.0;
										for (int y=0; y<baseH; ++y)
										{
											if (!whole.getBuffer()[static_cast<size_t>(y)*pitch+x]) continue;
											const int yy=y-1;
											const int sx=_r41Rotation==2 ? 32-xx : 2*yy-48;
											const int sy=_r41Rotation==2 ? 64-yy : 40-xx/2;
											const double worldY=(sy-24)-(sx-16)/2.0;
											if (worldY < -1.0 || worldY > 2.0) continue;
											if (std::abs(worldY)<nearest)
											{ nearest=std::abs(worldY);edge=y; }
										}
										if (edge<0 && p==0)
											for (int y=baseH-1; y>=0; --y)
												if (whole.getBuffer()[static_cast<size_t>(y)*pitch+x])
												{ edge=y;break; }
										if (edge<0) continue;
										for (int dy=1; dy<=riserH && edge+dy<h; ++dy)
										{
											const size_t src=static_cast<size_t>(edge+dy)*pitch+x;
											const Uint8 pixel=whole.getBuffer()[src];
											if (!pixel) continue;
											face[static_cast<size_t>(edge+dy)*w+x]=pixel;
											++painted;
										}
									}
									if (painted)
									{
										Position upScreen;
										_camera->convertMapToScreen(uphill->getPosition(),&upScreen);
										upScreen += cameraPos;
										Surface::blitRaw(surface,SurfaceRaw<const Uint8>(
											face.data(),w,h,w),
											upScreen.x-1,upScreen.y-1-p,
											reShade(uphill),false,_nvColor);
										if (_r41Rotation==2 && itX==24)
										{
											static bool loggedP[3]={false,false,false};
											const int idx=p/8;
											if (!loggedP[idx])
											{
												loggedP[idx]=true;
												Log(LOG_INFO) << "RC16_RISER_COMPOSITE P=" << p
													<< " faceH=" << riserH << " painted=" << painted;
											}
										}
									}
								}
							}
						}
					}

					auto* unit = tile->getUnit();

					// Draw cursor back
					if (_cursorType != CT_NONE && _selectorX > itX - _cursorSize && _selectorY > itY - _cursorSize && _selectorX < itX+1 && _selectorY < itY+1 && !_save->getBattleState()->getMouseOverIcons())
					{
						if (_camera->getViewLevel() == itZ)
						{
							if (_cursorType != CT_AIM)
							{
								if (unit && (unit->getVisible() || _save->getDebugMode()))
									frameNumber = halfAnimFrameRest; // yellow box
								else
									frameNumber = 0; // red box
							}
							else
							{
								if (unit && (unit->getVisible() || _save->getDebugMode()))
									frameNumber = 7 + halfAnimFrame; // yellow animated crosshairs
								else
									frameNumber = 6; // red static crosshairs
							}
							tmpSurface = _game->getMod()->getSurfaceSet("CURSOR.PCK")->getFrame(frameNumber);
							Surface::blitRaw(surface, tmpSurface, screenPosition.x, screenPosition.y, 0);
						}
						else if (_camera->getViewLevel() > itZ)
						{
							frameNumber = 2; // blue box
							tmpSurface = _game->getMod()->getSurfaceSet("CURSOR.PCK")->getFrame(frameNumber);
							Surface::blitRaw(surface, tmpSurface, screenPosition.x, screenPosition.y, 0);
						}
					}

					if (isUnitMovingNearby)
					{
						// special handling for a moving unit in background of tile.
						constexpr static Position backPos[] =
						{
							Position(0, -1, 0),
							Position(-1, -1, 0),
							Position(-1, 0, 0),
						};

						for (size_t b = 0; b < std::size(backPos); ++b)
						{
							drawUnit(unitSprite, _save->getTile(mapPosition + viewToWorldDelta(backPos[b])), tile, screenPosition, topLayer);
						}
					}

					// Draw walls. R41: wall ownership remains in *world* tiles;
					// only the screen-side edge changes with camera rotation.
					// Moving the actual physical boundary rather than moving a
					// same-tile picture is essential to correct unit occlusion.
					{
						if (_r41Rotation == 0)
						{
							// Preserve the unmodified native fast path at 0 degrees.
							tmpSurface = tile->getSprite(O_WESTWALL);
							if (tmpSurface)
							{
								int wallShade = getWallShade(O_WESTWALL, tile);
								if (tile->getObstacle(O_WESTWALL))
									Surface::blitRaw(surface, tmpSurface, screenPosition.x, screenPosition.y - tile->getYOffset(O_WESTWALL), obstacleShade, false, _nvColor);
								else
									Surface::blitRaw(surface, tmpSurface, screenPosition.x, screenPosition.y - tile->getYOffset(O_WESTWALL), wallShade, false, _nvColor);
							}
							tmpSurface = tile->getSprite(O_NORTHWALL);
							if (tmpSurface)
							{
								int wallShade = getWallShade(O_NORTHWALL, tile);
								if (tile->getObstacle(O_NORTHWALL))
									Surface::blitRaw(surface, tmpSurface, screenPosition.x, screenPosition.y - tile->getYOffset(O_NORTHWALL), obstacleShade, bool(tile->getSprite(O_WESTWALL)), _nvColor);
								else
									Surface::blitRaw(surface, tmpSurface, screenPosition.x, screenPosition.y - tile->getYOffset(O_NORTHWALL), wallShade, bool(tile->getSprite(O_WESTWALL)), _nvColor);
							}
						}
						else
						{
							// Visual WEST/NORTH are respectively the negative U/V
							// boundaries of the rotated diamond. The positive-facing
							// world edges belong to the adjacent physical tile.
							Tile *screenWestOwner = tile;
							Tile *screenNorthOwner = tile;
							TilePart screenWestPart = O_WESTWALL;
							TilePart screenNorthPart = O_NORTHWALL;
							switch (_r41Rotation)
							{
							case 1:
								screenWestPart = O_NORTHWALL;
								screenNorthOwner = _save->getTile(mapPosition + Position(1,0,0));
								screenNorthPart = O_WESTWALL;
								break;
							case 2:
								screenWestOwner = _save->getTile(mapPosition + Position(1,0,0));
								screenNorthOwner = _save->getTile(mapPosition + Position(0,1,0));
								break;
							case 3:
								screenWestOwner = _save->getTile(mapPosition + Position(0,1,0));
								screenWestPart = O_NORTHWALL;
								screenNorthPart = O_WESTWALL;
								break;
							}
							// Mirror wall art only if axes are exchanged by the view.
							// Store the mirror once per unique sprite frame.
							r41BlitWall(surface,screenWestOwner,screenWestPart,
								screenPosition.x,screenPosition.y,false,bool(_r41Rotation & 1));
							r41BlitWall(surface,screenNorthOwner,screenNorthPart,
								screenPosition.x,screenPosition.y,
								screenWestOwner && bool(screenWestOwner->getSprite(screenWestPart)),
								bool(_r41Rotation & 1));
						}
						// Draw object
						tmpSurface = r42RotatedRamp(tile,O_OBJECT,tile->getSprite(O_OBJECT));
						if (tmpSurface)
						{
							if (r41ObjectBack)
							{
								const int edge = tmpSurface.getWidth() == 34 && tmpSurface.getHeight() >= 42 ? -1 : 0;
								if (tile->getObstacle(O_OBJECT))
									Surface::blitRaw(surface, tmpSurface, screenPosition.x + edge, screenPosition.y + edge - tile->getYOffset(O_OBJECT), obstacleShade, false, _nvColor);
								else
									Surface::blitRaw(surface, tmpSurface, screenPosition.x + edge, screenPosition.y + edge - tile->getYOffset(O_OBJECT), tileShade, false, _nvColor);
							}
						}
						// draw an item on top of the floor (if any)
						BattleItem* item = tile->getTopItem();
						if (item)
						{
							itemSprite.draw(item,
								screenPosition.x,
								screenPosition.y + tile->getTerrainLevel(),
								tileShade
							);
							if (_anyIndicator)
							{
								BattleUnit *itemUnit = item->getUnit();
								if (itemUnit && itemUnit->getStatus() == STATUS_UNCONSCIOUS && itemUnit->indicatorsAreEnabled())
								{
									if (_burnIndicator && itemUnit->getFire() > 0)
									{
										_burnIndicator->blitNShade(surface,
											screenPosition.x,
											screenPosition.y + tile->getTerrainLevel(),
											tileShade);
									}
									else if (_woundIndicator && itemUnit->getFatalWounds() > 0)
									{
										_woundIndicator->blitNShade(surface,
											screenPosition.x,
											screenPosition.y + tile->getTerrainLevel(),
											tileShade);
									}
									else if (_shockIndicator && itemUnit->hasNegativeHealthRegen())
									{
										_shockIndicator->blitNShade(surface,
											screenPosition.x,
											screenPosition.y + tile->getTerrainLevel(),
											tileShade);
									}
									else if (_stunIndicator)
									{
										_stunIndicator->blitNShade(surface,
											screenPosition.x,
											screenPosition.y + tile->getTerrainLevel(),
											tileShade);
									}
								}
							}
						}
					}

					// check if we got bullet && it is in Field Of View
					if (_projectile && _projectileInFOV)
					{
						tmpSurface = nullptr;
						BattleItem* item = _projectile->getItem();
						if (item)
						{
							Position voxelPos = _projectile->getPosition();
							// draw shadow on the floor
							voxelPos.z = _save->getTileEngine()->castedShade(voxelPos);
							if (voxelPos.x / 16 >= itX &&
								voxelPos.y / 16 >= itY &&
								voxelPos.x / 16 <= itX+1 &&
								voxelPos.y / 16 <= itY+1 &&
								voxelPos.z / 24 == itZ &&
								_save->getTileEngine()->isVoxelVisible(voxelPos))
							{
								_camera->convertVoxelToScreen(voxelPos, &bulletPositionScreen);

								itemSprite.drawShadow(item,
									bulletPositionScreen.x - 16,
									bulletPositionScreen.y - 26
								);
							}

							voxelPos = _projectile->getPosition();
							// draw thrown object
							if (voxelPos.x / 16 >= itX &&
								voxelPos.y / 16 >= itY &&
								voxelPos.x / 16 <= itX+1 &&
								voxelPos.y / 16 <= itY+1 &&
								voxelPos.z / 24 == itZ &&
								_save->getTileEngine()->isVoxelVisible(voxelPos))
							{
								_camera->convertVoxelToScreen(voxelPos, &bulletPositionScreen);

								itemSprite.draw(item,
									bulletPositionScreen.x - 16,
									bulletPositionScreen.y - 26,
									tileShade
								);
							}
						}
						else
						{
							// draw bullet on the correct tile
							if (itX >= bulletLowX && itX <= bulletHighX && itY >= bulletLowY && itY <= bulletHighY)
							{
								int begin = 0;
								int end = BULLET_SPRITES;
								int direction = 1;
								if (_projectile->isReversed())
								{
									begin = BULLET_SPRITES - 1;
									end = -1;
									direction = -1;
								}

								for (int i = begin; i != end; i += direction)
								{
									tmpSurface = _projectileSet->getFrame(_projectile->getParticle(i));
									if (tmpSurface)
									{
										Position voxelPos = _projectile->getPosition(1-i);
										// draw shadow on the floor
										voxelPos.z = _save->getTileEngine()->castedShade(voxelPos);
										if (voxelPos.x / 16 == itX &&
											voxelPos.y / 16 == itY &&
											voxelPos.z / 24 == itZ &&
											_save->getTileEngine()->isVoxelVisible(voxelPos))
										{
											_camera->convertVoxelToScreen(voxelPos, &bulletPositionScreen);
											bulletPositionScreen.x -= tmpSurface.getWidth() / 2;
											bulletPositionScreen.y -= tmpSurface.getHeight() / 2;
											Surface::blitRaw(surface, tmpSurface, bulletPositionScreen.x, bulletPositionScreen.y, 16, false, _nvColor);
										}

										// draw bullet itself
										voxelPos = _projectile->getPosition(1-i);
										if (voxelPos.x / 16 == itX &&
											voxelPos.y / 16 == itY &&
											voxelPos.z / 24 == itZ &&
											_save->getTileEngine()->isVoxelVisible(voxelPos))
										{
											_camera->convertVoxelToScreen(voxelPos, &bulletPositionScreen);
											bulletPositionScreen.x -= tmpSurface.getWidth() / 2;
											bulletPositionScreen.y -= tmpSurface.getHeight() / 2;
											Surface::blitRaw(surface, tmpSurface, bulletPositionScreen.x, bulletPositionScreen.y, 0, false, _nvColor);
										}
									}
								}
							}
						}
					}

					//draw particle clouds
					int pixelMaskArray[] = { 0, 2, 1, 3 };
					SurfaceRaw<int> pixelMask(pixelMaskArray, 2, 2);
					const int vaporScreenOriginX = screenPosition.x + _spriteWidth / 2;
					const int vaporScreenOriginY = screenPosition.y + _spriteHeight - _spriteWidth / 2 + tile->getPosition().toVoxel().z;
					const Uint8* const transparetPtr = _transparencies->data();

					//draw particle clouds behind solder
					for (const Particle& p : getVaporParticle(tile, 0))
					{
						int vaporX = vaporScreenOriginX + p.getOffsetX();
						int vaporY = vaporScreenOriginY + p.getOffsetY();
						auto transparetOffsets = transparetPtr
							+ (p.getColor() * Mod::TransparenciesOpacityLevels * Mod::TransparenciesPaletteColors)
							+ (p.getOpacity() * Mod::TransparenciesPaletteColors);

						ShaderDrawFunc(
							[&](Uint8& dest, int size)
							{
								if (p.getSize() <= size)
								{
									dest = transparetOffsets[dest];
								}
							},
							ShaderSurface(this),
							ShaderMove(pixelMask, vaporX, vaporY)
						);
					}

					unit = tile->getUnit();
					// Draw soldier from this tile, below or above
					drawUnit(unitSprite, tile, tile, screenPosition, topLayer, isUnitMovingNearby ? movingUnit : nullptr);

					if (isUnitMovingNearby)
					{
						// special handling for a moving unit in foreground of tile.
						constexpr static Position frontPos[] =
						{
							Position(-1, +1, 0),
							Position(0, +1, 0),
							Position(+1, +1, 0),
							Position(+1, 0, 0),
							Position(+1, -1, 0),
						};

						for (size_t f = 0; f < std::size(frontPos); ++f)
						{
							drawUnit(unitSprite, _save->getTile(mapPosition + viewToWorldDelta(frontPos[f])), tile, screenPosition, topLayer);
						}
					}

					// R41: some physically-owned world walls at the map's
					// west/north rim would otherwise be mapped to the back edge
					// of an OUT-OF-BOUNDS neighbor. Draw those as front edges
					// after units, offset by a half diamond (16x8 pixels).
					// Their real tile, discovery and collision are untouched.
					if (_r41Rotation && tile->isDiscovered(O_FLOOR))
					{
						if ((_r41Rotation == 1 || _r41Rotation == 2) &&
							mapPosition.x == 0)
						{
							const int xoff = _r41Rotation == 1 ? -16 : 16;
							r41BlitWall(surface,tile,O_WESTWALL,
								screenPosition.x + xoff,screenPosition.y + 8,
								false,bool(_r41Rotation & 1));
						}
						if ((_r41Rotation == 2 || _r41Rotation == 3) &&
							mapPosition.y == 0)
						{
							const int xoff = _r41Rotation == 2 ? -16 : 16;
							r41BlitWall(surface,tile,O_NORTHWALL,
								screenPosition.x + xoff,screenPosition.y + 8,
								false,bool(_r41Rotation & 1));
						}
					}

					// Draw smoke/fire
					if (tile->getSmoke() && tile->isDiscovered(O_FLOOR))
					{
						frameNumber = 0;
						int shade = 0;
						if (!tile->getFire())
						{
							if (_save->getDepth() > 0)
							{
								frameNumber += Mod::UNDERWATER_SMOKE_OFFSET;
							}
							else
							{
								frameNumber += Mod::SMOKE_OFFSET;
							}
							if (Mod::EXTENDED_SMOKE_OFFSET == 0)
							{
								frameNumber += int(floor((tile->getSmoke() / 6.0) - 0.1)); // see http://www.ufopaedia.org/images/c/cb/Smoke.gif
							}
							else if (Mod::EXTENDED_SMOKE_OFFSET == 1)
							{
								frameNumber += int(floor((tile->getSmoke() / 6.0) - 0.1)) * 4;
							}
							else // if (Mod::EXTENDED_SMOKE_OFFSET == 2)
							{
								frameNumber += (tile->getSmoke() - 1) / 5 * 4;
							}
							shade = tileShade;
						}

						if (halfAnimFrame + tile->getAnimationOffset() > 3)
						{
							frameNumber += halfAnimFrame + tile->getAnimationOffset() - 4;
						}
						else
						{
							frameNumber += halfAnimFrame + tile->getAnimationOffset();
						}
						tmpSurface = _game->getMod()->getSurfaceSet("SMOKE.PCK")->getFrame(frameNumber);
						if (gHighVisibilitySmoke && !tile->getFire() && tmpSurface)
						{
							// Indexed-color sprites do not support per-pixel alpha here.
							// Keep ~25% of interior pixels and ~65% of silhouette pixels.
							// Cache masks per animation frame instead of allocating on every tile.
							static std::map<int, std::vector<Uint8>> clarityFrames;
							const int w = tmpSurface.getWidth(), h = tmpSurface.getHeight();
							std::vector<Uint8>& pixels = clarityFrames[frameNumber];
							if (pixels.size() != static_cast<size_t>(w * h))
							{
								pixels.assign(w * h, 0);
								const Uint8* src = tmpSurface.getBuffer();
								const int pitch = tmpSurface.getPitch();
								for (int sy = 0; sy < h; ++sy)
								for (int sx = 0; sx < w; ++sx)
								{
									const Uint8 color = src[sy * pitch + sx];
									if (!color) continue;
									const bool edge = sx == 0 || sy == 0 || sx + 1 == w || sy + 1 == h ||
										src[sy * pitch + sx - 1] == 0 || src[sy * pitch + sx + 1] == 0 ||
										src[(sy - 1) * pitch + sx] == 0 || src[(sy + 1) * pitch + sx] == 0;
									const int pattern = (sx * 7 + sy * 13 + (sx * sy) * 3) % 20;
									if (pattern < (edge ? 13 : 5)) pixels[sy * w + sx] = color;
								}
							}
							Surface::blitRaw(surface, SurfaceRaw<const Uint8>(pixels.data(), w, h, w), screenPosition.x, screenPosition.y, shade, false, _nvColor);
						}
						else
						{
							Surface::blitRaw(surface, tmpSurface, screenPosition.x, screenPosition.y, shade, false, _nvColor);
						}
					}

					//draw particle clouds on front of solder
					for (const Particle& p : getVaporParticle(tile, topLayer ? 3 : 1))
					{
						int vaporX = vaporScreenOriginX + p.getOffsetX();
						int vaporY = vaporScreenOriginY + p.getOffsetY();
						auto transparetOffsets = transparetPtr
							+ (p.getColor() * Mod::TransparenciesOpacityLevels * Mod::TransparenciesPaletteColors)
							+ (p.getOpacity() * Mod::TransparenciesPaletteColors);

						ShaderDrawFunc(
							[&](Uint8& dest, int size)
							{
								if (p.getSize() <= size)
								{
									dest = transparetOffsets[dest];
								}
							},
							ShaderSurface(this),
							ShaderMove(pixelMask, vaporX, vaporY)
						);
					}

					// Draw Path Preview
					if (_previewSettingArrows && tile->getPreview() != -1 && tile->isDiscovered(O_FLOOR))
					{
						if (itZ > 0 && tile->hasNoFloor(_save))
						{
							tmpSurface = _game->getMod()->getSurfaceSet("Pathfinding")->getFrame(11);
							if (tmpSurface)
							{
								Surface::blitRaw(surface, tmpSurface, screenPosition.x, screenPosition.y+2, 0, false, tile->getMarkerColor());
							}
						}
						tmpSurface = _game->getMod()->getSurfaceSet("Pathfinding")->getFrame(tile->getPreview() >= 0 && tile->getPreview() < 8 ? ((tile->getPreview() + 8 - 2 * _r41Rotation) & 7) : tile->getPreview());
						if (tmpSurface)
						{
							Surface::blitRaw(surface, tmpSurface, screenPosition.x, screenPosition.y + tile->getTerrainLevel(), 0, false, tileColor);
						}
					}

					{
						// Draw object
						tmpSurface = r42RotatedRamp(tile,O_OBJECT,tile->getSprite(O_OBJECT));
						if (tmpSurface)
						{
							if (!r41ObjectBack)
							{
								const int edge = tmpSurface.getWidth() == 34 && tmpSurface.getHeight() >= 42 ? -1 : 0;
								if (tile->getObstacle(O_OBJECT))
									Surface::blitRaw(surface, tmpSurface, screenPosition.x + edge, screenPosition.y + edge - tile->getYOffset(O_OBJECT), obstacleShade, false, _nvColor);
								else
									Surface::blitRaw(surface, tmpSurface, screenPosition.x + edge, screenPosition.y + edge - tile->getYOffset(O_OBJECT), tileShade, false, _nvColor);
							}
						}
					}
					// Draw cursor front
					if (_cursorType != CT_NONE && _selectorX > itX - _cursorSize && _selectorY > itY - _cursorSize && _selectorX < itX+1 && _selectorY < itY+1 && !_save->getBattleState()->getMouseOverIcons())
					{
						if (_camera->getViewLevel() == itZ)
						{
							if (_cursorType != CT_AIM)
							{
								if (unit && (unit->getVisible() || _save->getDebugMode()))
									frameNumber = 3 + halfAnimFrameRest; // yellow box
								else
									frameNumber = 3; // red box
							}
							else
							{
								if (unit && (unit->getVisible() || _save->getDebugMode()))
									frameNumber = 7 + halfAnimFrame; // yellow animated crosshairs
								else
									frameNumber = 6; // red static crosshairs
							}
							tmpSurface = _game->getMod()->getSurfaceSet("CURSOR.PCK")->getFrame(frameNumber);
							Surface::blitRaw(surface, tmpSurface, screenPosition.x, screenPosition.y, 0);

							// UFO extender accuracy: display adjusted accuracy value on crosshair in real-time.
							if (_cursorType >= CT_AIM && _showInfoOnCursor && (_cursorType != CT_THROW || !Options::oxceDisableInfoOnThrowCursor) &&
								!(_r22On && Options::battleConfirmFireMode &&
								  _save->getBattleGame() &&
								  _save->getBattleGame()->getCurrentAction() &&
								  _save->getBattleGame()->getCurrentAction()->targeting &&
								  !_save->getBattleGame()->getCurrentAction()->waypoints.empty() &&
								  Position(itX,itY,itZ) !=
								    _save->getBattleGame()->getCurrentAction()->waypoints.front()))
							{
								BattleAction *action = _save->getBattleGame()->getCurrentAction();
								const RuleItem *weapon = action->weapon->getRules();
								std::ostringstream ss;
								BattleActionAttack attack = BattleActionAttack::GetBeforeShoot(*action);
								int distanceSq = action->actor->distance3dToPositionSq(Position(itX, itY,itZ));
								int distance = (int)std::ceil(sqrt(float(distanceSq)));

								if (_cursorType == CT_AIM || _cursorType == CT_THROW)
								{
									int accuracy = BattleUnit::getFiringAccuracy(attack, _game->getMod());

									{
										int upperLimit, lowerLimit;
										int dropoff = weapon->calculateLimits(upperLimit, lowerLimit, _save->getDepth(), action->type);

										// at this point, let's assume the shot is adjusted and set the text amber.
										_txtAccuracy->setColor(Palette::blockOffset(Pathfinding::yellow - 1) - 1);

										if (distance > upperLimit)
										{
											accuracy -= (distance - upperLimit) * dropoff;
										}
										else if (distance < lowerLimit)
										{
											accuracy -= (lowerLimit - distance) * dropoff;
										}
										else
										{
											// no adjustment made? set it to green.
											_txtAccuracy->setColor(Palette::blockOffset(Pathfinding::green - 1) - 1);
										}
									}

									// Include LOS penalty for tiles in the unit's current view range
									// Don't recalculate LOS for outside of the current FOV
									int noLOSAccuracyPenalty = action->weapon->getRules()->getNoLOSAccuracyPenalty(_game->getMod());
									if (noLOSAccuracyPenalty != -1)
									{
										bool hasLOS = false;
										if (Position(itX, itY, itZ) == _cacheCursorPosition && _isCtrlPressed == _cacheIsCtrlPressed && _cacheHasLOS != -1)
										{
											// use cached result
											hasLOS = (_cacheHasLOS == 1);
										}
										else
										{
											// recalculate
											if (unit && (unit->getVisible() || _save->getDebugMode()))
											{
												hasLOS = _save->getTileEngine()->visible(action->actor, tile);
											}
											else
											{
												hasLOS = _save->getTileEngine()->isTileInLOS(action, tile, true);
											}
											// remember
											_cacheIsCtrlPressed = _isCtrlPressed;
											_cacheCursorPosition = Position(itX, itY, itZ);
											_cacheHasLOS = hasLOS ? 1 : 0;
										}

										if (!hasLOS)
										{
											accuracy = accuracy * noLOSAccuracyPenalty / 100;
											_txtAccuracy->setColor(Palette::blockOffset(Pathfinding::yellow - 1) - 1);
										}
									}

									bool outOfRange = action->type == BA_THROW
										? weapon->isOutOfThrowRange(distanceSq, _save->getDepth())
										: weapon->isOutOfRange(distanceSq);

									// zero accuracy or out of range: set it red.
									if (accuracy <= 0 || outOfRange)
									{
										accuracy = 0;
										_txtAccuracy->setColor(Palette::blockOffset(Pathfinding::red - 1) - 1);
									}
									ss << accuracy;
									ss << "%";
								}

								//TODO: merge this code with `InventoryState::calculateCurrentDamageTooltip` as 90% is same or should be same
								// display additional damage and psi-effectiveness info
								if (_isAltPressed)
								{
									// step 1: determine rule
									const RuleItem *rule;
									if (weapon->getBattleType() == BT_PSIAMP)
									{
										rule = weapon;
									}
									else if (action->weapon->needsAmmoForAction(action->type))
									{
										auto* ammo = attack.damage_item;
										if (ammo != nullptr)
										{
											rule = ammo->getRules();
										}
										else
										{
											rule = 0; // empty weapon = no rule
										}
									}
									else
									{
										rule = weapon;
									}

									// step 2: check if unlocked
									if (_cacheActiveWeaponUfopediaArticleUnlocked == -1)
									{
										_cacheActiveWeaponUfopediaArticleUnlocked = 0;
										if (_game->getSavedGame()->getMonthsPassed() == -1)
										{
											_cacheActiveWeaponUfopediaArticleUnlocked = 1; // new battle mode
										}
										else if (rule)
										{
											_cacheActiveWeaponUfopediaArticleUnlocked = 1; // assume unlocked
											ArticleDefinition *article = _game->getMod()->getUfopaediaArticle(rule->getType(), false);
											if (article && !Ufopaedia::isArticleAvailable(_game->getSavedGame(), article))
											{
												_cacheActiveWeaponUfopediaArticleUnlocked = 0; // ammo/weapon locked
											}
											if (rule->getType() != weapon->getType())
											{
												article = _game->getMod()->getUfopaediaArticle(weapon->getType(), false);
												if (article && !Ufopaedia::isArticleAvailable(_game->getSavedGame(), article))
												{
													_cacheActiveWeaponUfopediaArticleUnlocked = 0; // weapon locked
												}
											}
										}
									}

									// step 3: calculate and draw
									if (rule && _cacheActiveWeaponUfopediaArticleUnlocked == 1)
									{
										if (rule->getBattleType() == BT_PSIAMP)
										{
											float attackStrength = BattleUnit::getPsiAccuracy(attack);
											float defenseStrength = 30.0f; // indicator ignores: +victim->getArmor()->getPsiDefence(victim);

											float dis = Position::distance(action->actor->getPosition().toVoxel(), Position(itX, itY, itZ).toVoxel());
											int min = attackStrength - defenseStrength - rule->getPsiAccuracyRangeReduction(dis);
											int max = min + 55;
											if (max <= 0)
											{
												ss << "0%";
											}
											else
											{
												ss << min << "-" << max << "%";
											}
										}
										if (rule->getBattleType() != BT_PSIAMP || action->type == BA_USE)
										{
											int totalDamage = 0;
											if (weapon->getIgnoreAmmoPower())
											{
												totalDamage += weapon->getPowerBonus(attack);
												totalDamage -= weapon->getPowerRangeReduction(distance * 16);
											}
											else
											{
												totalDamage += rule->getPowerBonus(attack);
												totalDamage -= rule->getPowerRangeReduction(distance * 16);
											}
											if (totalDamage < 0) totalDamage = 0;
											if (_cursorType != CT_WAYPOINT)
												ss << "\n";
											ss << rule->getDamageType()->getRandomDamage(totalDamage, 1);
											ss << "-";
											ss << rule->getDamageType()->getRandomDamage(totalDamage, 2);
											if (rule->getDamageType()->RandomType == DRT_UFO_WITH_TWO_DICE)
												ss << "*";
										}
									}
									else
									{
										ss << "\n?-?";
									}
								}

								_txtAccuracy->setText(ss.str());
								_txtAccuracy->draw();
								_txtAccuracy->blitNShade(surface, screenPosition.x, screenPosition.y, 0);
							}
						}
						else if (_camera->getViewLevel() > itZ)
						{
							frameNumber = 5; // blue box
							tmpSurface = _game->getMod()->getSurfaceSet("CURSOR.PCK")->getFrame(frameNumber);
							Surface::blitRaw(surface, tmpSurface, screenPosition.x, screenPosition.y, 0);
						}
						if (!_isAltPressed && _cursorType > CT_AIM && _camera->getViewLevel() == itZ)
						{
							bool ignore = false;
							if (_cursorType == CT_PSI || _cursorType == CT_WAYPOINT)
							{
								BattleAction* action = _save->getBattleGame()->getCurrentAction();
								int distanceSq = action->actor->distance3dToPositionSq(Position(itX, itY, itZ));
								if (action->weapon->getRules()->isOutOfRange(distanceSq))
								{
									// weapon doesn't work at this distance, just draw a normal cursor with a red 0% hint text
									ignore = true;
									_txtAccuracy->setColor(Palette::blockOffset(Pathfinding::red - 1) - 1);
									_txtAccuracy->setText("0%");
									_txtAccuracy->draw();
									_txtAccuracy->blitNShade(surface, screenPosition.x, screenPosition.y, 0);
								}
							}
							if (!ignore)
							{
								int frame[6] = { 0, 0, 0, 11, 13, 15 };
								tmpSurface = _game->getMod()->getSurfaceSet("CURSOR.PCK")->getFrame(frame[_cursorType] + (_animFrame / 4) % 2);
								Surface::blitRaw(surface, tmpSurface, screenPosition.x, screenPosition.y, 0);
							}
						}
					}

					// Draw waypoints if any on this tile
					int waypid = 1;
					int waypXOff = 2;
					int waypYOff = 2;

					for (const auto& waypoint : _waypoints)
					{
						if (waypoint == mapPosition)
						{
							if (waypXOff == 2 && waypYOff == 2)
							{
								tmpSurface = _game->getMod()->getSurfaceSet("CURSOR.PCK")->getFrame(7);
								Surface::blitRaw(surface, tmpSurface, screenPosition.x, screenPosition.y, 0);
							}
							if (_save->getBattleGame()->getCurrentAction()->type == BA_LAUNCH || _save->getBattleGame()->getCurrentAction()->sprayTargeting)
							{
								_numWaypid->setValue(waypid);
								_numWaypid->setBordered(true); // OXCE, not configurable
								_numWaypid->draw();
								_numWaypid->blitNShade(surface, screenPosition.x + waypXOff, screenPosition.y + waypYOff, 0);

								waypXOff += waypid > 9 ? 10 : 6; // OXCE
								if (waypXOff >= 26)
								{
									waypXOff = 2;
									waypYOff += 8;
								}
							}
						}
						waypid++;
					}
				}
			}
		}
	}
	if (pathfinderTurnedOn)
	{
		if (_numWaypid)
		{
			_numWaypid->setBordered(true); // give it a border for the pathfinding display, makes it more visible on snow, etc.
		}
		for (int itZ = beginZ; itZ <= endZ; itZ++)
		{
			for (int itX = beginX; itX <= endX; itX++)
			{
				for (int itY = beginY; itY <= endY; itY++)
				{
					mapPosition = Position(itX, itY, itZ);
					_camera->convertMapToScreen(mapPosition, &screenPosition);
					screenPosition += _camera->getMapOffset();

					// only render cells that are inside the surface
					if (screenPosition.x > -_spriteWidth && screenPosition.x < surface->getWidth() + _spriteWidth &&
						screenPosition.y > -_spriteHeight && screenPosition.y < surface->getHeight() + _spriteHeight )
					{
						tile = _save->getTile(mapPosition);
						if (!tile || !tile->isDiscovered(O_FLOOR) || tile->getPreview() == -1)
							continue;
						int adjustment = -tile->getTerrainLevel();
						if (_previewSettingArrows)
						{
							if (itZ > 0 && tile->hasNoFloor(_save))
							{
								tmpSurface = _game->getMod()->getSurfaceSet("Pathfinding")->getFrame(23);
								if (tmpSurface)
								{
									Surface::blitRaw(surface, tmpSurface, screenPosition.x, screenPosition.y+2, 0, false, tile->getMarkerColor());
								}
							}
							int overlay = (tile->getPreview() >= 0 && tile->getPreview() < 8 ? ((tile->getPreview() + 8 - 2 * _r41Rotation) & 7) : tile->getPreview()) + 12;
							tmpSurface = _game->getMod()->getSurfaceSet("Pathfinding")->getFrame(overlay);
							if (tmpSurface)
							{
								Surface::blitRaw(surface, tmpSurface, screenPosition.x, screenPosition.y - adjustment, 0, false, tile->getMarkerColor());
							}
						}

						if ((_previewSettingTu || _previewSettingEnergy) && (tile->getTUMarker() > -1 || tile->getEnergyMarker() > -1))
						{
							int off = tile->getTUMarker() > 9 ? 5 : 3;
							int offE = tile->getEnergyMarker() > 9 ? 5 : 3;
							int mcolor = _previewSettingArrows ? 0 : tile->getMarkerColor();
							if (_previewSettingArrows)
							{
								adjustment += 7;
							}
							if (_save->getSelectedUnit() && _save->getSelectedUnit()->isBigUnit())
							{
								adjustment += 1;
								if (!_previewSettingArrows)
								{
									adjustment += 7;
								}
							}
							if (_previewSettingTu)
							{
								_numWaypid->setValue(tile->getTUMarker());
								_numWaypid->draw();
								if (_previewSettingEnergy)
								{
									// TU
									_numWaypid->blitNShade(surface, screenPosition.x + 16 - off, screenPosition.y + (22 - adjustment), 0, false, mcolor);
									// and Energy
									_numWaypid->setValue(tile->getEnergyMarker());
									_numWaypid->draw();
									_numWaypid->blitNShade(surface, screenPosition.x + 16 - offE, screenPosition.y + (29 - adjustment), 0, false, mcolor);
								}
								else
								{
									// only TU
									_numWaypid->blitNShade(surface, screenPosition.x + 16 - off, screenPosition.y + (29 - adjustment), 0, false, mcolor);
								}
							}
							else if (_previewSettingEnergy)
							{
								// only Energy
								_numWaypid->setValue(tile->getEnergyMarker());
								_numWaypid->draw();
								_numWaypid->blitNShade(surface, screenPosition.x + 16 - offE, screenPosition.y + (29 - adjustment), 0, false, mcolor);
							}
						}
					}
				}
			}
		}
		if (_numWaypid)
		{
			_numWaypid->setBordered(false); // make sure we remove the border in case it's being used for missile waypoints.
		}
	}

	auto* selectedUnit = _save->getSelectedUnit();
	if (selectedUnit && (_save->getSide() == FACTION_PLAYER || _save->getDebugMode()) && selectedUnit->getPosition().z <= _camera->getViewLevel())
	{
		_camera->convertMapToScreen(selectedUnit->getPosition(), &screenPosition);
		screenPosition += _camera->getMapOffset();
		Position offset = calculateWalkingOffset(selectedUnit).ScreenOffset;
		if (selectedUnit->isBigUnit())
		{
			offset.y += 4;
		}
		offset.y += Position::TileZ - (selectedUnit->getHeight() + selectedUnit->getFloatHeight());
		if (selectedUnit->isKneeled())
		{
			offset.y -= 2;
		}
		if (this->getCursorType() != CT_NONE)
		{
			_arrow->blitNShade(surface, screenPosition.x + offset.x + (_spriteWidth / 2) - (_arrow->getWidth() / 2), screenPosition.y + offset.y - _arrow->getHeight() + getArrowBobForFrame(_animFrame), 0);
		}
	}

	// Draw motion scanner arrows
	if (_isAltPressed && _save->getSide() == FACTION_PLAYER && this->getCursorType() != CT_NONE)
	{
		for (auto* myUnit : *_save->getUnits())
		{
			bool motionScan = myUnit->getScannedTurn() == _save->getTurn() && myUnit->getFaction() != FACTION_PLAYER && !myUnit->isOut();
			bool customMarker = myUnit->getCustomMarker() > 0 && myUnit->getFaction() == FACTION_PLAYER && !myUnit->isOut();
			if (motionScan || customMarker)
			{
				Position temp = myUnit->getPosition();
				temp.z = _camera->getViewLevel();
				_camera->convertMapToScreen(temp, &screenPosition);
				screenPosition += _camera->getMapOffset();
				Position offset;
				//calculateWalkingOffset(myUnit, &offset);
				if (myUnit->isBigUnit())
				{
					offset.y += 4;
				}
				if (motionScan)
				{
					offset.y += Position::TileZ - /*myUnit->getHeight()*/ 21; // no spoilers
				}
				else if (customMarker)
				{
					offset.y += Position::TileZ - (myUnit->getHeight() + myUnit->getFloatHeight());
				}
				if (myUnit->isKneeled())
				{
					offset.y -= 2;
				}
				if (motionScan)
				{
					_arrow->blitNShade(
						surface,
						screenPosition.x + offset.x + (_spriteWidth / 2) - (_arrow->getWidth() / 2),
						screenPosition.y + offset.y - _arrow->getHeight() + getArrowBobForFrame(_animFrame),
						0);
				}
				else if (customMarker)
				{
					Surface::blitRaw(
						surface,
						_arrow,
						screenPosition.x + offset.x + (_spriteWidth / 2) - (_arrow->getWidth() / 2),
						screenPosition.y + offset.y - _arrow->getHeight() + getArrowBobForFrame(_animFrame),
						0,
						false,
						_isTFTD ? ArrowColorsTFTD[myUnit->getCustomMarker() % 4] : ArrowColorsUFO[myUnit->getCustomMarker() % 4]);
				}
			}
		}
	}
	delete _numWaypid;

	// Draw craft deployment preview arrows
	if (_isAltPressed && _save->isPreview() && this->getCursorType() != CT_NONE)
	{
		for (auto& pos : _save->getCraftTiles())
		{
			if (pos.z == _camera->getViewLevel())
			{
				_camera->convertMapToScreen(pos, &screenPosition);
				screenPosition += _camera->getMapOffset();
				screenPosition.y += 2; // based on vanilla soldier standHeight
				_arrow->blitNShade(
					surface,
					screenPosition.x + (_spriteWidth / 2) - (_arrow->getWidth() / 2),
					screenPosition.y - _arrow->getHeight() + getArrowBobForFrame(_animFrame),
					0);
			}
		}
	}

	// check if we got big explosions
	if (_explosionInFOV)
	{
		// big explosions cause the screen to flash as bright as possible before any explosions are actually drawn.
		// this causes everything to look like EGA for a single frame.
		if (_flashScreen)
		{
			for (int x = 0, y = 0; x < surface->getWidth() && y < surface->getHeight();)
			{
				Uint8 pixel = surface->getPixel(x, y);
				if (pixel)
				{
					pixel = (pixel & 0xF0) + 1; //avoid 0 pixel
					surface->setPixelIterative(&x, &y, pixel);
				}
			}
			_flashScreen = false;
		}
		else
		{
			for (const auto* explosion : _explosions)
			{
				_camera->convertVoxelToScreen(explosion->getPosition(), &bulletPositionScreen);
				if (explosion->isBig())
				{
					if (explosion->getCurrentFrame() >= 0)
					{
						tmpSurface = _game->getMod()->getSurfaceSet("X1.PCK")->getFrame(explosion->getCurrentFrame());
						Surface::blitRaw(surface, tmpSurface, bulletPositionScreen.x - (tmpSurface.getWidth() / 2), bulletPositionScreen.y - (tmpSurface.getHeight() / 2), 0, false, _nvColor);
					}
				}
				else if (explosion->isHit())
				{
					tmpSurface = _game->getMod()->getSurfaceSet("HIT.PCK")->getFrame(explosion->getCurrentFrame());
					Surface::blitRaw(surface, tmpSurface, bulletPositionScreen.x - 15, bulletPositionScreen.y - 25, 0, false, _nvColor);
				}
				else
				{
					tmpSurface = _game->getMod()->getSurfaceSet("SMOKE.PCK")->getFrame(explosion->getCurrentFrame());
					Surface::blitRaw(surface, tmpSurface, bulletPositionScreen.x - 15, bulletPositionScreen.y - 15, 0, false, _nvColor);
				}
			}
		}
	}

	surface->unlock();
}

/**
 * Handles mouse presses on the map.
 * @param action Pointer to an action.
 * @param state State that the action handlers belong to.
 */
void Map::mousePress(Action *action, State *state)
{
	InteractiveSurface::mousePress(action, state);
	_camera->mousePress(action, state);
}

/**
 * Handles mouse releases on the map.
 * @param action Pointer to an action.
 * @param state State that the action handlers belong to.
 */
void Map::mouseRelease(Action *action, State *state)
{
	InteractiveSurface::mouseRelease(action, state);
	_camera->mouseRelease(action, state);
}

/**
 * Handles keyboard presses on the map.
 * @param action Pointer to an action.
 * @param state State that the action handlers belong to.
 */
void Map::keyboardPress(Action *action, State *state)
{

    // LOSLOF_R22_NATIVE_INPUT_FIX: do NOT intercept map clicks.
    // F8 only toggles passive drawing. Backslash toggles virtual stance
    // while native OXCE is in an actual weapon-targeting state.
    if (action && action->getDetails()->type == SDL_KEYDOWN)
    {
        const SDLKey key = action->getDetails()->key.keysym.sym;
        // R43_QA_ONLY: Shift+F9 targets the saved Skyranger position.
        if (key == SDLK_F9 && (action->getDetails()->key.keysym.mod & KMOD_SHIFT))
        {
            if (_save && !_save->getDebugMode()) _save->setDebugMode();
            const int level=(action->getDetails()->key.keysym.mod & KMOD_ALT)?0:
                (action->getDetails()->key.keysym.mod & KMOD_CTRL)?2:1;
            r43QaCenter=Position(24,52,level);
            r43QaPin=true;
            _camera->stopMouseScrolling();
            _camera->stopKeyScrolling();
            _camera->centerOnPosition(r43QaCenter,false);
            _r41PivotValid=true;
            _r41PivotWorld=r43QaCenter;
            _redraw=true;
            return;
        }
        // R41: Shift+F10 clockwise; Ctrl+Shift+F10 counterclockwise.
        // De-bounce key repeat; keep the world point at viewport center.
        if (key == SDLK_F10 && (action->getDetails()->key.keysym.mod & KMOD_SHIFT))
        {
            const Uint32 rotateNow = SDL_GetTicks();
            const Uint32 elapsedSinceLastRotation = rotateNow - _r41LastRotationAt;
            // Debounce auto-repeat while accepting every distinct tap.
            if (_camera && elapsedSinceLastRotation >= 180U)
            {
                _r41LastRotationAt = rotateNow;
                _camera->stopMouseScrolling();
                _camera->stopKeyScrolling();
                // Cached _center may be stale after loading a save.
                // Resolve the WORLD tile at the viewport center BEFORE
                // changing the orientation; then project that same tile.
                // Preserve one world pivot across successive rotations.
                // Rounding in inverse tile projection otherwise accumulates
                // >10 tiles of drift with every 90-degree turn.
                const Position currentOffset = _camera->getMapOffset();
                if (!_r41PivotValid || elapsedSinceLastRotation > 10000U)
                {
                    int centerX=0, centerY=0;
                    _camera->convertScreenToMap(getWidth()/2,
                        _visibleMapHeight/2, &centerX, &centerY);
                    _r41PivotWorld = Position(centerX,centerY,_camera->getViewLevel());
                    _r41PivotValid = true;
                }
                const int change = (action->getDetails()->key.keysym.mod & KMOD_CTRL) ? 3 : 1;
                const int oldRotation = _r41Rotation;
                _r41Rotation = (_r41Rotation + change) % 4;
                _camera->centerOnPosition(_r41PivotWorld, false);
                _r41PivotOffset = _camera->getMapOffset();
                Log(LOG_INFO) << "R41_VIEW_ROTATE " << oldRotation
                    << " -> " << _r41Rotation << " center=" << _r41PivotWorld;
                setSelectorPosition(_mouseX, _mouseY);
                _r22ThrowCacheKey = 0;
                _r22StatsKey = 0;
                r29ClearBlockGrid();
                _redraw = true;
            }
            return;
        }
        if (key == SDLK_F8)
        {
            // R32: Shift+F8 independently toggles the six-field enemy census.
            // Preserve the R30 twenty-type resistance reference when F8 is on.
            if (action->getDetails()->key.keysym.mod & KMOD_SHIFT)
            {
                _r32EnemyCounts = !_r32EnemyCounts;
                if (_r22On) _r30FullResists = !_r30FullResists;
                _redraw = true;
                return;
            }
            _r22On = !_r22On;
            _r30FullResists = false;
            _r22StanceActor = _save ? _save->getSelectedUnit() : nullptr;
            _r22StanceOverride = false;
            _r22Kneel = _r22StanceActor ?
                _r22StanceActor->isKneeled() : false;
            _r22StatsKey = 0;
            _r22HullHash = 0;
            // Force fresh visible-reaction estimates after every F8 toggle.
            _r37ReactionCheckedAt = 0;
            _r37ReactionRisks.clear();
            _r22ThrowCacheKey = 0;
            _r22ThrowTrajectory.clear();
            _r22ThrowValid = false;
            _r22StatsText.clear();
            _r22TileRisks.clear();
            r29ClearBlockGrid();
            _redraw = true;
            return;
        }
        if (key == SDLK_BACKSLASH && _r22On && _save &&
            _save->getSide() == FACTION_PLAYER && _save->getBattleGame())
        {
            BattleAction *native = _save->getBattleGame()->getCurrentAction();
            BattleUnit *actor = _save->getSelectedUnit();
            if (native && native->targeting && actor && native->actor == actor &&
                (native->type == BA_SNAPSHOT || native->type == BA_AIMEDSHOT ||
                 native->type == BA_AUTOSHOT || native->type == BA_THROW))
            {
                if (_r22StanceActor != actor)
                {
                    _r22StanceActor = actor;
                    _r22StanceOverride = false;
                }
                const bool current = _r22StanceOverride ?
                    _r22Kneel : actor->isKneeled();
                _r22Kneel = !current; // virtual only; NO kneel() call.
                _r22StanceOverride = true;
                _r22StatsKey = 0;
                _r22HullHash = 0;
                _r22ThrowCacheKey = 0;
                _r22StatsText.clear();
                _r22TileRisks.clear();
                r29ClearBlockGrid();
                _redraw = true;
                return;
            }
        }
    }

	InteractiveSurface::keyboardPress(action, state);
	_camera->keyboardPress(action, state);
}

/**
 * Handles map vision toggle mode.
 */

void Map::enableNightVision()
{
	_nightVisionOn = true;
	_debugVisionMode = 0;
	persistToggles();
}

void Map::toggleNightVision()
{
	_nightVisionOn = !_nightVisionOn;
	_debugVisionMode = 0;
	persistToggles();
}

void Map::toggleDebugVisionMode()
{
	_debugVisionMode = (_debugVisionMode + 1) % 3;
	_nightVisionOn = false;
	persistToggles();
}

void Map::persistToggles()
{
	if (Options::oxceToggleNightVisionType == 2)
	{
		// persisted per campaign
		_game->getSavedGame()->setToggleNightVision(_nightVisionOn);
	}
	else if (Options::oxceToggleNightVisionType == 1)
	{
		// persisted per battle
		_save->setToggleNightVision(_nightVisionOn);
	}

	if (Options::oxceToggleBrightnessType == 2)
	{
		// persisted per campaign
		_game->getSavedGame()->setToggleBrightness(_debugVisionMode);
	}
	else if (Options::oxceToggleBrightnessType == 1)
	{
		// persisted per battle
		_save->setToggleBrightness(_debugVisionMode);
	}

	_save->setToggleBrightnessTemp(_debugVisionMode);
}

/**
 * Handles fade-in and fade-out shade modification
 * @param original tile/item/unit shade
 */

int Map::reShade(Tile *tile) const
{
	// when modders just don't know where to stop...
	if (_debugVisionMode > 0)
	{
		if (_debugVisionMode == 1)
		{
			// Reaver's tests
			return tile->getShade() / 2;
		}
		// Meridian's debug helper
		return 0;
	}

	// no night vision
	if (_nvColor == 0)
	{
		return tile->getShade();
	}

	// already bright enough
	if ((tile->getShade() <= NIGHT_VISION_SHADE))
	{
		return tile->getShade();
	}

	// hybrid night vision (local)
	for (const auto* bu : *_save->getUnits())
	{
		if (bu->getFaction() == FACTION_PLAYER && !bu->isOut())
		{
			if (Position::distance2dSq(tile->getPosition(), bu->getPosition()) <= bu->getMaxViewDistanceAtDarkSquared())
			{
				return tile->getShade() > _fadeShade ? _fadeShade : tile->getShade();
			}
		}
	}

	// hybrid night vision (global)
	return std::min(+NIGHT_VISION_MAX_SHADE, tile->getShade());
}

int Map::reShadeMinimap(int maxShade) const
{
	if (_debugVisionMode > 0)
	{
		if (_debugVisionMode == 1)
		{
			return maxShade / 2;
		}
		return 0;
	}

	if (_nvColor == 0)
	{
		return maxShade;
	}

	return std::min(+NIGHT_VISION_MAX_SHADE / 2, maxShade);
}

/**
 * Handles keyboard releases on the map.
 * @param action Pointer to an action.
 * @param state State that the action handlers belong to.
 */
void Map::keyboardRelease(Action *action, State *state)
{
	InteractiveSurface::keyboardRelease(action, state);
	_camera->keyboardRelease(action, state);
}

/**
 * Handles mouse over events on the map.
 * @param action Pointer to an action.
 * @param state State that the action handlers belong to.
 */
void Map::mouseOver(Action *action, State *state)
{
	InteractiveSurface::mouseOver(action, state);
	_camera->mouseOver(action, state);
	_mouseX = (int)action->getAbsoluteXMouse();
	_mouseY = (int)action->getAbsoluteYMouse();
	setSelectorPosition(_mouseX, _mouseY);
}


/**
 * Sets the selector to a certain tile on the map.
 * @param mx mouse x position.
 * @param my mouse y position.
 */
void Map::setSelectorPosition(int mx, int my)
{
	int oldX = _selectorX, oldY = _selectorY;

	_camera->convertScreenToMap(mx, my + _spriteHeight/4, &_selectorX, &_selectorY);

	if (oldX != _selectorX || oldY != _selectorY)
	{
		_redraw = true;
	}
}

/**
 * Handles animating tiles. 8 Frames per animation.
 * @param redraw Redraw the battlescape?
 */
void Map::animate(bool redraw)
{
	_save->nextAnimFrame();
	_animFrame = _save->getAnimFrame();

	// random ambient sounds
	{
		if (!_save->getAmbienceRandom().empty())
		{
			_save->decreaseCurrentAmbienceDelay();
			if (_save->getCurrentAmbienceDelay() <= 0)
			{
				_save->resetCurrentAmbienceDelay();
				_save->playRandomAmbientSound();
			}
		}
	}

	// animate tiles
	for (int i = 0; i < _save->getMapSizeXYZ(); ++i)
	{
		_save->getTile(i)->animate();
	}

	// animate vapor
	for (auto i : Collections::rangeValueLess(_vaporParticles.size()))
	{
		auto& v = _vaporParticles[i];
		int posX = i % _camera->getMapSizeX();
		int posY = i / _camera->getMapSizeX();

		Collections::removeIf(
			v,
			[&](Particle& p)
			{
				if (p.animate())
				{
					Position tileOffset = p.updateScreenPosition();
					if (tileOffset != Position(0,0,0))
					{
						addVaporParticle(Position(posX,posY,0) + tileOffset, p);
						return true;
					}
					return false;
				}
				else
				{
					return true;
				}
			}
		);
	}

	// init vapor vector
	for (auto i : Collections::rangeValueLess(_vaporParticlesInit.size()))
	{
		auto& vi = _vaporParticlesInit[i];
		auto& vDest = _vaporParticles[i];
		if (vi.empty())
		{
			continue;
		}

		if (vDest.empty())
		{
			vi.swap(vDest);
		}
		else
		{
			vDest.insert(std::begin(vDest), std::begin(vi), std::end(vi));
		}


		Collections::removeAll(vi);
	}

	for (auto& tilePar : _vaporParticles)
	{
		if (tilePar.empty())
		{
			Collections::removeAll(tilePar);
		}
		else
		{
			std::sort(std::begin(tilePar), std::end(tilePar), [](const Particle& a, const Particle& b){ return a.getLayerZ() < b.getLayerZ(); });
		}
	}

	// animate certain units (large flying units have a propulsion animation)
	for (auto* bu : *_save->getUnits())
	{
		const Position pos = bu->getPosition();

		// skip units that do not have position
		if (pos == TileEngine::invalid)
		{
			continue;
		}

		if (_save->getDepth() > 0)
		{
			bu->setFloorAbove(false);

			// make sure this unit isn't obscured by the floor above him, otherwise it looks weird.
			if (_camera->getViewLevel() > pos.z)
			{
				for (int z = std::min(_camera->getViewLevel(), _save->getMapSizeZ() - 1); z != pos.z; --z)
				{
					if (!_save->getTile(Position(pos.x, pos.y, z))->hasNoFloor(0))
					{
						bu->setFloorAbove(true);
						break;
					}
				}
			}
		}

		bu->breathe();
	}

	if (redraw) _redraw = true;
}

/**
 * Draws the rectangle selector.
 * @param pos Pointer to a position.
 */
void Map::getSelectorPosition(Position *pos) const
{
	pos->x = _selectorX;
	pos->y = _selectorY;
	pos->z = _camera->getViewLevel();
}

/**
 * Calculates the offset of a soldier, when it is walking in the middle of 2 tiles.
 * @param unit Pointer to BattleUnit.
 * @param offset Pointer to the offset to return the calculation.
 */
UnitWalkingOffset Map::calculateWalkingOffset(const BattleUnit *unit) const
{
	UnitWalkingOffset result = { };

	int offsetX[8] = { 1, 1, 1, 0, -1, -1, -1, 0 };
	int offsetY[8] = { 1, 0, -1, -1, -1, 0, 1, 1 };
	int phase = unit->getWalkingPhase() + unit->getDiagonalWalkingPhase();
	// Movement interpolation follows the displayed direction, not native XY.
	int dir = (unit->getDirection() + 8 - 2 * _r41Rotation) % 8;
	int midphase = 4 + 4 * (dir % 2);
	int endphase = 8 + 8 * (dir % 2);
	int size = unit->getArmor()->getSize();

	result.ScreenOffset.x = 0;
	result.ScreenOffset.y = 0;

	if (size > 1)
	{
		if (dir < 1 || dir > 5)
			midphase = endphase;
		else if (dir == 5)
			midphase = 12;
		else if (dir == 1)
			midphase = 5;
		else
			midphase = 1;
	}
	if (unit->getVerticalDirection())
	{
		midphase = 4;
		endphase = 8;
	}
	else if ((unit->getStatus() == STATUS_WALKING || unit->getStatus() == STATUS_FLYING))
	{
		if (phase < midphase)
		{
			result.ScreenOffset.x = phase * 2 * offsetX[dir];
			result.ScreenOffset.y = - phase * offsetY[dir];
		}
		else
		{
			result.ScreenOffset.x = (phase - endphase) * 2 * offsetX[dir];
			result.ScreenOffset.y = - (phase - endphase) * offsetY[dir];
		}
	}

	result.NormalizedMovePhase = endphase == 16 ? phase : phase * 2;

	// If we are walking in between tiles, interpolate it's terrain level.
	if (unit->getStatus() == STATUS_WALKING || unit->getStatus() == STATUS_FLYING)
	{
		const Position posCurr = unit->getPosition();
		const Position posDest = unit->getDestination();
		const Position posLast = unit->getLastPosition();
		if (phase < midphase)
		{
			int fromLevel = getTerrainLevel(posCurr, size);
			int toLevel = getTerrainLevel(posDest, size);
			if (posCurr.z > posDest.z)
			{
				// going down a level, so toLevel 0 becomes +24, -8 becomes  16
				toLevel += Position::TileZ*(posCurr.z - posDest.z);
			}
			else if (posCurr.z < posDest.z)
			{
				// going up a level, so toLevel 0 becomes -24, -8 becomes -16
				toLevel = -Position::TileZ*(posDest.z - posCurr.z) + abs(toLevel);
			}
			result.TerrainLevelOffset = Interpolate(fromLevel, toLevel, phase, endphase);
		}
		else
		{
			// from phase 4 onwards the unit behind the scenes already is on the destination tile
			// we have to get it's last position to calculate the correct offset
			int fromLevel = getTerrainLevel(posLast, size);
			int toLevel = getTerrainLevel(posDest, size);
			if (posLast.z > posDest.z)
			{
				// going down a level, so fromLevel 0 becomes -24, -8 becomes -32
				fromLevel -= Position::TileZ*(posLast.z - posDest.z);
			}
			else if (posLast.z < posDest.z)
			{
				// going up a level, so fromLevel 0 becomes +24, -8 becomes 16
				fromLevel = Position::TileZ*(posDest.z - posLast.z) - abs(fromLevel);
			}
			result.TerrainLevelOffset = Interpolate(fromLevel, toLevel, phase, endphase);
		}
	}
	else
	{
		result.TerrainLevelOffset = getTerrainLevel(unit->getPosition(), size);
	}
	result.ScreenOffset.y += result.TerrainLevelOffset;
	return result;
}


/**
  * Terrainlevel goes from 0 to -24. For a larger sized unit, we need to pick the highest terrain level, which is the lowest number...
  * @param pos Position.
  * @param size Size of the unit we want to get the level from.
  * @return terrainlevel.
  */
int Map::getTerrainLevel(const Position& pos, int size) const
{
	int lowestlevel = 0;

	for (int x = 0; x < size; x++)
	{
		for (int y = 0; y < size; y++)
		{
			int l = _save->getTile(pos + Position(x,y,0))->getTerrainLevel();
			if (l < lowestlevel)
				lowestlevel = l;
		}
	}

	return lowestlevel;
}

/**
 * Sets the 3D cursor to selection/aim mode.
 * @param type Cursor type.
 * @param size Size of cursor.
 */
void Map::setCursorType(CursorType type, int size)
{
	// reset cursor indicator cache
	_cacheActiveWeaponUfopediaArticleUnlocked = -1;
	_cacheIsCtrlPressed = false;
	_cacheCursorPosition = TileEngine::invalid;
	_cacheHasLOS = -1;

	_cursorType = type;
	if (_cursorType == CT_NORMAL)
		_cursorSize = size;
	else
		_cursorSize = 1;
}

/**
 * Gets the cursor type.
 * @return cursor type.
 */
CursorType Map::getCursorType() const
{
	return _cursorType;
}

/**
 * Puts a projectile sprite on the map.
 * @param projectile Projectile to place.
 */
void Map::setProjectile(Projectile *projectile)
{
	_projectile = projectile;
	if (projectile && Options::battleSmoothCamera)
	{
		_launch = true;
	}
}

/**
 * Gets the current projectile sprite on the map.
 * @return Projectile or 0 if there is no projectile sprite on the map.
 */
Projectile *Map::getProjectile() const
{
	return _projectile;
}

/**
 * Add new vapor particle.
 * @param pos Tile position of particle.
 * @param particle Particle to add.
 */
void Map::addVaporParticle(Position pos, Particle particle)
{
	if ((int)(_transparencies->size()) < (particle.getColor() + 1) * Mod::TransparenciesOpacityLevels * Mod::TransparenciesPaletteColors)
	{
		return;
	}
	if (pos.x >= _camera->getMapSizeX() || pos.y >= _camera->getMapSizeY())
	{
		return;
	}
	if (pos.x < 0 || pos.y < 0)
	{
		return;
	}

	auto& v = _vaporParticlesInit[_camera->getMapSizeX() * pos.y + pos.x];

	// as there will usually be more than one Particle, we prepare more space
	if (v.capacity() < 64)
	{
		v.reserve(64);
	}

	v.push_back(particle);
}

/**
 * Get all vapor for tile.
 * @param tile current tile.
 * @param topLayer if tile is top visible layer, if true then will return particles belongs to upper tiles.
 * @return range of particles that should be drawn.
 */
Collections::Range<const Particle*> Map::getVaporParticle(const Tile* tile, int topLayer) const
{
	Position pos = tile->getPosition();
	auto& v = _vaporParticles[_camera->getMapSizeX() * pos.y + pos.x];
	int startZ = pos.z * Particle::LayerAccuracy + (topLayer & 1);
	int endZ = startZ + Particle::LayerAccuracy / 2;
	auto* s = std::partition_point(v.data(), v.data() + v.size(), [&](const Particle& a){ return a.getLayerZ() < startZ; });
	auto* e = (topLayer & 2) ? v.data() + v.size() : std::partition_point(s, v.data() + v.size(), [&](const Particle& a){ return a.getLayerZ() < endZ; });
	return Collections::Range{ s, e };
}

/**
 * Gets a list of explosion sprites on the map.
 * @return A list of explosion sprites.
 */
std::list<Explosion*> *Map::getExplosions()
{
	return &_explosions;
}

/**
 * Gets the pointer to the camera.
 * @return Pointer to camera.
 */
Camera *Map::getCamera()
{
	return _camera;
}

/**
 * Timers only work on surfaces so we have to pass this on to the camera object.
 */
void Map::scrollMouse()
{
	_camera->scrollMouse();
}

/**
 * Timers only work on surfaces so we have to pass this on to the camera object.
 */
void Map::scrollKey()
{
	_camera->scrollKey();
}

/**
 * Modify the fade shade level if fade's in progress.
 */
void Map::fadeShade()
{
	bool hold = SDL_GetKeyState(NULL)[Options::keyNightVisionHold];
	if ((_nightVisionOn && !hold) || (!_nightVisionOn && hold))
	{
		_nvColor = Options::oxceNightVisionColor;
		_save->setToggleNightVisionTemp(true);
		_save->setToggleNightVisionColorTemp(_nvColor);
		if (_fadeShade > NIGHT_VISION_SHADE) // 0 = max brightness
		{
			--_fadeShade;
		}
	}
	else
	{
		if (_nvColor != 0)
		{
			if (_fadeShade < _save->getGlobalShade())
			{
				// gradually fade away
				++_fadeShade;
			}
			else
			{
				// and at the end turn off night vision
				_nvColor = 0;
				_save->setToggleNightVisionTemp(false);
				_save->setToggleNightVisionColorTemp(0);
			}
		}
	}
}

/**
 * Gets a list of waypoints on the map.
 * @return A list of waypoints.
 */
std::vector<Position> *Map::getWaypoints()
{
	return &_waypoints;
}

/**
 * Sets mouse-buttons' pressed state.
 * @param button Index of the button.
 * @param pressed The state of the button.
 */
void Map::setButtonsPressed(Uint8 button, bool pressed)
{
	setButtonPressed(button, pressed);
}

/**
 * Sets the unitDying flag.
 * @param flag True if the unit is dying.
 */
void Map::setUnitDying(bool flag)
{
	_unitDying = flag;
}

/**
 * Updates the selector to the last-known mouse position.
 */
void Map::refreshSelectorPosition()
{
	setSelectorPosition(_mouseX, _mouseY);
}

/**
 * Special handling for setting the height of the map viewport.
 * @param height the new base screen height.
 */
void Map::setHeight(int height)
{
	Surface::setHeight(height);
	_visibleMapHeight = height - _iconHeight;
	_message->setHeight((_visibleMapHeight < 200)? _visibleMapHeight : 200);
	_message->setY((_visibleMapHeight - _message->getHeight()) / 2);
}

/**
 * Special handling for setting the width of the map viewport.
 * @param width the new base screen width.
 */
void Map::setWidth(int width)
{
	int dX = width - getWidth();
	Surface::setWidth(width);
	_message->setX(_message->getX() + dX / 2);
}

/**
 * Get the hidden movement screen's vertical position.
 * @return the vertical position of the hidden movement window.
 */
int Map::getMessageY() const
{
	return _message->getY();
}

/**
 * Get the icon height.
 */
int Map::getIconHeight() const
{
	return _iconHeight;
}

/**
 * Get the icon width.
 */
int Map::getIconWidth() const
{
	return _iconWidth;
}

/**
 * Returns the angle(left/right balance) of a sound effect,
 * based off a map position.
 * @param pos the map position to calculate the sound angle from.
 * @return the angle of the sound (280 to 440).
 */
int Map::getSoundAngle(const Position& pos) const
{
	int midPoint = getWidth() / 2;
	Position relativePosition;

	_camera->convertMapToScreen(pos, &relativePosition);
	// cap the position to the screen edges relative to the center,
	// negative values indicating a left-shift, and positive values shifting to the right.
	relativePosition.x = Clamp((relativePosition.x + _camera->getMapOffset().x) - midPoint, -midPoint, midPoint);

	// convert the relative distance to a relative increment of an 80 degree angle
	// we use +- 80 instead of +- 90, so as not to go ALL the way left or right
	// which would effectively mute the sound out of one speaker.
	// since Mix_SetPosition uses modulo 360, we can't feed it a negative number, so add 360 instead.
	return 360 + (relativePosition.x / (midPoint / 80.0));
}

/**
 * Reset the camera smoothing bool.
 */
void Map::resetCameraSmoothing()
{
	_smoothingEngaged = false;
}

/**
 * Set the "explosion flash" bool.
 * @param flash should the screen be rendered in EGA this frame?
 */
void Map::setBlastFlash(bool flash)
{
	_flashScreen = flash;

	// Meridian: no frikin flashing!!
	_flashScreen = false;
}

/**
 * Checks if the screen is still being rendered in EGA.
 * @return if we are still in EGA mode.
 */
bool Map::getBlastFlash() const
{
	return _flashScreen;
}

/**
 * Resets obstacle markers.
 */
void Map::resetObstacles(void)
{
	for (int z = 0; z < _save->getMapSizeZ(); z++)
		for (int y = 0; y < _save->getMapSizeY(); y++)
			for (int x = 0; x < _save->getMapSizeX(); x++)
			{
				Tile *tile = _save->getTile(Position(x, y, z));
				if (tile) tile->resetObstacle();
			}
	_showObstacles = false;
}

/**
 * Enables obstacle markers.
 */
void Map::enableObstacles(void)
{
	_showObstacles = true;
	if (_obstacleTimer)
	{
		_obstacleTimer->stop();
		_obstacleTimer->start();
	}
}

/**
 * Disables obstacle markers.
 */
void Map::disableObstacles(void)
{
	_showObstacles = false;
	if (_obstacleTimer)
	{
		_obstacleTimer->stop();
	}
}

}
