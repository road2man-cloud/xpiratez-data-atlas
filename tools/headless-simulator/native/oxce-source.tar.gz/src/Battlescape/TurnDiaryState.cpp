/*
 * Copyright 2010-2019 OpenXcom Developers.
 *
 * This file is part of OpenXcom.
 *
 * OpenXcom is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * OpenXcom is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with OpenXcom.  If not, see <http://www.gnu.org/licenses/>.
 */
#include "TurnDiaryState.h"
#include "../Engine/Action.h"
#include "../Engine/Game.h"
#include "../Engine/Options.h"
#include "../Engine/Logger.h"
#include "../Interface/Window.h"
#include "../Interface/Text.h"
#include "../Interface/TextButton.h"
#include "../Interface/TextList.h"
#include "../Mod/Mod.h"
#include "../Savegame/HitLog.h"
#include "../Savegame/SavedBattleGame.h"
#include "../Savegame/SavedGame.h"

namespace OpenXcom
{

/**
 * Initializes all the elements in the Turn Diary window.
 */
TurnDiaryState::TurnDiaryState(const HitLog *hitLog)
{
	_screen = false;

	// Create objects
	_window = new Window(this, 216, 160, 52, 20, POPUP_BOTH);
	_txtTitle = new Text(206, 17, 57, 32);
	_btnCancel = new TextButton(140, 16, 90, 156);
	_lstTurnDiary = new TextList(180, 96, 65, 52);

	// Set palette
	_game->getSavedGame()->getSavedBattle()->setPaletteByDepth(this);

	add(_window, "messageWindowBorder", "battlescape");
	add(_txtTitle, "messageWindows", "battlescape");
	add(_btnCancel, "messageWindowButtons", "battlescape");
	add(_lstTurnDiary, "optionLists", "battlescape");

	centerAllSurfaces();

	// Set up objects
	_window->setHighContrast(true);
	_window->setBackground(_game->getMod()->getSurface("TAC00.SCR"));

	_txtTitle->setAlign(ALIGN_CENTER);
	_txtTitle->setBig();
	_txtTitle->setHighContrast(true);
	_txtTitle->setText(tr("STR_HIT_LOG"));

	_btnCancel->setText(tr("STR_CANCEL_UC"));
	_btnCancel->setHighContrast(true);
	_btnCancel->onMouseClick((ActionHandler)&TurnDiaryState::btnCancelClick);
	_btnCancel->onKeyboardPress((ActionHandler)&TurnDiaryState::btnCancelClick, Options::keyCancel);

	_lstTurnDiary->setColumns(1, 172);
	_lstTurnDiary->setSelectable(true);
	_lstTurnDiary->setBackground(_window);
	_lstTurnDiary->setMargin(8);
	_lstTurnDiary->setAlign(ALIGN_CENTER);
	_lstTurnDiary->setHighContrast(true);
	_lstTurnDiary->setWordWrap(true);

	// Display the most recent *completed hostile turn* FIRST. The old mixed
	// diary buried hostile shots below newer environmental/turn messages.
	// The HitLog ABI is unchanged; structured events use the existing vector.
	size_t row = 0;
	auto addLogRow = [this, &row](const std::string &value)
	{
		_lstTurnDiary->addRow(1, value.c_str());
		if (row % 2 != 0) _lstTurnDiary->setRowColor(row, _lstTurnDiary->getSecondaryColor());
		++row;
	};

	const std::vector<std::string> enemy = hitLog->getLastHostileTurnDiary();
#ifdef XPZ_PREV_ENEMY_DIAG
	Log(LOG_INFO) << "[XPZ_HISTORY_DIAG] OPEN hasHostile=" << hitLog->hasCompletedHostileTurnDiary()
		<< " hostileEvents=" << enemy.size() << " diarySize=" << hitLog->getTurnDiary().size();
	for (size_t i = 0; i < hitLog->getTurnDiary().size(); ++i)
	{
		if (HitLog::isDiaryMetadata(hitLog->getTurnDiary()[i]))
		{
			Log(LOG_INFO) << "[XPZ_HISTORY_DIAG] ENTRY " << i << " " << hitLog->getTurnDiary()[i].substr(1, 90);
		}
	}
#endif
	if (hitLog->hasCompletedHostileTurnDiary())
	{
		addLogRow(std::string("직전 적 턴: ") + std::to_string(enemy.size()) + "건");
		if (enemy.empty())
		{
			addLogRow("공격/피해 기록 없음");
		}
		else
		{
			// Recent events first; TextList remains scrollable for large fights.
			for (std::vector<std::string>::const_reverse_iterator it = enemy.rbegin(); it != enemy.rend(); ++it)
			{
				addLogRow(*it);
			}
		}
	}
	else
	{
		addLogRow("직전 적 턴 기록 없음 (이 실행 이후부터 기록)");
	}

	addLogRow("--- 현재 턴 ---");
	const std::string active = hitLog->getHitLogText(true);
	if (!active.empty()) addLogRow(active);
	const std::vector<std::string> current = hitLog->getCurrentTurnDiary();
	for (std::vector<std::string>::const_reverse_iterator it = current.rbegin(); it != current.rend(); ++it)
	{
		addLogRow(*it);
	}
}

/**
 * Returns to the previous screen.
 * @param action Pointer to an action.
 */
void TurnDiaryState::btnCancelClick(Action *)
{
	_game->popState();
}

}
