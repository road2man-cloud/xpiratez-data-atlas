/*
 * R43 RC18: Scroll the tactical camera without recentering it onto a tile.
 *
 * Work in the rotated, continuous map plane. Both keyboard and mouse pans
 * enter Camera::scrollXY, so a bounds correction must constrain the requested
 * delta rather than snap centerOnPosition() to a clamped tile coordinate.
 *
 * This helper has no SDL dependencies so that the production calculation can
 * be regression-tested independently of the renderer.
 */
#ifndef OPENXCOM_CAMERASCROLLBOUNDS_H
#define OPENXCOM_CAMERASCROLLBOUNDS_H

#include <algorithm>
#include <cmath>

namespace OpenXcom
{
namespace CameraScrollBounds
{

struct ScrollDelta
{
	int x;
	int y;
};

// Outside positions are possible immediately after focusing a unit on an edge.
// In that case allow movement TOWARD the map, never force an instant snap into it.
inline long long constrainAxis(long long previous, long long requested, long long maximum)
{
	if (previous < 0)
		return std::max(previous, std::min(requested, maximum));
	if (previous > maximum)
		return std::min(previous, std::max(requested, 0LL));
	return std::max(0LL, std::min(requested, maximum));
}

inline ScrollDelta limitScroll(int offsetX, int offsetY,
	int requestedX, int requestedY,
	int screenWidth, int visibleMapHeight,
	int spriteWidth, int spriteHeight, int viewLevel,
	int mapWidth, int mapHeight, int rotation)
{
	if (spriteWidth <= 0 || mapWidth <= 0 || mapHeight <= 0)
		return {0, 0};

	// This is the same continuous inverse isometric projection used by
	// Camera::convertScreenToMap, before its integer tile division and clamp.
	const long long screenX = screenWidth / 2;
	const long long screenY = visibleMapHeight / 2 - spriteWidth / 2
		+ (long long)viewLevel * ((spriteHeight + spriteWidth / 4) / 2);
	const long long t = screenY - offsetY;
	const long long oldU = 2 * t + screenX - offsetX - spriteWidth;
	const long long oldV = -screenX + offsetX + 2 * t;

	// A pan changes the two diagonal map-plane axes independently.
	const long long requestedU = oldU - requestedX - 2LL * requestedY;
	const long long requestedV = oldV + requestedX - 2LL * requestedY;

	// 90 and 270 degree views exchange map width and height.
	const bool quarterTurn = (rotation & 1) != 0;
	const long long maxU = (long long)((quarterTurn ? mapHeight : mapWidth) - 1) * spriteWidth;
	const long long maxV = (long long)((quarterTurn ? mapWidth : mapHeight) - 1) * spriteWidth;
	const long long allowedU = constrainAxis(oldU, requestedU, maxU);
	const long long allowedV = constrainAxis(oldV, requestedV, maxV);
	const long long du = allowedU - oldU;
	const long long dv = allowedV - oldV;

	// Project only the allowed delta back into screen pixels. No tile-centered
	// repositioning and no unbounded 1-pixel convergence loops.
	return {
		(int)std::llround((dv - du) / 2.0),
		(int)std::llround(-(du + dv) / 4.0)
	};
}

} // namespace CameraScrollBounds
} // namespace OpenXcom

#endif
