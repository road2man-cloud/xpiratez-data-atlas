#pragma once
/*
 * Research unlock markers for the in-game research lists.
 * R31: direct ruleset references, independently classified; a recipe
 * using an item as an ingredient does not imply that item's research
 * unlocks that recipe. Each category can coexist with the others.
 */
#include <map>
#include <string>
#include <vector>
#include "../Mod/Mod.h"
#include "../Mod/RuleResearch.h"
#include "../Mod/RuleManufacture.h"
#include "../Mod/RuleItem.h"
#include "../Mod/RuleCraft.h"
#include "../Mod/RuleSoldier.h"
#include "../Mod/RuleMissionScript.h"

namespace OpenXcom
{
enum ResearchUnlockBit
{
    RUL_MISSION = 1, RUL_MANUFACTURE = 2, RUL_PURCHASE = 4, RUL_FOLLOWUP = 8
};

inline std::map<std::string, Uint8> buildResearchUnlockFlags(const Mod *mod)
{
    std::map<std::string, Uint8> flags;
    if (!mod) return flags;

    const auto mark = [&flags](const RuleResearch *topic, Uint8 bit)
    {
        if (topic) flags[topic->getName()] |= bit;
    };

    // A follow-up exists when a rule explicitly unlocks other research OR
    // some other research requires this one, even if the path is conditional.
    for (const std::string &name : mod->getResearchList())
    {
        const RuleResearch *rule = mod->getResearch(name);
        if (!rule) continue;
        for (const RuleResearch *pre : rule->getDependencies()) mark(pre, RUL_FOLLOWUP);
        for (const RuleResearch *pre : rule->getRequirements()) mark(pre, RUL_FOLLOWUP);
        if (!rule->getUnlocked().empty()) mark(rule, RUL_FOLLOWUP);
    }

    for (const std::string &name : mod->getManufactureList())
    {
        const RuleManufacture *recipe = mod->getManufacture(name);
        if (!recipe) continue;
        for (const RuleResearch *pre : recipe->getRequirements()) mark(pre, RUL_MANUFACTURE);
    }

    for (const std::string &name : mod->getItemsList())
    {
        const RuleItem *item = mod->getItem(name);
        if (!item) continue;
        for (const RuleResearch *pre : item->getBuyRequirements()) mark(pre, RUL_PURCHASE);
    }
    for (const std::string &name : mod->getCraftsList())
    {
        const RuleCraft *craft = mod->getCraft(name);
        if (!craft || craft->getBuyCost() <= 0) continue;
        for (const RuleResearch *pre : craft->getRequirements()) mark(pre, RUL_PURCHASE);
    }
    for (const std::string &name : mod->getSoldiersList())
    {
        const RuleSoldier *soldier = mod->getSoldier(name);
        if (!soldier || soldier->getBuyCost() <= 0) continue;
        for (const RuleResearch *pre : soldier->getRequirements()) mark(pre, RUL_PURCHASE);
    }

    // Only positive research triggers of scripts which can actually
    // generate missions; negative triggers do not count as unlocks.
    const auto scanMissionScripts = [&mark, mod](const std::vector<std::string> *names, bool adhoc)
    {
        if (!names) return;
        for (const std::string &name : *names)
        {
            const RuleMissionScript *script = adhoc ? mod->getAdhocScript(name) : mod->getMissionScript(name);
            if (!script || !script->hasMissionWeights()) continue;
            for (const auto &entry : script->getResearchTriggers())
                if (entry.second) mark(entry.first, RUL_MISSION);
        }
    };
    scanMissionScripts(mod->getMissionScriptList(), false);
    scanMissionScripts(mod->getAdhocScriptList(), true);

    return flags;
}

inline Uint8 researchUnlockFlag(const std::map<std::string, Uint8> &flags, const RuleResearch *topic)
{
    if (!topic) return 0;
    const auto it = flags.find(topic->getName());
    return it == flags.end() ? 0 : it->second;
}
}
